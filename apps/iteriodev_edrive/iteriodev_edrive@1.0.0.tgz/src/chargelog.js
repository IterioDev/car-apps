// Ported from cauliflowermossgrape/idrive7-apps (MIT License, Copyright (c) 2026 cauliflowermossgrape): apps/edrive/main.js @ c67ea17.
'use strict';
/**
 * chargelog.js - eDrive's charges (the kit's main.js: last charge, charge log page). Pure: time passed in (ms).
 *
 * A charge = the charge level rising by >= minPct (app.json chargeMinPct, 3) while the car stands still (regen
 * while driving doesn't count). The last reading is kept (persist toJSON()), so a charge done while the head
 * unit slept shows up as a jump at the next start - even when the car is already moving by the first reading,
 * as readings come every few seconds while the car is on and regen never adds that much between them.
 * A session ends when driving off or on a real drop (> 2 %); small dips while parked keep it open.
 *
 *   const log = ChargeLog.fromJSON(saved, { minPct: 3 })
 *   log.reading(soc, now, moving, kwhPerPct) -> true: save the state now (a charge logged, a session opened / grew / closed)
 *   log.charging()             -> a session is open (range.js learns nothing meanwhile: ask before log.reading)
 *   log.last(kwhPerPct)        -> the charge in progress (>= minPct, open: true) or the last one, or null
 *   log.rows(kmPerPct, price)  -> newest first: { from, to, fromT, toT, added (%), kwh, km, cost }
 *   log.totals(now, kmPerPct, price) -> { month, all }: { count, kwh, pct, km, cost }
 *   log.days(now, n)           -> kWh charged per local day, n days, oldest first, today last
 *   cost(kwh, price)           -> kWh from the grid (LOSS) x price per kWh, null without a price
 * kmPerPct: range.js estimate(...).kpp now (range added); kwhPerPct: range.js kwhPerPct(designKwh, soh).
 */
const LOG_MAX = 200;             // charges kept in the log
const LOSS = 1.1;                // grid energy per kWh stored (charger + battery losses, estimate)
const ASLEEP_MS = 10 * 60000;    // a gap this long between charge readings: the car was off meanwhile
const RISE = 0.3;                // % a reading must rise to count as charging
const DROP = 2;                  // % below the session's top that ends it while parked

const isNum = (v) => typeof v === 'number' && isFinite(v);
const cost = (kwh, price) => (isNum(kwh) && isNum(price) && price > 0 ? kwh * LOSS * price : null);

class ChargeLog {
    constructor(st, opts) {
        this.st = Object.assign({ lastSoc: null, lastSocT: null, session: null, log: [] }, st);
        this.minPct = opts && isNum(opts.minPct) ? opts.minPct : 3;
    }
    static fromJSON(o, opts) { return new ChargeLog(o ? JSON.parse(JSON.stringify(o)) : null, opts); }
    toJSON() { return this.st; }

    charging() { return !!this.st.session; }

    reading(soc, now, moving, kwhPerPct) {
        if (!isNum(soc)) return false;
        const st = this.st, prev = st.lastSoc, open = st.session;
        let logged = null;
        if (isNum(prev)) {
            if (soc > prev + RISE && now - st.lastSocT > ASLEEP_MS && soc >= (open ? open.from : prev) + this.minPct) {
                // charged while the car was off (also one that began while the head unit was still awake):
                // the charge runs up to this reading and ended before it
                if (!st.session) st.session = { from: prev, fromT: st.lastSocT };
                st.session.to = soc; st.session.toT = now;
                logged = this.close(kwhPerPct);
            } else if (soc > prev + RISE && !moving) {
                if (!st.session) st.session = { from: prev, fromT: st.lastSocT };
                st.session.to = soc; st.session.toT = now;
            } else if (st.session && (soc < st.session.to - DROP || moving)) {
                logged = this.close(kwhPerPct);
            }
        }
        st.lastSoc = soc; st.lastSocT = now;
        // saved with this reading, so the state never holds a logged charge with the reading before it
        // (the next start would log the same charge again)
        return !!logged || st.session !== open || !!(open && open.toT === now);
    }

    close(kwhPerPct) {
        const s = this.st.session;
        this.st.session = null;
        if (!s || !(s.to - s.from >= this.minPct)) return null;
        const e = { from: s.from, to: s.to, fromT: s.fromT, toT: s.toT, kwh: isNum(kwhPerPct) ? (s.to - s.from) * kwhPerPct : null };
        this.st.log.push(e);
        if (this.st.log.length > LOG_MAX) this.st.log.splice(0, this.st.log.length - LOG_MAX);
        return e;
    }

    last(kwhPerPct) {
        const s = this.st.session;
        if (s && s.to - s.from >= this.minPct) return Object.assign({}, s, { kwh: isNum(kwhPerPct) ? (s.to - s.from) * kwhPerPct : null, open: true });
        return this.st.log.length ? this.st.log[this.st.log.length - 1] : null;
    }

    rows(kmPerPct, price) {
        return this.st.log.slice().reverse().map((c) => Object.assign({}, c, {
            added: c.to - c.from, km: isNum(kmPerPct) ? (c.to - c.from) * kmPerPct : null, cost: cost(c.kwh, price),
        }));
    }

    totals(now, kmPerPct, price) {
        const d = new Date(now), monthStart = new Date(d.getFullYear(), d.getMonth(), 1).getTime();
        const sum = (list) => {
            const kwh = list.reduce((a, c) => a + (isNum(c.kwh) ? c.kwh : 0), 0), pct = list.reduce((a, c) => a + (c.to - c.from), 0);
            return { count: list.length, kwh: kwh, pct: pct, km: isNum(kmPerPct) ? pct * kmPerPct : null, cost: cost(kwh, price) };
        };
        return { month: sum(this.st.log.filter((c) => c.toT >= monthStart)), all: sum(this.st.log) };
    }

    days(now, n) {
        n = n || 14;
        const d = new Date(now), out = [];
        for (let i = n - 1; i >= 0; i--) {
            // local midnights (a DST day is 23 / 25 h)
            const a = new Date(d.getFullYear(), d.getMonth(), d.getDate() - i).getTime();
            const b = new Date(d.getFullYear(), d.getMonth(), d.getDate() - i + 1).getTime();
            out.push(this.st.log.reduce((s, c) => s + (c.toT >= a && c.toT < b && isNum(c.kwh) ? c.kwh : 0), 0));
        }
        return out;
    }
}

function test() {
    const assert = require('assert');
    const near = (a, b) => assert(isNum(a) && Math.abs(a - b) < 1e-6, a + ' != ' + b);
    const k = 0.12 * 0.915, MIN = 60000, H = 3600000;        // kWh per % (the kit's demo: 12 kWh, SOH 91.5)
    let log = ChargeLog.fromJSON(null);
    // parked and awake (plugged in): 30 -> 34 % one reading a minute, a small dip keeps it open, then driving off
    const T = new Date(2026, 10, 3, 18, 0).getTime();
    assert.strictEqual(log.reading(30, T, false, k), false);
    assert.strictEqual(log.reading(31, T + MIN, false, k), true);                        // session opened
    assert.strictEqual(log.charging(), true);
    assert.strictEqual(log.last(k), null);                                               // < 3 % so far
    log.reading(32, T + 2 * MIN, false, k); log.reading(34, T + 3 * MIN, false, k);
    assert.deepStrictEqual([log.last(k).open, log.last(k).to], [true, 34]);
    assert.strictEqual(log.reading(33.5, T + 4 * MIN, false, k), false);                 // pre-conditioning dip
    assert.strictEqual(log.reading(33.5, T + 5 * MIN, true, k), true);                   // driving off: logged
    let c = log.last(k);
    assert.deepStrictEqual([c.from, c.to, c.fromT, c.toT, c.open], [30, 34, T, T + 3 * MIN, undefined]); near(c.kwh, 4 * k);
    // regen while driving, and a parked rise under 3 %: nothing
    log.reading(33.9, T + 6 * MIN, true, k);
    log.reading(34.5, T + 7 * MIN, false, k); log.reading(35.5, T + 8 * MIN, false, k); log.reading(35.5, T + 9 * MIN, true, k);
    assert.strictEqual(log.st.log.length, 1); assert.strictEqual(log.charging(), false);
    // charged overnight while the head unit slept: seen at the next start, the car already moving
    log = ChargeLog.fromJSON(JSON.parse(JSON.stringify(log)));                          // restart
    assert.strictEqual(log.reading(95, T + 14 * H, true, k), true);
    c = log.last(k);
    assert.deepStrictEqual([c.from, c.to, c.fromT, c.toT], [35.5, 95, T + 9 * MIN, T + 14 * H]); near(c.kwh, 59.5 * k);
    // a charge begun while awake, the head unit slept with the session open: closed at the next start from its start
    log.reading(40, T + 20 * H, false, k); log.reading(42, T + 20 * H + MIN, false, k);
    log = ChargeLog.fromJSON(JSON.parse(JSON.stringify(log)));
    log.reading(80, T + 30 * H, false, k);
    assert.deepStrictEqual([log.last(k).from, log.last(k).to, log.charging()], [40, 80, false]);
    // capped at 200 entries, the newest kept
    for (let i = 0; i < 205; i++) { log.reading(20, T + 40 * H + i * 2 * H, true, k); log.reading(90, T + 41 * H + i * 2 * H, true, k); }
    assert.strictEqual(log.st.log.length, 200); assert.strictEqual(log.last(k).toT, T + 41 * H + 204 * 2 * H);
    // totals, 14 days, cost (local dates)
    const at = (m, d, h) => new Date(2026, m, d, h).getTime(), e = (m, d, kwh) => ({ from: 20, to: 20 + kwh / k, fromT: at(m, d, 1), toT: at(m, d, 6), kwh: kwh });
    log = ChargeLog.fromJSON({ log: [e(9, 1, 2), e(9, 30, 4), e(10, 2, 3), e(10, 4, 5)] });
    const now = at(10, 4, 12), tot = log.totals(now, 1.6, 0.25);
    assert.deepStrictEqual([tot.month.count, tot.all.count], [2, 4]);
    near(tot.month.kwh, 8); near(tot.all.kwh, 14); near(tot.month.cost, 8 * 1.1 * 0.25); near(tot.month.pct, 8 / k); near(tot.all.km, 14 / k * 1.6);
    const days = log.days(now, 14);
    assert.strictEqual(days.length, 14);
    assert.deepStrictEqual([days[13], days[11], days[8], days.reduce((a, v) => a + v, 0)], [5, 3, 4, 12]);   // Oct 1: older
    const rows = log.rows(1.6, 0);
    assert.deepStrictEqual([rows[0].toT, rows[0].cost], [at(10, 4, 6), null]); near(rows[0].added, 5 / k); near(rows[0].km, 5 / k * 1.6);
    near(cost(10, 0.3), 3.3); assert.strictEqual(cost(null, 0.3), null);
    console.log('chargelog self-check ok: +4 % parked = ' + (4 * k).toFixed(2) + ' kWh, overnight 35.5 -> 95 % = ' + (59.5 * k).toFixed(2)
        + ' kWh, month ' + tot.month.kwh + ' kWh / ' + tot.month.cost.toFixed(2) + ' EUR, 14 days ' + days.join(' '));
}

module.exports = { ChargeLog, cost, LOG_MAX, LOSS, test };
if (require.main === module) test();

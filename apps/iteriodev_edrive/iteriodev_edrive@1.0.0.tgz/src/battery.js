// Ported from cauliflowermossgrape/idrive7-apps (MIT License, Copyright (c) 2026 cauliflowermossgrape): apps/edrive/live.js @ c67ea17.
'use strict';
/**
 * battery.js - eDrive's high-voltage battery values from the battery unit (SME, 0x07), read-only.
 * Also from the kit: app.json config.battery (identifiers, scalings, powerSign), main.js (12 V, "no hybrid
 * system", the poll pacing) and kit/runtime/dids.js (decoding).
 *
 *   read(addr, did) -> Promise of Buffer, the whole reply (62 <did> data / 41 <pid> data / 7F <sid> <nrc>),
 *   or null when the unit did not answer. did 'DDBC' = UDS 22 DD BC, 'OBD 42' = OBD service 01 PID 42.
 *   Nothing else is ever asked (read-only).
 *
 *   const b = new Battery(read, { powerSign: -1 }, saved)
 *   await b.poll(now)          -> { soc, v12 }   every few s: 12 V and charge; decides "no hybrid system"
 *   await b.health()           -> SOH % or null  (every few days)
 *   await b.power(now, lscV)   -> { v, a, kw } or null, kW + = the battery gives power (lscV: SOME/IP volts fallback)
 *   await b.slow()             -> { cellV, cellT, coolant, limits } (each null when not answered)
 *   b.noHybrid                 -> true once the SME stayed silent while the link worked; b.toJSON() keeps it
 *   limitsKw(limits, v)        -> { out (drive), in (regen / charge) } kW
 *   new Drive(now).add(kw, now, moving, climateKw); .totals(); .trace   this drive + the 2-minute trace
 */
const isNum = (v) => typeof v === 'number' && isFinite(v);

const SME = 0x07, DME = 0x12, DME2 = 0x13, EGS = 0x18;
const RETRY_MS = 300000;           // 12 V after 3 failures / the SME without a hybrid system: asked every 5 min
const V_MS = 5000;                 // pack voltage moves little: read every 5 s, the current every turn
const V_KEEP_MS = 60000;
const TRACE_MS = 120000;           // power trace on the Battery tab
const GAP_MS = 6000;               // a longer gap between power reads counts as this (kit: 3 x 2 s background)
const IDLE_KW = 0.3;

const f = (at, bytes, factor, min, max, signed) => ({ at: at, bytes: bytes, factor: factor, min: min, max: max, signed: !!signed });
const VOLT = { v: f(0, 2, 0.01, 150, 500) };
const CELL = (at) => f(at, 2, 0.001, 2.5, 4.4);
const TEMP = (at) => f(at, 2, 0.01, -40, 80, true);
const V12 = { v: f(0, 2, 0.001, 5, 18) };
const SOH = { pct: f(0, 1, 1, 40, 110) };
/** app.json config.battery as candidates: the first that answers with a plausible first field wins. */
const CONFIG = {
    ecu: SME,
    powerSign: -1,                 // kW = V x A / 1000 x -1 on the X5 45e (DD69 + = into the pack)
    soc: [{ did: 'DDBC', fields: { pct: f(0, 2, 0.1, 0, 100) } }],
    soh: [{ did: 'DD7B', fields: SOH }, { did: '6335', fields: SOH }],
    hvV: [{ did: 'DDB4', fields: VOLT }, { did: 'DD68', fields: VOLT }, { did: 'DD66', fields: VOLT },
        { did: 'DDEF', fields: { v: f(0, 2, 1, 150, 500) } }],
    hvI: [{ did: 'DD69', fields: { a: f(0, 4, 0.01, -800, 800, true) } }],
    // every cell, 2 bytes each (96 on the X5 45e); else the lowest / highest only
    cellV: [{ did: 'DFA5', array: CELL(0) }, { did: 'DDBF', fields: { min: CELL(0), max: CELL(2) } }],
    cellT: [{ did: 'DDC0', fields: { min: TEMP(0), max: TEMP(2), avg: TEMP(4) } }],
    coolant: [{ did: 'DD6C', fields: { t: f(0, 2, 0.01, -40, 100, true) } }],
    limits: [{ did: 'DD7D', fields: { chargeA: f(0, 2, 0.1, 0, 1000), dischargeA: f(2, 2, 0.1, 0, 1000) } }],
    // control module voltage (terminal 30): engine unit, battery unit, OBD 42 for units that refuse F442 (NRC 31),
    // a second engine unit, the gearbox unit (G06 N63: the engine unit doesn't answer)
    v12: [{ ecu: DME, did: 'F442', fields: V12 }, { ecu: SME, did: 'F442', fields: V12 }, { ecu: DME, did: 'OBD 42', fields: V12 },
        { ecu: DME2, did: 'F442', fields: V12 }, { ecu: DME2, did: 'OBD 42', fields: V12 },
        { ecu: EGS, did: 'F442', fields: V12 }, { ecu: EGS, did: 'OBD 42', fields: V12 }],
};

/** fd.bytes big-endian bytes at fd.at after the echo: raw x factor + offset, null outside min..max or past the end. */
function num(buf, head, fd) {
    const at = head + (fd.at || 0), n = fd.bytes || 1;
    if (buf.length < at + n) return null;
    let raw = 0;
    for (let j = 0; j < n; j++) raw = raw * 256 + buf[at + j];
    if (fd.signed && raw >= Math.pow(2, 8 * n - 1)) raw -= Math.pow(2, 8 * n);
    const v = raw * (fd.factor == null ? 1 : fd.factor) + (fd.offset || 0);
    return (fd.min != null && v < fd.min) || (fd.max != null && v > fd.max) ? null : v;
}

/**
 * One candidate's reply: { field: value } (the first field must be plausible, the others are null when not),
 * for an array { cells, min, max, avg, minAt, maxAt } (cells outside min..max null, at least half valid); else null.
 */
function decode(c, buf) {
    if (!buf || buf.length < 2) return null;
    const obd = c.did.indexOf('OBD ') === 0, id = parseInt(obd ? c.did.slice(4) : c.did, 16), head = obd ? 2 : 3;
    if (obd ? buf[0] !== 0x41 || buf[1] !== id : buf.length < 3 || buf[0] !== 0x62 || buf[1] * 256 + buf[2] !== id) return null;
    if (c.array) {
        const n = c.array.bytes || 1, cells = [];
        for (let at = 0; head + at + n <= buf.length; at += n) cells.push(num(buf, head, Object.assign({}, c.array, { at: at })));
        const ok = cells.filter(isNum);
        if (!ok.length || ok.length < cells.length / 2) return null;
        const min = Math.min.apply(null, ok), max = Math.max.apply(null, ok);
        return { cells: cells, min: min, max: max, avg: ok.reduce((a, v) => a + v, 0) / ok.length, minAt: cells.indexOf(min) + 1, maxAt: cells.indexOf(max) + 1 };
    }
    const out = {}, keys = Object.keys(c.fields);
    keys.forEach((k) => { out[k] = num(buf, head, c.fields[k]); });
    return isNum(out[keys[0]]) ? out : null;
}

/** A single-field group's value (soc, soh, v12, coolant ...), or null. */
const first = (r) => (r.value ? r.value[Object.keys(r.value)[0]] : null);

/** Power the battery allows now (kW) from its current limits x pack voltage. */
const limitsKw = (lim, v) => (lim && isNum(v) ? {
    out: isNum(lim.dischargeA) ? lim.dischargeA * v / 1000 : null,
    in: isNum(lim.chargeA) ? lim.chargeA * v / 1000 : null,
} : null);

class Battery {
    constructor(read, opts, saved) {
        opts = opts || {};
        this.read = read;
        this.cfg = Object.assign({}, CONFIG, opts.config);
        this.powerSign = isNum(opts.powerSign) ? opts.powerSign : this.cfg.powerSign;
        this.st = { hybrid: !!(saved && saved.hybrid), noHybrid: !!(saved && saved.noHybrid) };
        this.pick = {};
        this.smeMiss = 0; this.v12Fail = 0; this.v12Try = -Infinity; this.socTry = -Infinity;
        this.v = null; this.vT = -Infinity;
    }

    /**
     * A value's candidates, starting with the one that answered last: { value (decoded or null), heard (any
     * reply came back, a refusal too), silent (every candidate: no reply) }. A read that throws (link down)
     * is neither heard nor silent.
     */
    async group(name) {
        const list = this.cfg[name] || [], start = this.pick[name] || 0;
        let heard = false, silent = true;
        for (let k = 0; k < list.length; k++) {
            const i = (start + k) % list.length, c = list[i];
            let buf;
            try { buf = await this.read(c.ecu == null ? this.cfg.ecu : c.ecu, c.did); } catch (e) { silent = false; continue; }
            if (buf) heard = true;
            const v = decode(c, buf);
            if (v) { this.pick[name] = i; return { value: v, heard: true, silent: false }; }
        }
        return { value: null, heard: heard, silent: silent && !heard };
    }

    /** 12 V every poll (after 3 failures in a row every 5 min), then the charge, which tells if there is a hybrid system. */
    async poll(now) {
        let v12 = null, soc = null;
        if (this.v12Fail < 3 || now - this.v12Try > RETRY_MS) {
            this.v12Try = now;
            v12 = first(await this.group('v12'));
            this.v12Fail = v12 === null ? this.v12Fail + 1 : 0;
        }
        // without a hybrid system the battery unit is only asked again every 5 minutes
        if (!this.noHybrid || now - this.socTry > RETRY_MS) {
            this.socTry = now;
            const r = await this.group('soc');
            soc = first(r);
            this.detect(r, v12 !== null);
        }
        return { soc: soc, v12: v12 };
    }

    /**
     * Any reply from the battery unit (even a refusal) = a hybrid system, for good. No reply 3 times in a row
     * while another unit answers (the 12 V), or 6 times when nothing answers (cars whose 12 V can't be read
     * either, seen on a G06 N63) = no hybrid system.
     */
    detect(r, otherAnswered) {
        if (r.heard) { this.smeMiss = 0; this.st.hybrid = true; this.st.noHybrid = false; }
        else if (r.silent && !this.st.hybrid && ++this.smeMiss >= (otherAnswered ? 3 : 6)) this.st.noHybrid = true;
    }
    get noHybrid() { return this.st.noHybrid && !this.st.hybrid; }
    /** The "Hybrid system" setting: 'yes' / 'no' / 'auto' (what was detected). */
    isHybrid(setting) { return setting === 'yes' ? true : setting === 'no' ? false : !this.noHybrid; }

    async health() { return first(await this.group('soh')); }

    /** V x I with the kit's sign. lscV: the pack voltage from SOME/IP (LSCDataSink) when no voltage DID answers. */
    async power(now, lscV) {
        if (!isNum(this.v) || now - this.vT > V_MS) {
            const v = first(await this.group('hvV'));
            if (v !== null) { this.v = v; this.vT = now; }
        }
        const a = first(await this.group('hvI'));
        const v = now - this.vT < V_KEEP_MS ? this.v : isNum(lscV) ? lscV : null;
        if (a === null || !isNum(v)) return null;
        return { v: v, a: a, kw: v * a / 1000 * (this.powerSign < 0 ? -1 : 1) };
    }

    /** Cells, temperatures, coolant, current limits; cellV gets spreadMv (highest - lowest). */
    async slow() {
        const out = {};
        for (const k of ['cellV', 'cellT', 'coolant', 'limits']) {
            const r = await this.group(k), c = this.cfg[k][this.pick[k] || 0];
            out[k] = r.value && !c.array && Object.keys(c.fields).length === 1 ? first(r) : r.value;
        }
        if (out.cellV && isNum(out.cellV.min) && isNum(out.cellV.max)) out.cellV.spreadMv = Math.round((out.cellV.max - out.cellV.min) * 1000);
        return out;
    }

    toJSON() { return { hybrid: this.st.hybrid, noHybrid: this.st.noHybrid }; }
}

/**
 * This drive: energy out of the pack (used), back in while moving (regen), in while standing (charged), the
 * part the climate took (never more than the pack gave), peaks; and the last 2 minutes of power (trace).
 * climateKw: the climate's draw now (kit: measured / estimated; range.js climateKw() as the fallback).
 */
class Drive {
    constructor(now) {
        this.out = 0; this.regen = 0; this.charged = 0; this.climate = 0; this.peakOut = 0; this.peakIn = 0;
        this.since = now; this.trace = []; this.kw = null; this.kwT = null;
    }
    add(kw, now, moving, climateKw) {
        if (this.kwT !== null && isNum(this.kw)) {
            const h = Math.min(now - this.kwT, GAP_MS) / 3600000;
            if (kw > 0) {
                this.out += kw * h;
                if (isNum(climateKw) && climateKw > 0) this.climate += Math.min(climateKw, kw) * h;
            } else if (moving) this.regen -= kw * h;
            else this.charged -= kw * h;
        }
        this.peakOut = Math.max(this.peakOut, kw);
        if (moving) this.peakIn = Math.max(this.peakIn, -kw);
        this.kw = kw; this.kwT = now;
        this.trace.push([now, kw]);
        while (this.trace.length && now - this.trace[0][0] > TRACE_MS) this.trace.shift();
    }
    /** kWh: used, regen, net (used - regen), charged; climate / driving and their shares; peaks (kW). */
    totals() {
        const clim = Math.min(this.climate, this.out), has = this.out > 0.005;
        return { used: this.out, regen: this.regen, net: this.out - this.regen, charged: this.charged, climate: clim,
            driving: Math.max(0, this.out - clim), climateShare: has ? clim / this.out : null,
            peakOut: this.peakOut, peakIn: this.peakIn, since: this.since };
    }
}

/** What the pack is doing: DRIVING / DRAWING (standing) / REGEN / CHARGING (standing) / IDLE. */
const state = (kw, moving) => (kw > IDLE_KW ? (moving ? 'DRIVING' : 'DRAWING') : kw < -IDLE_KW ? (moving ? 'REGEN' : 'CHARGING') : 'IDLE');

async function test() {
    const assert = require('assert');
    const near = (a, b, e) => assert(isNum(a) && Math.abs(a - b) < (e || 1e-6), a + ' != ' + b);
    const hex4 = (n) => ('000' + (n & 0xFFFF).toString(16)).slice(-4);
    // replies scaled as the kit's app.json config.battery, values from its demo (live.js / main.js Demo):
    // 64 % charge, SOH 91, 352 V / -37.1 A (13 kW driving), 96 cells ~3.72 V (two weak), cells 21.4-23.9 C,
    // coolant 20.8 C, limits 165 A in / 330 A out, 12.45 V
    const cells = [];
    for (let i = 0; i < 96; i++) cells.push(3722 + (i % 5) - (i === 37 ? 16 : i === 70 ? 9 : 0));
    const CAR = {
        '7:DDBC': '62DDBC0280', '7:DD7B': '7F2231', '7:6335': '6263355B', '7:DDB4': '62DDB48980', '7:DD69': '62DD69FFFFF182',
        '7:DFA5': '62DFA5' + cells.map(hex4).join(''), '7:DDBF': '62DDBF0E7C0E8E', '7:DDC0': '62DDC0085C095608CA',
        '7:DD6C': '62DD6C0820', '7:DD7D': '62DD7D06720CE4', '18:F442': '62F44230A2',
    };
    const asked = [];
    const car = (map) => (addr, did) => {
        asked.push(did);
        return Promise.resolve(map[addr + ':' + did] ? Buffer.from(map[addr + ':' + did], 'hex') : null);
    };
    let b = new Battery(car(CAR));
    const r0 = await b.poll(0);
    near(r0.soc, 64); near(r0.v12, 12.45);
    assert.strictEqual(b.noHybrid, false); assert.strictEqual(b.st.hybrid, true);
    assert.strictEqual(await b.health(), 91); assert.strictEqual(b.pick.soh, 1);        // DD7B refused (NRC 31): 6335
    const p = await b.power(0);
    near(p.v, 352); near(p.a, -37.1); near(p.kw, 13.0592);                             // + = the battery gives power
    near((await new Battery(car(CAR), { powerSign: 1 }).power(0)).kw, -13.0592);
    const s = await b.slow();
    assert.strictEqual(s.cellV.cells.length, 96);
    near(s.cellV.min, 3.708); near(s.cellV.max, 3.726); assert.strictEqual(s.cellV.minAt, 38); assert.strictEqual(s.cellV.spreadMv, 18);
    near(s.cellT.min, 21.4); near(s.cellT.max, 23.9); near(s.cellT.avg, 22.5); near(s.coolant, 20.8);
    near(s.limits.chargeA, 165); near(s.limits.dischargeA, 330);
    const lk = limitsKw(s.limits, p.v); near(lk.in, 58.08); near(lk.out, 116.16);
    assert(asked.every((d) => /^([0-9A-F]{4}|OBD [0-9A-F]{2})$/.test(d)));                // 22 xxxx / OBD 01 only
    // decoding: signed temperatures, out of range, a wrong echo, a refusal
    near(decode(CONFIG.cellT[0], Buffer.from('62DDC0FDF3FE0CFDFF', 'hex')).min, -5.25);
    assert.strictEqual(decode(CONFIG.soc[0], Buffer.from('62DDBC0400', 'hex')), null);   // 102.4 %
    assert.strictEqual(decode(CONFIG.soc[0], Buffer.from('62DDBD0280', 'hex')), null);
    assert.strictEqual(decode(CONFIG.soc[0], Buffer.from('7F2231', 'hex')), null);
    assert.strictEqual(decode(CONFIG.soc[0], Buffer.from('62DDBC02', 'hex')), null);     // too short
    // no per-cell DID: DDBF's lowest / highest; v12 by OBD 42 when the engine unit refuses F442
    const other = Object.assign({}, CAR, { '7:DFA5': null, '18:F442': '7F2231', '18:OBD 42': '414230A2' });
    b = new Battery(car(other));
    const s2 = await b.slow();
    assert.strictEqual(s2.cellV.cells, undefined); near(s2.cellV.min, 3.708); assert.strictEqual(s2.cellV.spreadMv, 18);
    near((await b.poll(0)).v12, 12.45); assert.strictEqual(b.pick.v12, 2);
    // no hybrid system: the SME never answers, the engine unit does -> after 3 polls; then the SME every 5 min
    b = new Battery(car({ '18:F442': '62F44230A2' }));
    for (let i = 0; i < 2; i++) await b.poll(i * 1000);
    assert.strictEqual(b.noHybrid, false);
    await b.poll(2000);
    assert.strictEqual(b.noHybrid, true); assert.strictEqual(b.isHybrid('auto'), false); assert.strictEqual(b.isHybrid('yes'), true);
    asked.length = 0; await b.poll(3000); assert.strictEqual(asked.indexOf('DDBC'), -1);
    asked.length = 0; await b.poll(2000 + RETRY_MS + 1); assert(asked.indexOf('DDBC') >= 0);
    assert.deepStrictEqual(new Battery(null, null, JSON.parse(JSON.stringify(b))).noHybrid, true);
    // nothing answers at all: 6 polls
    b = new Battery(car({}));
    for (let i = 0; i < 5; i++) await b.poll(i * 1000);
    assert.strictEqual(b.noHybrid, false); await b.poll(5000); assert.strictEqual(b.noHybrid, true);
    // one refusal from the SME = a hybrid, for good
    b = new Battery(car({ '7:DDBC': '7F2222', '18:F442': '62F44230A2' }));
    for (let i = 0; i < 5; i++) await b.poll(i * 1000);
    assert.strictEqual(b.noHybrid, false); assert.strictEqual(b.st.hybrid, true);
    // a link error is not "no reply"
    b = new Battery(() => Promise.reject(new Error('link down')));
    for (let i = 0; i < 8; i++) await b.poll(i * 1000);
    assert.strictEqual(b.noHybrid, false);
    // this drive and the trace
    const d = new Drive(0);
    d.add(30, 0, true, 1.8);                    // first reading: nothing integrated yet
    d.add(36, 1000, true, 1.8);                 // 36 kW for 1 s, the climate 1.8 kW of it
    d.add(-18, 2000, true);                     // regen
    d.add(-7.2, 3000, false);                   // standing, plugged in
    d.add(3.6, 13000, false);                   // a 10 s gap counts as 6 s
    const t = d.totals();
    near(t.used, 0.016); near(t.regen, 0.005); near(t.net, 0.011); near(t.charged, 0.002); near(t.climate, 0.0005);
    near(t.driving, 0.0155); near(t.climateShare, 0.0005 / 0.016); assert.strictEqual(t.peakOut, 36); assert.strictEqual(t.peakIn, 18);
    d.add(1, 130000, false);
    assert.deepStrictEqual(d.trace.map((x) => x[0]), [13000, 130000]);                  // 2 minutes kept
    assert.deepStrictEqual([state(13, true), state(-11, true), state(1.5, false), state(-7, false), state(0.1, true)],
        ['DRIVING', 'REGEN', 'DRAWING', 'CHARGING', 'IDLE']);
    console.log('battery self-check ok: soc 64 %, soh 91 %, ' + p.v + ' V x ' + p.a + ' A = ' + p.kw.toFixed(2) + ' kW, cells '
        + s.cellV.min + '-' + s.cellV.max + ' V (' + s.cellV.spreadMv + ' mV), limits ' + lk.in.toFixed(1) + ' / ' + lk.out.toFixed(1) + ' kW');
}

module.exports = { Battery, Drive, CONFIG, decode, limitsKw, state, test };
if (require.main === module) test().catch((e) => { console.error(e); process.exit(1); });

// Ported from cauliflowermossgrape/idrive7-apps (MIT License, Copyright (c) 2026 cauliflowermossgrape): apps/edrive/range.js @ c67ea17.
'use strict';
/**
 * range.js - what this car uses on electric power, learned from its own driving (the kit's range.js), plus
 * from the kit's main.js: the stretch tracking between charge readings, the engine-start charge, the range
 * estimate (before learning: the outside-temperature curve with its low-high spread) and the battery size.
 * Pure: every time is passed in (ms), nothing is read or written here; persist toJSON(), load fromJSON().
 *
 *   driving:  % of charge per km (engine off, climate draw taken out), last LEARN_KM km - overall and per
 *             speed band (SPEED_BANDS); a band with little driving leans on the overall value.
 *   climate:  climate + on-board electrics, % per HOUR, per outside-temperature band (BANDS), learned from
 *             standing / creeping with the engine off and from driving with it on (above the same speed band
 *             with it off, st.driveOff); typical draw (AUX_KW) until learned. Off: on-board only (st.base,
 *             BASE_KW). With the A/C: its own bands (st.acAux), AUX_KW + AC_KW. climate = 'ac' / true / false /
 *             null (not known: as on) / 'mixed' (switched during a stretch: teaches nothing but the speed).
 *   engine:   with the engine running the whole stretch, the battery's own use per km (st.engineUse, negative
 *             = the engine charges it); never mixed into the electric values.
 *   comfort:  seat / steering-wheel heating (kW, estimated by the caller): taken out before learning, added back.
 *   speed:    typical speed of electric driving, stops in traffic included (up to STOP_H after moving).
 *
 *   const m = RangeModel.fromJSON(saved)
 *   m.onSpeed(kmh, now, engineOn); m.onRpm(rpm, now, kmh, socFresh) -> true: an engine start was learned (save)
 *   m.onClimate(c); m.onReading(soc, now, { ambient, kwhPerPct, comfortKw, charging })   every charge reading
 *   m.estimate(soc, tC, climate, pace, comfortKw, { designKwh, soh, range20, reserve }) -> range (see there)
 *   m.pace(now), m.reserve(setting), kwhPerPct(designKwh, soh), energy(soc, soh, designKwh), rangeAt(tC, range20)
 */
const LEARN_KM = 60;             // electric driving remembered for the use per km
const AUX_H = 2;                 // hours of climate draw remembered per temperature band
const SPEED_H = 3;               // hours of electric driving remembered for the typical speed
const BANDS = [-5, 5, 15, 25];   // outside-temperature bands (°C)
const STOP_H = 5 / 60;           // standing this long after moving still counts as a stop in traffic
const SPEED_BANDS = [35, 60, 85, 110];   // km/h: city / town / country / fast / motorway
const BAND_KM = 30;              // km remembered per speed band
const BAND_PRIOR_KM = 5;         // a band's own value counts fully from about this much driving in it
/** Typical climate control + on-board draw (kW) by outside temperature: [°C, kW]. */
const AUX_KW = [[-10, 3.0], [0, 2.2], [10, 1.0], [18, 0.5], [24, 0.5], [30, 1.2], [38, 2.0]];
/** Typical on-board draw (kW) with climate control off: control units, screens, pumps, fans. */
const BASE_KW = 0.3;
/** Typical extra draw (kW) of the A/C compressor by outside temperature: [°C, kW] (cold: dehumidifying). */
const AC_KW = [[0, 0.5], [10, 0.8], [18, 1.0], [25, 1.5], [35, 2.5]];
// with the engine on, the battery's own change per km is at most this (the engine charging hard in slow traffic
// is ~1.5 %/km); more comes from standing / creeping, where "per km" means nothing
const ENGINE_MAX_PCT_KM = 3;
/** Range of a full battery by outside temperature for a car doing 50 km at 20 °C: [°C, low km, high km]. */
const RANGE_CURVE = [[-10, 20, 30], [0, 30, 38], [10, 40, 45], [20, 50, 50]];
const RESERVE = 8;               // engine-start charge (%) until two engine starts have been seen
// low battery: the car holds the charge at about 5-11 % and drives as a hybrid; nothing there teaches the range
const HOLD_TOP = 11;
const READ_GAP_H = 2 / 60;       // readings further apart than this: the car was off meanwhile, nothing learned
const PACE_TAU = 300;            // s: the pace follows the last few minutes of electric driving
const PACE_KEEP = 15 * 60000;    // ms without moving after which there is no "current pace"
const STOP_MS = 5 * 60000;       // standing longer than this is parking, not traffic: the pace stops
const DEFAULTS = { designKwh: 12, soh: null, range20: 50, reserve: 'auto' };   // the kit's settings defaults

const isNum = (v) => typeof v === 'number' && isFinite(v);
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const speedBandOf = (kmh) => { let i = 0; while (i < SPEED_BANDS.length && kmh >= SPEED_BANDS[i]) i++; return 'v' + i; };
const bandOf = (tC) => { let i = 0; while (i < BANDS.length && tC >= BANDS[i]) i++; return 'b' + i; };
const fade = (o, k, max) => { if (o[k] > max) { const f = max / o[k]; Object.keys(o).forEach((x) => { o[x] *= f; }); } };

function curve(c, tC) {
    const t = clamp(isNum(tC) ? tC : 15, c[0][0], c[c.length - 1][0]);
    let i = 0;
    while (i < c.length - 2 && t > c[i + 1][0]) i++;
    const f = (t - c[i][0]) / (c[i + 1][0] - c[i][0]);
    return c[i][1] + (c[i + 1][1] - c[i][1]) * f;
}
const auxKwTypical = (tC) => curve(AUX_KW, tC);
const acKwTypical = (tC) => curve(AC_KW, tC);

/** kWh in 1 % of charge today: size when new (gross, setting) x health (no health read yet: 100 %). */
const kwhPerPct = (designKwh, soh) => designKwh * (isNum(soh) ? soh : 100) / 100 / 100;
/** What a full charge holds today and what is in the battery now (kWh). */
const energy = (soc, soh, designKwh) => {
    const holds = isNum(soh) ? designKwh * soh / 100 : null;
    return { holds: holds, now: isNum(holds) && isNum(soc) ? holds * soc / 100 : null };
};

/**
 * Range of a full battery at tC: { lo, hi, mid } km (no temperature: 10 °C). Warmer than 20 °C counts as 20;
 * colder than -10 continues the -10..0 slope (not below 15 / 18 km). Scaled by range20 (range when full at 20 °C).
 */
function rangeAt(tC, range20) {
    const k = (isNum(range20) ? range20 : DEFAULTS.range20) / 50, c = RANGE_CURVE, t = isNum(tC) ? tC : 10;
    let lo, hi;
    if (t >= c[c.length - 1][0]) { lo = c[c.length - 1][1]; hi = c[c.length - 1][2]; }
    else if (t <= c[0][0]) {
        const d = c[0][0] - t, sl = (c[1][1] - c[0][1]) / (c[1][0] - c[0][0]), sh = (c[1][2] - c[0][2]) / (c[1][0] - c[0][0]);
        lo = Math.max(15, c[0][1] - sl * d); hi = Math.max(18, c[0][2] - sh * d);
    } else {
        let i = 0;
        while (t > c[i + 1][0]) i++;
        const f = (t - c[i][0]) / (c[i + 1][0] - c[i][0]);
        lo = c[i][1] + (c[i + 1][1] - c[i][1]) * f; hi = c[i][2] + (c[i + 1][2] - c[i][2]) * f;
    }
    return { lo: lo * k, hi: hi * k, mid: (lo + hi) / 2 * k };
}

class RangeModel {
    constructor(st) {
        this.st = st || {}; this.stoodH = Infinity;
        // learned before kit 2.1: stretches of standing with the engine charging counted too (e.g. +18 %/km)
        const A = this.st.engineAll;
        if (A && A.km > 0 && Math.abs(A.pct / A.km) > ENGINE_MAX_PCT_KM) { delete this.st.engineAll; delete this.st.engineUse; }
        // not persisted: the stretch since the last charge reading, the pace
        this.seg = { km: 0, engine: false, engineAll: false, climate: null, climateMixed: false, comfort: 0 };
        this.prevSoc = null; this.prevT = null; this.speedT = null; this.lastMove = null; this.paceKmh = null;
        this.rpmNow = null; this.rpmT = null; this.climateNow = null;
    }
    static fromJSON(o) { return new RangeModel(o ? JSON.parse(JSON.stringify(o)) : {}); }
    toJSON() { return this.st; }

    /* ---------- the stretch between two charge readings (kit main.js onSpeed / onRpm / onSoc) ---------- */
    onSpeed(kmh, now, engineOn) {
        if (this.speedT !== null && isNum(kmh)) {
            const dt = clamp(now - this.speedT, 0, 2000);
            this.seg.km += kmh * dt / 3600000;
            // the pace: the last few minutes of ELECTRIC driving, stops in traffic included
            if (kmh > 3 && !engineOn) this.lastMove = now;
            if (!engineOn && this.lastMove !== null && now - this.lastMove < STOP_MS) {
                this.paceKmh = this.paceKmh === null ? kmh : this.paceKmh + (kmh - this.paceKmh) * (dt / 1000) / (dt / 1000 + PACE_TAU);
            }
        }
        this.speedT = now;
    }
    /** Current pace (km/h) or null after PACE_KEEP without electric driving (the typical speed is used then). */
    pace(now) { return this.paceKmh !== null && this.lastMove !== null && now - this.lastMove < PACE_KEEP ? this.paceKmh : null; }
    /**
     * Engine speed. An engine start while driving at a low charge (socFresh: a reading from the last minute,
     * <= 20 % and above the hold zone) is where this car stops driving electric: returns true (save the state).
     */
    onRpm(rpm, now, kmh, socFresh) {
        const was = this.rpmNow;
        this.rpmNow = rpm; this.rpmT = now;
        if (rpm > 400) this.seg.engine = true;
        else if (rpm < 300) this.seg.engineAll = false;      // the engine stopped at some point in the stretch
        if (isNum(was) && was < 300 && rpm > 600 && isNum(kmh) && kmh > 3 && isNum(socFresh) && socFresh <= 20 && socFresh > HOLD_TOP) {
            this.st.engineStarts = (this.st.engineStarts || []).concat([Math.round(socFresh * 10) / 10]).slice(-5);
            return true;
        }
        return false;
    }
    /** Climate now ('ac' / true / false; null = not known): a switch during a stretch makes it 'mixed'. */
    onClimate(c) {
        if (c === null || c === undefined) return;
        if (this.climateNow !== null && c !== this.climateNow) this.seg.climateMixed = true;
        this.climateNow = c;
    }
    /**
     * A charge reading. The stretch since the last one, if the readings are close (car on), the rpm signal is
     * live (car awake), no charge session is open (o.charging, from chargelog.js before its own reading) and
     * the charge is above the hold zone: engine off throughout teaches learn(), engine on throughout learnEngine().
     */
    onReading(soc, now, o) {
        o = o || {};
        const prev = this.prevSoc, s = this.seg, comfort = isNum(o.comfortKw) ? o.comfortKw : 0;
        if (isNum(prev) && isNum(soc) && (now - this.prevT) / 3600000 < READ_GAP_H && this.rpmT !== null && now - this.rpmT < 5000
            && !o.charging && Math.min(prev, soc) > HOLD_TOP + 1) {
            const h = (now - this.prevT) / 3600000;
            if (!s.engine) this.learn(prev - soc, h, s.km, o.ambient, o.kwhPerPct, s.climateMixed ? 'mixed' : s.climate, (s.comfort + comfort) / 2);
            else if (s.engineAll) this.learnEngine(prev - soc, h, s.km);
        }
        s.km = 0; s.engine = isNum(this.rpmNow) && this.rpmNow > 400; s.engineAll = s.engine;
        s.climate = this.climateNow; s.climateMixed = false; s.comfort = comfort;
        this.prevSoc = soc; this.prevT = now;
    }
    /** Charge at which the engine starts: the setting ('auto' / a number), or the median of the engine starts seen. */
    reserve(setting) {
        if (setting != null && setting !== 'auto' && isFinite(+setting)) return +setting;
        const e = (this.st.engineStarts || []).filter((x) => x > HOLD_TOP).sort((a, b) => a - b);
        return Math.max(HOLD_TOP, e.length >= 2 ? e[Math.floor(e.length / 2)] : RESERVE);
    }

    /* ---------- the kit's range.js ---------- */
    /** % per km for driving alone, once there is enough (>= 5 km and 2 %); per speed band leaning on the overall. */
    drivePctPerKm(kmh) {
        const L = this.st.learn;
        if (!L || L.km < 5 || L.pct < 2) return null;
        const a = L.pct / L.km;
        if (!(a > 0.2 && a < 10)) return null;
        const b = isNum(kmh) && kmh > 3 && this.st.drive && this.st.drive[speedBandOf(kmh)];
        if (!b || !(b.km > 0.5)) return a;
        const own = b.pct / b.km;
        if (!(own > 0.1 && own < 15)) return a;
        const w = b.km / (b.km + BAND_PRIOR_KM);
        return own * w + a * (1 - w);
    }
    /** The same, from driving with the climate OFF only (the yardstick for the climate's draw while driving). */
    driveOffPctPerKm(kmh) {
        const b = this.st.driveOff && this.st.driveOff[speedBandOf(kmh)];
        if (!b || b.km < 3) return null;
        const a = b.pct / b.km;
        return a > 0.1 && a < 15 ? a : null;
    }
    /** Per speed band: [{ band, from, to, km, pctPerKm, engineKm, enginePctPerKm }]. */
    bands() {
        const edges = [0].concat(SPEED_BANDS, [null]);
        return edges.slice(0, -1).map((from, i) => {
            const b = this.st.drive && this.st.drive['v' + i], e = this.st.engineUse && this.st.engineUse['v' + i];
            return { band: 'v' + i, from: from, to: edges[i + 1], km: b ? b.km : 0, pctPerKm: b && b.km > 0.5 ? b.pct / b.km : null,
                engineKm: e ? e.km : 0, enginePctPerKm: e && e.km > 1 ? e.pct / e.km : null };
        });
    }
    /** A stretch with the engine running throughout: the battery's use (%, negative = charged) over km. */
    learnEngine(used, h, km) {
        if (!isNum(used) || !(h > 0) || km < 0.3 || km / h < 10 || Math.abs(used / km) > ENGINE_MAX_PCT_KM) return;
        const E = this.st.engineUse || (this.st.engineUse = {}), band = speedBandOf(km / h);
        const b = E[band] || (E[band] = { km: 0, pct: 0 });
        b.km += km; b.pct += used;
        fade(b, 'km', BAND_KM);
        const A = this.st.engineAll || (this.st.engineAll = { km: 0, pct: 0 });
        A.km += km; A.pct += used;
        fade(A, 'km', LEARN_KM);
    }
    /** Battery use with the engine on at kmh: % per km (negative = charging), or null until learned. */
    enginePctPerKm(kmh) {
        const A = this.st.engineAll;
        if (!A || A.km < 2) return null;
        const all = A.pct / A.km, b = isNum(kmh) && this.st.engineUse && this.st.engineUse[speedBandOf(kmh)];
        if (!b || !(b.km > 0.5)) return all;
        const w = b.km / (b.km + BAND_PRIOR_KM);
        return (b.pct / b.km) * w + all * (1 - w);
    }
    /** Climate + on-board draw at tC: { rate (% per hour), learned, climate }; false = on-board only. */
    auxRate(tC, k, climate) {
        if (climate === false) {
            const typ = BASE_KW / k, b = this.st.base;
            if (!b || b.h < 0.25) return { rate: typ, learned: false, climate: climate };
            const w = Math.min(1, b.h), own = Math.max(0, b.pct / b.h);
            return { rate: own * w + typ * (1 - w), learned: true, climate: climate };
        }
        const ac = climate === 'ac', bands = ac ? this.st.acAux : this.st.aux;
        const typ = (auxKwTypical(tC) + (ac ? acKwTypical(tC) : 0)) / k;
        const b = isNum(tC) && bands && bands[bandOf(tC)];
        if (!b || b.h < 0.25) return { rate: typ, learned: false, climate: climate };
        const w = Math.min(1, b.h), own = Math.max(0, b.pct / b.h);
        return { rate: own * w + typ * (1 - w), learned: true, climate: climate };
    }
    /** The climate's own draw (kW) above the on-board electrics (this drive's "to climate" when nothing better is known). */
    climateKw(tC, k, climate) {
        if (climate === false || climate == null) return 0;
        return Math.max(0, (this.auxRate(tC, k, climate).rate - this.auxRate(tC, k, false).rate) * k);
    }
    /** Typical speed of electric driving in km/h (35 until there is 6 minutes of it). */
    evSpeed() {
        const v = this.st.evSpeed;
        return v && v.h >= 0.1 ? clamp(v.km / v.h, 12, 110) : 35;
    }
    /** One stretch with the engine off throughout: used % (regen makes it smaller) over h hours and km at tC. */
    learn(used, h, km, tC, k, climate, comfortKw) {
        if (!isNum(used) || !(h > 0)) return;
        const st = this.st, mixed = climate === 'mixed';
        if (isNum(comfortKw) && comfortKw > 0 && k > 0) used -= comfortKw * h / k;
        if (km < 0.05) {
            if (used <= -0.05 || (!isNum(tC) && climate !== false)) return;  // charge rising: not a draw
            if (!mixed) {
                let b;
                if (climate === false) b = st.base || (st.base = { h: 0, pct: 0 });
                else {
                    const key = climate === 'ac' ? 'acAux' : 'aux', bands = st[key] || (st[key] = {});
                    b = bands[bandOf(tC)] || (bands[bandOf(tC)] = { h: 0, pct: 0 });
                }
                b.h += h; b.pct += used;
                fade(b, 'h', AUX_H);
            }
            // a stop in traffic is part of the trip's time (its climate draw is too); parking is not
            this.stoodH += h;
            if (this.stoodH <= STOP_H && st.evSpeed) { st.evSpeed.h += h; fade(st.evSpeed, 'h', SPEED_H); }
            return;
        }
        this.stoodH = 0;
        if (!mixed) {
            const net = used - this.auxRate(tC, k, climate).rate * h, band = speedBandOf(km / h);
            const L = st.learn || (st.learn = { km: 0, pct: 0 });
            L.km += km; L.pct += net;
            fade(L, 'km', LEARN_KM);
            const D = st.drive || (st.drive = {}), b = D[band] || (D[band] = { km: 0, pct: 0 });
            b.km += km; b.pct += net;
            fade(b, 'km', BAND_KM);
            if (climate === false) {
                const O = st.driveOff || (st.driveOff = {}), o = O[band] || (O[band] = { km: 0, pct: 0 });
                o.km += km; o.pct += net;
                fade(o, 'km', BAND_KM);
            } else if ((climate === true || climate === 'ac') && isNum(tC)) {
                // climate on while driving: what it used above that yardstick is the climate (+ on-board) draw
                const off = this.driveOffPctPerKm(km / h);
                if (off !== null) {
                    const key = climate === 'ac' ? 'acAux' : 'aux', bands = st[key] || (st[key] = {});
                    const c = bands[bandOf(tC)] || (bands[bandOf(tC)] = { h: 0, pct: 0 });
                    c.h += h; c.pct += Math.max(0, used - off * km);
                    fade(c, 'h', AUX_H);
                }
            }
        }
        const v = st.evSpeed || (st.evSpeed = { km: 0, h: 0 });
        v.km += km; v.h += h;
        fade(v, 'h', SPEED_H);
    }
    /** Learned range for `use` % at tC: { kpp, mid, noAux, climateKm, comfortKm, aux, pace, perKm }, or null before driving is learned. */
    range(use, tC, k, climate, pace, comfortKw) {
        const v = isNum(pace) && pace > 3 ? clamp(pace, 8, 150) : this.evSpeed();
        const a = this.drivePctPerKm(v);
        if (!a) return null;
        const aux = this.auxRate(tC, k, climate), off = this.auxRate(tC, k, false);
        const comfort = isNum(comfortKw) && comfortKw > 0 ? comfortKw / k : 0;
        const kppAt = (auxRate, c) => 1 / (a + (auxRate + c) / v);
        const kpp = kppAt(aux.rate, comfort);
        const r = (x) => (isNum(use) ? use * x : null);
        return {
            kpp: kpp, mid: r(kpp), noAux: isNum(use) ? use / a : null, aux: aux, pace: v, perKm: a,
            climateKm: climate === false || !isNum(use) ? 0 : Math.max(0, r(kppAt(off.rate, comfort)) - r(kpp)),
            comfortKm: isNum(use) ? r(kppAt(aux.rate, 0)) - r(kpp) : null,
        };
    }

    /**
     * Electric range at charge soc (only the charge above the engine-start point counts): { mid, lo, hi (km),
     * kpp (km per %), learned, learnedKm, res (engine-start %), full (range when full), held (low-battery hybrid
     * zone), auxKw, auxLearned, auxKm, climateKm, comfortKm, pace, perKm }. Learned: +-10 %; before that the
     * outside-temperature curve's low-high (it already holds typical climate use; off gives that back, the
     * A/C costs on top). o: { designKwh, soh, range20, reserve } (the settings; DEFAULTS).
     */
    estimate(soc, tC, climate, pace, comfort, o) {
        o = Object.assign({}, DEFAULTS, o);
        const res = this.reserve(o.reserve), span = Math.max(1, 100 - res), use = isNum(soc) ? Math.max(0, soc - res) : null;
        const k = kwhPerPct(o.designKwh, o.soh), m = this.range(use, tC, k, climate, pace, comfort), aux = m ? m.aux : this.auxRate(tC, k, climate);
        const base = { res: res, auxKw: aux.rate * k, auxLearned: aux.learned, climate: climate, comfortKw: comfort || 0,
            held: isNum(soc) && soc <= HOLD_TOP + 0.5, learnedKm: this.st.learn ? this.st.learn.km : 0 };
        if (m) {
            return Object.assign(base, {
                mid: m.mid, lo: use === null ? null : m.mid * 0.9, hi: use === null ? null : m.mid * 1.1,
                kpp: m.kpp, learned: true, full: m.kpp * span, auxKm: use === null ? null : m.noAux - m.mid,
                climateKm: m.climateKm, comfortKm: m.comfortKm, pace: m.pace, perKm: m.perKm,
            });
        }
        const r = rangeAt(tC, o.range20);
        let f = 1;
        if (climate === false) {
            const onPerKm = span / r.mid, climPerKm = (this.auxRate(tC, k).rate - aux.rate) / this.evSpeed();
            f = onPerKm / Math.max(onPerKm * 0.5, onPerKm - Math.max(0, climPerKm));
        } else if (climate === 'ac') {
            const onPerKm = span / r.mid, acPerKm = (aux.rate - this.auxRate(tC, k, true).rate) / this.evSpeed();
            f = onPerKm / (onPerKm + Math.max(0, acPerKm));
        }
        const kpp = r.mid / span * f;
        return Object.assign(base, {
            mid: use === null ? null : use * kpp, lo: use === null ? null : use * r.lo / span * f, hi: use === null ? null : use * r.hi / span * f,
            kpp: kpp, learned: false, full: kpp * span, auxKm: null, pace: isNum(pace) ? pace : this.evSpeed(),
        });
    }
}

function test() {
    const assert = require('assert');
    const near = (a, b, e) => assert(isNum(a) && Math.abs(a - b) < (e || 1e-6), a + ' != ' + b);
    // before any driving: the temperature curve, kit defaults (50 km at 20 °C, 12 kWh, engine starts at 11 %)
    let m = RangeModel.fromJSON(null);
    let e = m.estimate(61, 20, null, null, 0);
    assert.strictEqual(e.learned, false); assert.strictEqual(e.res, 11);
    near(e.mid, 50 * 50 / 89); near(e.full, 50);
    e = m.estimate(61, 0, null, null, 0);
    near(e.lo, 50 * 30 / 89); near(e.hi, 50 * 38 / 89);                                   // 0 °C: 30-38 km when full
    assert.deepStrictEqual(rangeAt(-20), { lo: 15, hi: 22, mid: 18.5 });
    assert.deepStrictEqual(rangeAt(30, 100), { lo: 100, hi: 100, mid: 100 });
    near(rangeAt(null).mid, 42.5);                                                       // no temperature: 10 °C
    assert(m.estimate(61, 10, false, null, 0).mid > m.estimate(61, 10, true, null, 0).mid);   // climate off: more
    assert(m.estimate(61, 10, 'ac', null, 0).mid < m.estimate(61, 10, true, null, 0).mid);
    assert.strictEqual(m.estimate(11, 10, null).held, true);
    // battery size and health
    near(kwhPerPct(12, 91.5), 0.1098); near(kwhPerPct(12), 0.12);
    const en = energy(64, 91.5, 12); near(en.holds, 10.98); near(en.now, 7.0272);
    assert.deepStrictEqual(energy(64, null, 12), { holds: null, now: null });
    // 12 km electric at 72 km/h, climate off, 10 °C: speed every 1 s, a charge reading every 15 s using
    // 0.5 %/km + the typical on-board draw (0.3 kW = 2.5 %/h of 12 kWh)
    const k = 0.12, drop = 0.5 * 0.3 + 2.5 * 15 / 3600;
    m.onClimate(false);
    for (let t = 0; t <= 600000; t += 1000) {
        m.onSpeed(72, t, false); m.onRpm(0, t, 72, null);
        if (t % 15000 === 0) m.onReading(80 - (t / 15000) * drop, t, { ambient: 10, kwhPerPct: k, charging: false });
    }
    near(m.st.learn.km, 12); near(m.st.learn.pct, 6); near(m.drivePctPerKm(72), 0.5); near(m.evSpeed(), 72);
    near(m.bands()[2].km, 12); near(m.st.driveOff.v2.km, 12);                            // all in the 60-85 band
    near(m.pace(600000), 72); assert.strictEqual(m.pace(600000 + 16 * 60000), null);
    e = m.estimate(61, 10, false, 72, 0, { designKwh: 12 });
    assert.strictEqual(e.learned, true);
    near(e.kpp, 1 / (0.5 + 2.5 / 72)); near(e.mid, 50 * e.kpp); near(e.lo, e.mid * 0.9); near(e.hi, e.mid * 1.1); near(e.full, 89 * e.kpp);
    const on = m.estimate(61, 10, true, 72, 0);                                           // climate on: typical 1.0 kW at 10 °C
    near(on.kpp, 1 / (0.5 + (1.0 / k) / 72)); near(on.climateKm, e.mid - on.mid);
    near(m.estimate(61, 10, true, 72, 0.2).comfortKm, 50 / (0.5 + (1.0 / k) / 72) - 50 / (0.5 + (1.2 / k) / 72));
    near(m.climateKw(10, k, true), 0.7); assert.strictEqual(m.climateKw(10, k, false), 0);
    // readings 10 min apart (car off), during a charge session, or in the hold zone teach nothing
    const before = JSON.stringify(m.st);
    m.onReading(60, 2000000, { ambient: 10, kwhPerPct: k });
    m.onSpeed(60, 2001000, false); m.onRpm(0, 2001000); m.onReading(59.5, 2010000, { ambient: 10, kwhPerPct: k, charging: true });
    m.onSpeed(60, 2011000, false); m.onRpm(0, 2011000); m.onReading(11.5, 2020000, { ambient: 10, kwhPerPct: k });
    m.onRpm(0, 2021000); m.onReading(11, 2030000, { ambient: 10, kwhPerPct: k });
    assert.strictEqual(JSON.stringify(m.st), before);
    // standing with the climate on teaches its draw per temperature band
    m.learn(0.2, 0.3, 0, 0, k, true);
    const a = m.auxRate(0, k, true);
    assert.strictEqual(a.learned, true); near(a.rate, (0.2 / 0.3) * 0.3 + (2.2 / k) * 0.7);
    // engine on throughout: kept apart (negative = the engine charged it)
    m.learnEngine(-0.5, 0.1, 5); near(m.enginePctPerKm(50), -0.1);
    // engine starts while driving at a low charge -> the engine-start charge
    assert.strictEqual(m.onRpm(800, 3000000, 30, 15), true);
    m.onRpm(0, 3001000); assert.strictEqual(m.reserve('auto'), 11);                     // one start: still the default
    m.onRpm(900, 3002000, 30, 14); assert.strictEqual(m.reserve('auto'), 15);
    assert.strictEqual(m.reserve('8'), 8);
    assert.strictEqual(m.onRpm(900, 3003000, 30, 14), false);                           // no start (already running)
    // persisted and loaded: the same range
    const m2 = RangeModel.fromJSON(JSON.parse(JSON.stringify(m)));
    assert.deepStrictEqual(m2.estimate(61, 10, false, 72, 0), m.estimate(61, 10, false, 72, 0));
    // an old state with standing counted as driving (kit < 2.1) is dropped
    assert.strictEqual(new RangeModel({ engineAll: { km: 1, pct: 18 }, engineUse: {} }).st.engineAll, undefined);
    const u = RangeModel.fromJSON(null).estimate(61, 0, null);
    console.log('range self-check ok: 61 %, unlearned ' + u.lo.toFixed(1) + '-' + u.hi.toFixed(1) + ' km at 0 C, learned '
        + e.mid.toFixed(1) + ' km (' + e.lo.toFixed(1) + '-' + e.hi.toFixed(1) + '), climate on ' + on.mid.toFixed(1)
        + ' km, full ' + e.full.toFixed(1) + ' km');
}

module.exports = { RangeModel, rangeAt, kwhPerPct, energy, auxKwTypical, acKwTypical, bandOf, speedBandOf, HOLD_TOP,
    LEARN_KM, AUX_KW, BASE_KW, AC_KW, SPEED_BANDS, RANGE_CURVE, DEFAULTS, test };
if (require.main === module) test();

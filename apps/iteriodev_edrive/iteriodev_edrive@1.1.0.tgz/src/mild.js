'use strict';
/**
 * mild.js - a 48 V mild hybrid's 48 V battery (BATT48, diagnostic address 0x02) and DC/DC converter (PCU48, 0x54),
 * read-only. Idea and DIDs from jezikk82's patch to cauliflowermossgrape/idrive7-apps (Live Data 1.0.6 Energy tab,
 * issue #74, MIT); the layouts checked against our own BATT48 / PCU48 SGBDs (RES_0xAA56_D, RES_0xDA90_D,
 * TAB_IST_BETRIEBSZUSTAND_PCU48). Not yet confirmed on a car.
 *
 *   read(addr, did) -> Promise of Buffer (the whole reply) or null when the unit did not answer; throws: no link.
 *   Only 22 F1 50 (which unit, by its SGBD index), 22 AA56 and 22 DA90 are ever asked.
 *
 *   const m = new Mild(read)
 *   await m.identify(now)   which units are there (once; every 5 min again while neither answers)
 *   m.done, m.found()       identified; a known 48 V unit at 0x02 or 0x54
 *   m.batt, m.pcu           { addr, index, sgbd, ok } or null; ok = this app reads its values
 *   await m.poll(now)       -> { batt, pcu } decoded (each null: not supported, no answer); m.trace = 2 min of kW
 *   MODES[n]                the converter's reported mode
 */
const isNum = (v) => typeof v === 'number' && isFinite(v);

const RETRY_MS = 300000;           // neither unit answered: asked again every 5 min
const TRACE_MS = 120000;
// "<address> <SGBD index>" -> SGBD, the 48 V entries of ISTA's assignment table (Fault Codes' sgbd_index.json):
// 0x02 is the steering column switch (SZL_01, 0F1280) on cars without 48 V, so the unit is told by its index
const UNITS = {
    0x02: { '0F2810': 'BATT48', '0F2B50': 'BAT48FAR', '0F2FF0': 'BAT48_15', '0F2E80': 'SC48_01', '0F35D0': 'SC48_01' },
    0x54: { '0F2720': 'PCU48', '0F2C00': 'PCU48_2', '0F34E0': 'PCU48_2' },
};
const READS = { BATT48: 'AA56', PCU48: 'DA90' };       // the SGBDs whose layout this app has

// [field, at (bytes after the echo), bytes, signed, divisor, min, max]: big-endian, outside min..max = null
const AA56 = [['v', 0, 2, false, 100, 0, 70], ['a', 2, 2, true, 10, -1500, 1500], ['t', 4, 2, true, 2, -40, 100],
    ['soc', 14, 1, false, 1, 0, 100], ['socQ', 15, 1, false, 1, 0, 100], ['pack', 16, 2, false, 100, 0, 70],
    ['nomAh', 18, 1, false, 10, 0.1, 25.5], ['fullAh', 22, 1, false, 10, 0.1, 25.5], ['nowAh', 23, 1, false, 10, 0, 25.5],
    ['soh', 26, 1, false, 1, 0, 110]];
const DA90 = [['v12', 0, 2, false, 1000, 0, 20], ['v48', 2, 2, false, 1000, 0, 70], ['a12', 4, 2, true, 10, -1000, 1000],
    ['a48', 6, 2, true, 10, -1000, 1000], ['w12', 8, 2, true, 1, -10000, 10000], ['w48', 10, 2, true, 1, -10000, 10000],
    ['mode', 12, 1, false, 1, 0, 255]];
const MODES = { 3: 'Passive standby', 5: 'Error', 6: 'Precharge', 8: 'Active standby', 9: '48 V → 12 V', 10: '12 V → 48 V',
    11: 'Diagnostic standby', 12: 'Emergency mode', 13: 'Crash', 14: 'Diagnostic boost', 15: 'Diagnostic buck', 255: 'Invalid' };

/** 62 <did> <data> -> { field: value } (null where outside its range or past the end), else null. */
function decode(layout, did, buf) {
    const id = parseInt(did, 16);
    if (!buf || buf.length < 4 || buf[0] !== 0x62 || buf[1] * 256 + buf[2] !== id) return null;
    const out = {};
    layout.forEach((f) => {
        const at = 3 + f[1], n = f[2];
        let raw = null;
        if (buf.length >= at + n) {
            raw = n === 2 ? buf[at] * 256 + buf[at + 1] : buf[at];
            if (f[3] && raw >= Math.pow(2, 8 * n - 1)) raw -= Math.pow(2, 8 * n);
        }
        const v = raw === null ? null : raw / f[4];
        out[f[0]] = v === null || v < f[5] || v > f[6] ? null : v;
    });
    return out;
}
/** 62 F1 50 <3 bytes> -> "0F2810", else null */
const indexOf = (buf) => (buf && buf.length >= 6 && buf[0] === 0x62 && buf[1] === 0xF1 && buf[2] === 0x50
    ? ('00000' + ((buf[3] << 16) | (buf[4] << 8) | buf[5]).toString(16).toUpperCase()).slice(-6) : null);

class Mild {
    constructor(read) {
        this.read = read;
        this.batt = null; this.pcu = null; this.done = false; this.next = -Infinity;
        this.heard = { 2: false, 84: false };      // each address once it answered (a refusal too)
        this.trace = []; this.last = { batt: null, pcu: null };
    }
    found() { return !!(this.batt || this.pcu); }
    due(now) { return !this.done && now >= this.next; }
    /** a unit's name for Diagnostics: its SGBD once told, else its address */
    label(addr) { const u = addr === 0x02 ? this.batt : this.pcu; return u ? u.sgbd : addr === 0x02 ? '0x02' : '0x54'; }

    /**
     * 22 F1 50 to the addresses that have not answered yet. Settled once both answered, or once 0x02 answered with no
     * 48 V unit anywhere (a car without 48 V). One 48 V unit known, the other silent: asked again in 30 s, nothing
     * known: in 5 min, a link error: in 30 s.
     */
    async identify(now) {
        for (const addr of [0x02, 0x54]) {
            if (this.heard[addr]) continue;
            let buf;
            try { buf = await this.read(addr, 'F150'); } catch (e) { this.next = now + 30000; return; }
            if (!buf) continue;
            this.heard[addr] = true;
            const index = indexOf(buf), sgbd = index && UNITS[addr][index];
            const unit = sgbd ? { addr, index, sgbd, ok: !!READS[sgbd] } : null;
            if (addr === 0x02) this.batt = unit; else this.pcu = unit;
        }
        this.done = (this.heard[2] && this.heard[84]) || (this.heard[2] && !this.found());
        this.next = now + (this.found() ? 30000 : RETRY_MS);
    }

    /** The supported units' values; a battery reading adds to the 2-minute power trace (kW, + = the battery gives). */
    async poll(now) {
        const out = { batt: null, pcu: null };
        if (this.batt && this.batt.ok) out.batt = decode(AA56, 'AA56', await this.read(0x02, 'AA56'));
        if (this.pcu && this.pcu.ok) out.pcu = decode(DA90, 'DA90', await this.read(0x54, 'DA90'));
        const b = out.batt;
        if (b) b.kw = isNum(b.v) && isNum(b.a) ? b.v * b.a / 1000 : null;   // negative current = charging (the SGBD)
        if (b && isNum(b.kw)) this.trace.push([now, b.kw]);
        this.last = out;
        return out;
    }
    /** the trace's last 2 minutes (a silent battery: it runs empty) */
    points(now) {
        while (this.trace.length && now - this.trace[0][0] > TRACE_MS) this.trace.shift();
        return this.trace.map((x) => x[1]);
    }
}

async function test() {
    const assert = require('assert');
    const near = (a, b) => assert(isNum(a) && Math.abs(a - b) < 1e-9, a + ' != ' + b);
    // the replies of the upstream test (kit/tools/test_live_data.js @ 990c105)
    const batt = Buffer.alloc(28);
    batt.writeUInt16BE(4850, 0); batt.writeInt16BE(-125, 2); batt.writeInt16BE(50, 4);
    batt[14] = 76; batt[15] = 95; batt.writeUInt16BE(4860, 16); batt[18] = 100; batt[22] = 95; batt[23] = 90; batt[26] = 92;
    const pcu = Buffer.alloc(13);
    pcu.writeUInt16BE(14200, 0); pcu.writeUInt16BE(48500, 2); pcu.writeInt16BE(-123, 4); pcu.writeInt16BE(45, 6);
    pcu.writeInt16BE(-175, 8); pcu.writeInt16BE(218, 10); pcu[12] = 9;
    const reply = (did, data) => Buffer.concat([Buffer.from('62' + did, 'hex'), data]);
    const b = decode(AA56, 'AA56', reply('AA56', batt));
    assert.deepStrictEqual([b.v, b.a, b.t, b.soc, b.socQ, b.pack, b.nomAh, b.fullAh, b.nowAh, b.soh], [48.5, -12.5, 25, 76, 95, 48.6, 10, 9.5, 9, 92]);
    const p = decode(DA90, 'DA90', reply('DA90', pcu));
    assert.deepStrictEqual([p.v12, p.v48, p.a12, p.a48, p.w12, p.w48, p.mode], [14.2, 48.5, -12.3, 4.5, -175, 218, 9]);
    assert.deepStrictEqual([MODES[9], MODES[10], MODES[11], MODES[99]], ['48 V → 12 V', '12 V → 48 V', 'Diagnostic standby', undefined]);
    // too short: the missing fields null; a wrong echo, a refusal: nothing; 0xFF SOC: out of range
    const short = decode(DA90, 'DA90', Buffer.from('62DA9037', 'hex'));
    assert.deepStrictEqual([short.v12, short.mode], [null, null]);
    assert.strictEqual(decode(DA90, 'DA90', reply('DA91', pcu)), null);
    assert.strictEqual(decode(AA56, 'AA56', Buffer.from('7F2231', 'hex')), null);
    batt[14] = 0xFF; assert.strictEqual(decode(AA56, 'AA56', reply('AA56', batt)).soc, null); batt[14] = 76;
    // identify: by the SGBD index; 0x02 as the steering column switch is no 48 V unit; PCU48_2 found, not read
    const asked = [];
    const car = (map) => (addr, did) => { asked.push(addr + ':' + did); const v = map[addr + ':' + did]; return Promise.resolve(v ? Buffer.from(v, 'hex') : null); };
    const CAR = { '2:F150': '62F1500F2810', '84:F150': '62F1500F2720', '2:AA56': reply('AA56', batt).toString('hex'), '84:DA90': reply('DA90', pcu).toString('hex') };
    let m = new Mild(car(CAR));
    assert(m.due(0)); await m.identify(0);
    assert.deepStrictEqual([m.done, m.found(), m.batt.sgbd, m.batt.ok, m.pcu.sgbd, m.pcu.ok], [true, true, 'BATT48', true, 'PCU48', true]);
    const r = await m.poll(1000);
    near(r.batt.kw, -0.60625); near(r.pcu.v48, 48.5); assert.deepStrictEqual(m.points(1000), [r.batt.kw]);
    assert.deepStrictEqual([m.label(0x02), m.label(0x54)], ['BATT48', 'PCU48']);
    await m.poll(1000 + 121000); assert.strictEqual(m.points(122000).length, 1, '2 minutes kept');
    CAR['2:AA56'] = null; await m.poll(200000);
    assert.deepStrictEqual(m.points(242001), [], 'a silent battery: the trace runs empty');
    m = new Mild(car({ '2:F150': '62F1500F1280', '84:F150': '62F1500F2C00' }));
    await m.identify(0);
    assert.deepStrictEqual([m.done, m.batt, m.pcu.sgbd, m.pcu.ok, m.found(), m.label(0x02)], [true, null, 'PCU48_2', false, true, '0x02']);
    asked.length = 0; assert.deepStrictEqual(await m.poll(0), { batt: null, pcu: null }); assert.deepStrictEqual(asked, [], 'nothing read of PCU48_2');
    // 0x02 the steering column switch, nothing at 0x54: a car without 48 V, settled
    m = new Mild(car({ '2:F150': '62F1500F1280' })); await m.identify(0);
    assert.deepStrictEqual([m.done, m.found()], [true, false]);
    // the battery silent once (just woken), the converter there: the battery asked again in 30 s, the converter not
    const late = { '84:F150': '62F1500F2720' };
    m = new Mild(car(late)); await m.identify(0);
    assert.deepStrictEqual([m.done, m.found(), m.batt, m.due(29999), m.due(30000)], [false, true, null, false, true]);
    late['2:F150'] = '62F1500F2810'; asked.length = 0; await m.identify(30000);
    assert.deepStrictEqual([m.done, m.batt.sgbd, asked], [true, 'BATT48', ['2:F150']]);
    // neither answers: not done, again after 5 min; a link error: in 30 s
    m = new Mild(car({})); await m.identify(0);
    assert.deepStrictEqual([m.done, m.found(), m.due(1000), m.due(RETRY_MS)], [false, false, false, true]);
    m = new Mild(() => Promise.reject(new Error('link down'))); await m.identify(0);
    assert.deepStrictEqual([m.done, m.due(29999), m.due(30000)], [false, false, true]);
    assert(Object.keys(CAR).every((k) => /:(F150|AA56|DA90)$/.test(k)));
    console.log('mild self-check ok: 48.5 V x -12.5 A = ' + r.batt.kw.toFixed(3) + ' kW, SOC 76 %, SOH 92 %, converter ' + MODES[p.mode]);
}

module.exports = { Mild, MODES, UNITS, decode, AA56, DA90, test };
if (require.main === module) test().catch((e) => { console.error(e); process.exit(1); });

'use strict';
/*
 * oap-edrive ("eDrive"): a plug-in hybrid's high-voltage battery, read-only. Range: the electric range learned from
 * how this car is driven (javascript/range.js), the charge, battery health, the energy in the battery; Battery: power
 * now and its last 2 minutes, the cells, temperatures, this drive's energy; Charge log: every charge with its cost
 * (javascript/chargelog.js, max 200); Settings: battery size, electricity price, currency, hybrid system Auto / Yes /
 * No, power sign; Diagnostics (from Settings): what the battery unit answered.
 * The battery unit (SME 0x07) and the 12 V over TASU, UDS 22 / OBD 01 reads only (javascript/battery.js); speed,
 * engine speed, the outside temperature and the climate over SOME/IP. A car without a hybrid system (the SME never
 * answers): the app says so, shows only the 12 V battery, and asks nothing while its screen is closed. A 48 V mild
 * hybrid (1.1.0, javascript/mild.js): its 48 V battery (BATT48, 0x02) and DC/DC converter (PCU48, 0x54), told by their
 * SGBD index (22 F1 50) once the screen shows, are on the Battery tab, read every 2 s only while that tab shows.
 * Ported from cauliflowermossgrape/idrive7-apps apps/edrive (MIT) @ c67ea17; iDrive 8 only. Not tested on a hybrid.
 * State (settings, what was learned, the charges) in the app's data folder, edrive.json: written on a change, at
 * most every 30 s while values come in, and at shutdown (tmp + rename).
 *
 * Screens: drawn by the GPU renderer, designed in the HMI UI builder: apps/hmi-ui-builder/projects/edrive.json
 * (scripts/oap-tools/make_edrive_project.js), exported into this folder (rhmiData/ = one empty RHMI host state per
 * screen, renderer/ = screens.json + the builder's runtime). Start, tile and shutdown: the shared OnlineApp host
 * (oap-shared/online-host.js).
 */
const fs = require('fs');
const path = require('path');
const util = require('util');
const someipBuilders                   = require('oap-sdk/src/someip/someipBuilders');
const { createHost }                   = require('./online-host.js');
const { createGuard }                  = require('./tasu-guard.js');
const { Diag, hex }                    = require('./diag.js');
const { Battery, Drive, limitsKw, state: packState } = require('./battery.js');
const { RangeModel, kwhPerPct, energy } = require('./range.js');
const { ChargeLog }                    = require('./chargelog.js');
const { Mild, MODES }                  = require('./mild.js');

const LOG = '[iteriodev_edrive]';
const STATES = ['range', 'battery', 'log', 'settings', 'diag'];   // screens = their RHMI host states, the entry first
const PAGES = ['range', 'battery', 'log', 'settings'];             // the tabs
const MENUS = { range: 'rangeMenu', battery: 'batteryMenu', log: 'logMenu', settings: 'settingsMenu', diag: 'diagMenu' };
const TICK = +process.env.EDRIVE_TICK_MS || 1000;    // the read loop's step (tests: shorter)
const READ_MS = Math.min(1500, 20 * TICK);           // a unit that does not answer: given up after this
const SOH_MS = 3 * 86400000, SOH_RETRY_MS = 3600000; // battery health every 3 days; after a failure an hour later
const SAVE_MS = 30000;
const V12_KEEP = 60;                                 // 12 V readings on its trend: 5 min at a 5 s poll
const RETRY_MS = 30000;                              // a SOME/IP link again after a failure
const TASU_IF = 'com.harman.infotainment.systemfunctions.tasu.tasu.InternalTasu';
const TASU_INST = 'SystemFunctionsInternalTasuInst1';
// the kit's settings (apps/edrive/app.json: the gross sizes BMW fits, the price steps; live_data: the currencies)
const KWH_STEPS = [7.6, 9.2, 10.4, 11.2, 12, 14.1, 17.7, 19.4, 24, 25.7, 42.2];
const PRICE_STEPS = [0, 0.05, 0.1, 0.12, 0.15, 0.16, 0.17, 0.18, 0.19, 0.2, 0.21, 0.22, 0.23, 0.24, 0.25, 0.26, 0.27, 0.28, 0.29, 0.3,
    0.31, 0.32, 0.33, 0.34, 0.35, 0.36, 0.37, 0.38, 0.39, 0.4, 0.45, 0.5, 0.55, 0.6, 0.7];
const CURRENCIES = ['EUR', 'USD', 'CAD', 'GBP', 'CHF', 'PLN', 'CZK', 'SEK', 'NOK', 'DKK', 'HUF', 'UAH'];
const HYBRID = ['auto', 'yes', 'no'];
const DEFAULTS = { designKwh: 12, price: 0.25, currency: 'EUR', hybrid: 'auto', powerSign: -1 };
const UNIT = { 0x07: 'SME', 0x12: 'DME', 0x13: 'DME 2', 0x18: 'EGS' };   // 0x02 / 0x54: mild.label() (their SGBD once told)
const OK = '#5bd68a', TRACK = '#16191e';

// the linked bundle is javascript/app.js: the package root is one up, the app's data folder beside it (the Store's)
const SOURCE = typeof __dirname === 'string' ? path.join(__dirname, '..') : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const DATA = process.env.EDRIVE_DATA || path.join(__dirname, '..', '..', 'data');
const STATE_FILE = path.join(DATA, 'edrive.json');
const LOG_FILE = path.join(DATA, 'edrive.log');

const isNum = (v) => typeof v === 'number' && isFinite(v);
const errText = (e) => String((e && e.message) || e).slice(0, 120);
function log() {
    const line = [new Date().toISOString()].concat([].slice.call(arguments)
        .map((x) => (typeof x === 'string' ? x : util.inspect(x, { depth: 4 }).slice(0, 2000)))).join(' ');
    console.error(LOG, line);
    try { if (fs.statSync(LOG_FILE).size > 256 * 1024) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* no file yet */ }
    try { fs.appendFileSync(LOG_FILE, `${line}\n`); } catch (e) { /* no data folder */ }
}

// ---- state: settings, the battery unit's verdict, what was learned, the charges ----------------------------------
// no file: a first start; one that cannot be read or is not JSON: kept as edrive.json.bad (the next save would overwrite it)
const saved = (() => {
    try { const o = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); return o && typeof o === 'object' ? o : {}; } catch (e) {
        if (e.code === 'ENOENT') return {};
        try { fs.renameSync(STATE_FILE, `${STATE_FILE}.bad`); } catch (e2) { /* gone meanwhile */ }
        log('state file unusable, kept as edrive.json.bad:', errText(e));
        return {};
    }
})();
const settings = Object.assign({}, DEFAULTS, saved.settings);
['designKwh', 'price', 'powerSign'].forEach((k) => { if (!isNum(settings[k])) settings[k] = DEFAULTS[k]; });
if (HYBRID.indexOf(settings.hybrid) < 0) settings.hybrid = DEFAULTS.hybrid;
if (CURRENCIES.indexOf(settings.currency) < 0) settings.currency = DEFAULTS.currency;

let diag = null;                  // UDS over TASU once connected
const seen = {};                  // 'SME DDBC' -> 'answers' | 'refused (NRC 31)' | 'no answer' (Diagnostics)
/**
 * battery.js read(addr, did): 'DDBC' = 22 DD BC, 'OBD 42' = 01 42; the whole reply, or null when none came. Hybrid
 * system No: the battery unit is never asked (also not as a 12 V source). A unit the transport refuses (TASU's own
 * verdict, e.g. no such unit) counts as silent; only a missing link throws (battery.js: neither heard nor silent).
 */
function read(addr, did) {
    if (!diag) return Promise.reject(new Error('no diagnostic link'));
    if (addr === 0x07 && settings.hybrid === 'no') return Promise.resolve(null);
    const obd = did.indexOf('OBD ') === 0, id = parseInt(obd ? did.slice(4) : did, 16), key = `${addr === 0x02 || addr === 0x54 ? mild.label(addr) : UNIT[addr] || hex(addr)} ${did}`;
    return diag.physical(addr, obd ? 0x01 : 0x22, obd ? [id] : [id >> 8, id & 0xFF], READ_MS).then((u) => {
        seen[key] = !u ? 'no answer' : u[0] === 0x7F ? `refused (NRC ${hex(u[2])})` : 'answers';
        return u ? Buffer.from(u) : null;
    }, (e) => {
        if (!/^transport refused/.test(errText(e))) throw e;
        seen[key] = errText(e).slice(0, 40);
        return null;
    });
}
const battery = new Battery(read, { powerSign: settings.powerSign }, saved.battery);
const mild = new Mild(read);      // the 48 V units: only asked on a car without a high-voltage battery
const model = RangeModel.fromJSON(saved.range);
const charges = ChargeLog.fromJSON(saved.log, { minPct: 3 });
let soh = isNum(saved.soh) ? saved.soh : null, sohT = saved.sohT || 0, sohTry = 0;
let dirty = false, savedAt = 0;
function save() {
    const tmp = `${STATE_FILE}.tmp`;
    try {
        fs.writeFileSync(tmp, JSON.stringify({ settings, battery, range: model, log: charges, soh, sohT }));
        fs.renameSync(tmp, STATE_FILE);
        dirty = false; savedAt = Date.now();
    } catch (e) { log('save failed:', errText(e)); }
}

// ---- live values ------------------------------------------------------------------------------------------------
const live = { soc: null, socT: 0, v12: null, v12s: [], power: null, slow: {}, speed: null, rpm: null, ambient: null,
    climateOn: null, acOn: null, climate: null };
let drive = new Drive(Date.now());            // this drive: a new one after 10 min without power readings (parked)
const DRIVE_GAP_MS = 600000;
const moving = () => isNum(live.speed) && live.speed > 1;
const engineOn = () => isNum(live.rpm) && live.rpm > 400;
const hvFound = () => settings.hybrid === 'yes' || (settings.hybrid === 'auto' && battery.toJSON().hybrid);
const noHv = () => settings.hybrid === 'no' || (settings.hybrid === 'auto' && battery.noHybrid);
const kpp = () => kwhPerPct(settings.designKwh, soh);
const estimate = (now) => model.estimate(live.soc, live.ambient, live.climate, model.pace(now), 0, { designKwh: settings.designKwh, soh });

// ClimateMaster: one entry per zone; null = not said
const anyOn = (v, key) => {
    const a = Array.isArray(v) ? v : v && Array.isArray(v.value) ? v.value : [];
    return a.length ? a.some((z) => !!z && z[key] === true) : null;
};
function onClimate() {
    live.climate = live.climateOn === null ? null : live.climateOn ? (live.acOn ? 'ac' : true) : false;
    model.onClimate(live.climate);
}
// scalings as Fault Codes / Car Data use them on this car (speed / 64, rpm x 0.25, outside x 0.5 - 40)
const SOURCES = {
    Speed: ['de.bmw.infotainment.vehicle.Vehicle2', { statusCarSpeed2: (x) => {
        const r = x && x.speedVehicleCentreOfGravity;
        live.speed = typeof r === 'number' && r !== 65535 ? r / 64 : null;
        if (isNum(live.speed)) model.onSpeed(live.speed, Date.now(), engineOn());
    } }],
    Rpm: ['de.bmw.infotainment.vehicle.CDS', { statusEngineSpeed2: (x) => {
        const r = x && x.actualValueRPMEngineCrankshaft, now = Date.now();
        if (typeof r !== 'number' || r === 65535) return;
        live.rpm = r * 0.25;
        if (model.onRpm(live.rpm, now, live.speed, now - live.socT < 60000 ? live.soc : null)) dirty = true;
    } }],
    Outside: ['de.bmw.infrastructure.EnvironmentalInformation', { ExteriorTemperature: (x) => {
        const r = x && x.temperatureExterior;
        if (typeof r === 'number' && r !== 255) live.ambient = r * 0.5 - 40;
    } }],
    Climate: ['de.bmw.infotainment.climate.climatemaster.ClimateMaster', {
        statusClimateSystemOn: (v) => { live.climateOn = anyOn(v, 'airConditioningOn'); onClimate(); },
        statusAirCondAC: (v) => { live.acOn = anyOn(v, 'acButton'); onClimate(); },
    }],
};
function connectSource(name) {
    const ifName = SOURCES[name][0], fields = SOURCES[name][1];
    return someipBuilders.buildAndInitTypedProxy(ifName, '1', { timeoutMs: 10000 })
        .then((p) => Promise.all(Object.keys(fields).map((f) => Promise.resolve().then(() => p[f].subscribe(fields[f]))
            .catch((e) => log(`${name}.${f} subscribe:`, e)))))
        .then(() => log(`${name} subscribed`))
        .catch((e) => { log(`${name}:`, errText(e)); setTimeout(() => connectSource(name), RETRY_MS); });
}
function connectTasu() {
    return someipBuilders.buildAndInitTypedProxy(TASU_IF, TASU_INST, { timeoutMs: 10000 })
        .then((p) => { const d = new Diag(log, createGuard({})); return d.attach(p).then(() => { diag = d; log('TASU connected'); }); })
        .catch((e) => { log('TASU failed:', errText(e)); setTimeout(connectTasu, RETRY_MS); });
}

// ---- the read loop: charge + 12 V every 5 s (30 s with the screen closed), power every 1-2 s, the rest slower -------
function pollCharge(now) {
    if (settings.hybrid === 'yes') battery.socTry = -Infinity;   // Yes always asks it (battery.js: every 5 min once none found)
    const ask = settings.hybrid === 'no'          // No: the battery unit is not asked at all
        ? battery.group('v12').then((r) => ({ soc: null, v12: r.value ? r.value.v : null })) : battery.poll(now);
    return ask.then((r) => {
        dirty = true;                             // battery.js may have decided about the hybrid system
        if (isNum(r.v12)) { live.v12 = r.v12; live.v12s = live.v12s.concat([r.v12]).slice(-V12_KEEP); }
        if (!isNum(r.soc)) return;
        live.soc = r.soc; live.socT = now;
        const k = kpp();
        // range.js learns nothing while a charge session is open: chargelog.js is asked before its own reading
        model.onReading(r.soc, now, { ambient: live.ambient, kwhPerPct: k, comfortKw: 0, charging: charges.charging() });
        if (charges.reading(r.soc, now, moving(), k)) save();      // a charge logged, a session opened / grew / closed
    });
}
function pollPower(now) {
    return battery.power(now, null).then((p) => {
        live.power = p;
        if (!p) return;
        if (drive.kwT !== null && now - drive.kwT > DRIVE_GAP_MS) drive = new Drive(now);
        drive.add(p.kw, now, moving(), model.climateKw(live.ambient, kpp(), live.climate));
    });
}
const pollSlow = () => battery.slow().then((s) => { live.slow = s; });
const unitName = (u) => (u ? `${u.sgbd} (${u.index})${u.ok ? '' : ', not supported'}` : 'none');
// (both look again whether the screen still shows: HOME may come while an earlier read of the same turn runs)
const identify48 = (now) => (!shown() ? null : mild.identify(now).then(() => {
    if (mild.done) log(`48 V units: battery ${unitName(mild.batt)}, converter ${unitName(mild.pcu)}`);
}));
const poll48 = (now) => (shown() ? mild.poll(now) : null);
function pollHealth(now) {
    sohTry = now;
    return battery.health().then((v) => { if (isNum(v)) { soh = v; sohT = now; save(); } });
}
let busy = false, lastPoll = 0, lastPower = 0, lastSlow = 0, last48 = 0;
const shown = () => (screens && screens.st && !screens.paused ? screens.st.name : null);
function tick() {
    const now = Date.now(), page = shown(), hv = hvFound(), nh = noHv();
    // no hybrid system: nothing is asked while the screen is closed
    if (diag && !busy && (page || !nh)) {
        const steps = [];
        if (now - lastPoll >= (page ? 5 : 30) * TICK) { lastPoll = now; steps.push(pollCharge); }
        // no high-voltage battery: the 48 V units once, then their values while the Battery tab shows
        if (page && nh && mild.due(now)) steps.push(identify48);
        if ((page === 'battery' || page === 'diag') && nh && mild.found() && now - last48 >= 2 * TICK) { last48 = now; steps.push(poll48); }
        if (hv && now - lastPower >= (page === 'battery' ? 1 : 2) * TICK) { lastPower = now; steps.push(pollPower); }
        if (hv && page === 'battery' && now - lastSlow >= 10 * TICK) { lastSlow = now; steps.push(pollSlow); }
        if (hv && now - sohT > SOH_MS && now - sohTry > SOH_RETRY_MS) steps.push(pollHealth);
        if (steps.length) {
            busy = true;
            steps.reduce((p, f) => p.then(() => f(now)), Promise.resolve())
                .catch((e) => log('read failed:', errText(e)))
                .then(() => { busy = false; if (dirty && Date.now() - savedAt > SAVE_MS) save(); render(); });
        }
    }
    render();
}

// ---- the screens (the renderer) -----------------------------------------------------------------------------------
// renderer/ is the builder's export: screens.json + its runtime. Loaded with a computed path: the linker
// (oap_link.js) leaves it to the platform require (plain files in the package, Node 8).
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
let screens = null;
const hvNames = [], noHvNames = [], mhNames = [];   // Range / Battery / Charge log: the hybrid layout, the "no hybrid
                                                    // system" one; Battery: the 48 V mild hybrid's

const f = (v, d) => (isNum(v) ? v.toFixed(d) : '--');
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const two = (n) => (n < 10 ? '0' : '') + n;
const day = (t) => { const d = new Date(t); return `${d.getDate()} ${MON[d.getMonth()]}, ${two(d.getHours())}:${two(d.getMinutes())}`; };
function ago(now, t) {
    const m = Math.round((now - t) / 60000);
    return m < 1 ? 'just now' : m < 60 ? `${m} min ago` : m < 2880 ? `${Math.round(m / 60)} h ago` : `${Math.round(m / 1440)} days ago`;
}

const MILD_CHIP = ['48 V mild hybrid', 'info'];
function renderRange(now, est, nh, hv, m48) {
    const chips = !diag ? [['No diagnostic link', 'crit']] : m48 ? [MILD_CHIP] : nh ? [['No hybrid system', 'dim']] : !hv ? [['Asking the battery unit', 'dim']] : [];
    if (diag && hv && live.climate !== null) chips.push([live.climate === 'ac' ? 'A/C on' : live.climate ? 'Climate on' : 'Climate off', 'info']);
    if (diag && hv && isNum(live.rpm)) chips.push(engineOn() ? ['Engine running', 'dim'] : ['Electric', 'ok']);
    const byHand = settings.hybrid === 'no';      // No on Settings: not "never answered"
    screens.set('rangeMenu', { chips, sub: !nh ? 'Learned from how this car is driven' : byHand ? 'Hybrid system set to No' : 'The battery unit (SME) does not answer' })
        .set('noHvRange', byHand ? { head: 'Hybrid system: No', line: 'Set on Settings: the battery unit is not asked.' }
            : m48 ? { head: '48 V mild hybrid', line: 'No high-voltage battery: the 48 V battery and its converter are on Battery.' }
                : { head: 'No hybrid system found', line: 'The battery unit never answered: this car has no high-voltage battery.' })
        .set('noHvHint', { text: byHand ? 'Auto finds it again, Yes always asks it.' : m48 ? 'On the right: the 12 V battery.'
            : 'If it has one, set Hybrid system to Yes on Settings.' });
    const v = live.v12s, lo = v.length ? Math.min.apply(null, v) : null, hi = v.length ? Math.max.apply(null, v) : null;
    screens.set('noHvV12', { value: f(live.v12, 2), points: v, lo: isNum(lo) ? lo - 0.1 : 11, hi: isNum(hi) ? hi + 0.1 : 14,
        foot: v.length ? `last 5 min · engine ${engineOn() ? 'running' : 'off'} · min ${f(lo, 2)} · max ${f(hi, 2)}` : 'Reading the 12 V battery' });
    if (nh) return;
    const top = isNum(est.full) ? Math.max(10, Math.ceil(est.full * 1.25 / 10) * 10) : 60, lit = isNum(live.soc) ? Math.round(live.soc / 10) : 0;
    screens.set('rangeValue', { value: isNum(est.mid) ? String(Math.round(est.mid)) : '--' })
        .set('rangeSub', { text: isNum(est.lo) ? `${Math.round(est.lo)} - ${Math.round(est.hi)} km · the engine starts at ${Math.round(est.res)} %`
            + (est.learned ? '' : ' · not learned yet') : 'Waiting for the charge level' })
        .set('rangeBar', { value: isNum(est.mid) ? Math.min(1, est.mid / top) : 0, label: `Full: ${Math.round(est.full)} km`, right: `${top} km` })
        .set('rangeKv', { rows: [['Outside', isNum(live.ambient) ? `${live.ambient.toFixed(1)} °C` : '--'], ['12 V battery', isNum(live.v12) ? `${live.v12.toFixed(2)} V` : '--']] })
        .set('socValue', { value: isNum(live.soc) ? String(Math.round(live.soc)) : '--' });
    for (let i = 0; i < 10; i++) screens.set(`chgCell${i}`, { color: i < lit ? OK : TRACK });
    const l = charges.last(kpp()), e = energy(live.soc, soh, settings.designKwh);
    screens.set('lastAdded', { text: l ? `+${Math.round(l.to - l.from)} %  ·  +${Math.round((l.to - l.from) * est.kpp)} km` : '--' })
        .set('lastSub', { text: l ? `${Math.round(l.from)} → ${Math.round(l.to)} % · ${l.open ? 'charging now' : ago(now, l.toT)}` : 'No charge logged yet' })
        .set('sohValue', { value: f(soh, 1) })
        .set('sohSub', { text: isNum(e.holds) ? `a full charge holds ${e.holds.toFixed(1)} of ${settings.designKwh.toFixed(1)} kWh` : 'Battery health not read yet' })
        .set('kwhValue', { value: f(e.now, 1) });
}
function renderBattery() {
    const p = live.power, s = live.slow || {}, lim = limitsKw(s.limits, p && p.v), t = drive.totals();
    const c = s.cellV && isNum(s.cellV.min) && isNum(s.cellV.max) ? s.cellV : null, cells = c && c.cells ? c.cells.filter(isNum) : [];
    const lims = !!lim && isNum(lim.in) && isNum(lim.out), ct = s.cellT;
    screens.set('kwValue', { value: p ? (p.kw > 0 ? '+' : '') + p.kw.toFixed(1) : '--', color: p && p.kw < -0.3 ? 'ok' : 'accent' })
        .set('kwSub', { text: p ? `${packState(p.kw, moving()).toLowerCase()} · ${Math.round(p.v)} V · ${Math.round(Math.abs(p.a))} A` : 'Waiting for the battery unit' })
        .set('pwTrend', { points: drive.trace.map((x) => x[1]), lo: lims ? -lim.in : -50, hi: lims ? lim.out : 100,
            foot: lims ? `regen limit -${Math.round(lim.in)} kW · drive limit ${Math.round(lim.out)} kW` : 'last 2 min' })
        .set('cellTrend', { label: c && c.cells ? `Cell voltages · ${c.cells.length} cells` : 'Cell voltages', value: c ? String(c.spreadMv) : '--',
            points: cells, lo: c ? c.min - 0.005 : 3.5, hi: c ? c.max + 0.005 : 4.2,
            foot: c ? `lowest ${c.min.toFixed(3)} V · highest ${c.max.toFixed(3)} V` : 'Not read yet' })
        .set('batKv', { rows: [
            ['Cell temperature', ct && isNum(ct.min) && isNum(ct.max) ? `${Math.round(ct.min)} - ${Math.round(ct.max)} °C` : '--'],
            ['Coolant', isNum(s.coolant) ? `${Math.round(s.coolant)} °C` : '--'],
            ['This drive: used · regen', `${t.used.toFixed(1)} · ${t.regen.toFixed(1)} kWh`],
            ['Net · to climate', `${t.net.toFixed(1)} · ${t.climate.toFixed(1)} kWh`]] });
}
// the 48 V battery (+ = it gives power: a negative current is charging, its SGBD says) and the converter
function renderMild(now) {
    const r = mild.last, b = r.batt, p = r.pcu, B = mild.batt, P = mild.pcu, pts = mild.points(now);
    const v = (x, d, u) => (b && isNum(b[x]) ? `${b[x].toFixed(d)}${u}` : '--');
    const lo = pts.length ? Math.min.apply(null, pts.concat([0])) : -1, hi = pts.length ? Math.max.apply(null, pts.concat([0])) : 1;
    const kw = b && isNum(b.kw) ? b.kw : null, side = (V, A) => (p && isNum(p[V]) ? `${p[V].toFixed(2)} V · ${f(p[A], 1)} A` : '--');
    screens.set('mhKw', { value: isNum(kw) ? (kw > 0 ? '+' : '') + kw.toFixed(1) : '--', color: isNum(kw) && kw < -0.05 ? 'ok' : 'accent' })
        .set('mhKwSub', { text: !B ? 'No 48 V battery answered (BATT48)' : !B.ok ? `${B.sgbd} found: its values are not supported yet`
            : !b ? 'Waiting for the 48 V battery' : `${!isNum(b.a) ? '--' : b.a < -0.5 ? 'charging' : b.a > 0.5 ? 'discharging' : 'idle'} · ${v('v', 2, ' V')} · ${f(isNum(b.a) ? Math.abs(b.a) : null, 1)} A` })
        .set('mhTrend', { points: pts, lo: lo - (hi - lo) * 0.1 - 0.1, hi: hi + (hi - lo) * 0.1 + 0.1 })
        .set('mhSoc', { value: b && isNum(b.soc) ? String(Math.round(b.soc)) : '--' })
        .set('mhSocSub', { text: b && isNum(b.socQ) ? `estimate quality ${Math.round(b.socQ)} %` : '' })
        .set('mhBatKv', { rows: [['Health (SOH)', v('soh', 0, ' %')],
            ['A full charge holds', b && isNum(b.fullAh) && isNum(b.nomAh) ? `${b.fullAh.toFixed(1)} of ${b.nomAh.toFixed(1)} Ah` : '--'],
            ['Charge now', v('nowAh', 1, ' Ah')], ['Hottest cell', v('t', 0, ' °C')], ['Pack voltage', v('pack', 2, ' V')]] })
        .set('mhMode', { text: !P ? 'Not found' : !P.ok ? P.sgbd : p && isNum(p.mode) ? MODES[p.mode] || `Mode ${p.mode}` : '--' })
        .set('mhModeSub', { text: !P ? 'No 48 V converter answered (PCU48)' : !P.ok ? 'found: its values are not supported yet' : 'the mode the converter reports' })
        .set('mhPcuKv', { rows: [['12 V side', side('v12', 'a12')], ['12 V power', p && isNum(p.w12) ? `${p.w12} W` : '--'],
            ['48 V side', side('v48', 'a48')], ['48 V power', p && isNum(p.w48) ? `${p.w48} W` : '--']] });
}
function renderLog(now, est) {
    const cur = settings.currency, rows = charges.rows(est.kpp, settings.price), tot = charges.totals(now, est.kpp, settings.price);
    const money = (v) => (isNum(v) ? `${v.toFixed(2)} ${cur}` : '--'), days = charges.days(now, 14);
    const top = Math.max(5, Math.ceil(Math.max.apply(null, days) / 5) * 5);
    screens.set('logTable', { hidden: !rows.length, rows: rows.slice(0, 6).map((r) => [day(r.toT), `${Math.round(r.from)} → ${Math.round(r.to)} %`, f(r.kwh, 1),
            isNum(r.km) ? `+${Math.round(r.km)} km` : '--', money(r.cost)]) })
        .set('logEmpty', { hidden: rows.length > 0 })
        .set('logChart', { points: days.map((v, i) => [i, v]), yMax: top, yStep: top / 5 })
        .set('logKv', { rows: [['This month', `${tot.month.kwh.toFixed(1)} kWh · ${money(tot.month.cost)}`],
            ['All time', `${tot.all.kwh.toFixed(1)} kWh · ${money(tot.all.cost)}`], ['Charges', String(tot.all.count)]] });
}
function renderSettings(hv, nh) {
    const kwh = settings.designKwh, price = settings.price;   // a stepper at its list's end: greyed out (its tap does nothing)
    screens.set('kwhText', { text: `${kwh.toFixed(1)} kWh` })
        .set('kwhMinus', { disabled: kwh <= KWH_STEPS[0] }).set('kwhPlus', { disabled: kwh >= KWH_STEPS[KWH_STEPS.length - 1] })
        .set('priceText', { text: price.toFixed(2) })
        .set('priceMinus', { disabled: price <= PRICE_STEPS[0] }).set('pricePlus', { disabled: price >= PRICE_STEPS[PRICE_STEPS.length - 1] })
        .set('currencyRow', { text: settings.currency })
        .set('hybridTabs', { sel: HYBRID.indexOf(settings.hybrid) })
        .set('hybridRow', settings.hybrid !== 'auto' ? { sub: 'Set by hand', subColor: '' }
            : hv ? { sub: 'Auto: found, the battery unit answers', subColor: 'ok' }
                : nh ? { sub: 'Auto: not found, the battery unit does not answer', subColor: '' } : { sub: 'Auto: asking the battery unit', subColor: '' })
        .set('signTabs', { sel: settings.powerSign > 0 ? 1 : 0 });
}
// Diagnostics: the battery unit's identifiers, those that did not answer first (the 12 V source is on the left)
const rank = (k) => (seen[k] === 'answers' ? 'b' : 'a') + (k.indexOf('SME ') === 0 ? '0' : '1') + k;   // then the battery unit's first
function renderDiag(est, hv, nh) {
    const p = live.power, b = mild.last.batt, c = mild.last.pcu, v12 = ['12 V battery', isNum(live.v12) ? `${live.v12.toFixed(2)} V` : '--'];
    const unit = (u) => (u ? [`${u.sgbd} · ${u.index}${u.ok ? '' : ' · not supported'}`, u.ok ? 'ok' : 'warn'] : [mild.done ? 'none' : diag ? 'asking' : '--', '']);
    const head = [['Hybrid system', hv ? 'found' : nh ? 'not found' : 'asking', hv ? 'ok' : ''],
        ['Diagnostic link (TASU)', diag ? 'connected' : 'not connected', diag ? 'ok' : 'crit']];
    // no high-voltage battery: the 48 V units in the place of the high-voltage values (the 12 V stays 6th)
    screens.set('diagKvL', { rows: head.concat(nh ? [
        ['48 V battery'].concat(unit(mild.batt)), ['48 V converter'].concat(unit(mild.pcu)),
        ['48 V charge', b && isNum(b.soc) ? `${b.soc} %` : '--'], v12,
        ['48 V battery now', b && isNum(b.v) && isNum(b.a) ? `${b.v.toFixed(2)} V · ${b.a.toFixed(1)} A` : '--'],
        ['Converter mode', c && isNum(c.mode) ? `${c.mode} · ${MODES[c.mode] || 'unknown'}` : '--']] : [
        ['Charge level', isNum(live.soc) ? `${live.soc.toFixed(1)} %` : '--'],
        ['Battery health', isNum(soh) ? `${soh.toFixed(1)} %` : '--'],
        ['Pack', p ? `${p.v.toFixed(0)} V · ${p.a.toFixed(1)} A` : '--'], v12,
        ['Electric driving learned', `${Math.round(est.learnedKm)} km`],
        ['Engine starts at', `${Math.round(est.res)} %`]]) })
        .set('diagTitleR', { text: (nh ? 'Battery units (SME, 48 V) · first 8' : 'Battery unit (SME 0x07) · first 8').toUpperCase() })
        .set('diagKvR', { rows: Object.keys(seen).filter((k) => (nh ? /^(SME|0x02|0x54|BATT48|PCU48) / : /^SME /).test(k)).sort((x, y) => (rank(x) < rank(y) ? -1 : 1))
            .slice(0, 8).map((k) => [k, seen[k], seen[k] === 'answers' ? 'ok' : seen[k] === 'no answer' ? '' : 'warn']) });
}
function render() {
    if (!screens) return;
    const now = Date.now(), nh = noHv(), hv = hvFound(), est = estimate(now), m48 = nh && mild.found();
    hvNames.forEach((n) => screens.set(n, { hidden: nh }));
    noHvNames.forEach((n) => screens.set(n, { hidden: !nh || (m48 && n === 'noHvBattery') }));   // Battery: the 48 V units instead
    mhNames.forEach((n) => screens.set(n, { hidden: !m48 }));
    const noHvChip = m48 ? [MILD_CHIP] : [['No hybrid system', 'dim']];
    screens.set('batteryMenu', { chips: m48 ? [MILD_CHIP, ['Not confirmed on a car', 'warn']] : nh ? noHvChip : [],
        sub: m48 ? '48 V battery and DC/DC converter, read every 2 s while this tab shows'
            : nh ? 'No high-voltage battery: Range shows the 12 V battery' : 'HV battery live from the battery unit, every second' })
        .set('logMenu', { chips: nh ? noHvChip : [],
            sub: nh ? 'No high-voltage battery: nothing to charge' : `Every charge, with its cost at ${settings.price.toFixed(2)} ${settings.currency}/kWh` });
    renderRange(now, est, nh, hv, m48);
    if (!nh) { renderBattery(); renderLog(now, est); }
    if (m48) renderMild(now);
    renderSettings(hv, nh);
    renderDiag(est, hv, nh);
}

// ---- what the user does -------------------------------------------------------------------------------------------
/** the step d (-1 / +1) from the value nearest v in a list of steps */
function stepIn(list, v, d) {
    const i = list.reduce((b, x, j) => (Math.abs(x - v) < Math.abs(list[b] - v) ? j : b), 0);
    return list[Math.max(0, Math.min(list.length - 1, i + d))];
}
function setting(o) {
    Object.assign(settings, o);
    battery.powerSign = settings.powerSign;
    log('settings', JSON.stringify(settings));
    save(); render();
}
const EVENTS = {
    kwhMinus: () => setting({ designKwh: stepIn(KWH_STEPS, settings.designKwh, -1) }),
    kwhPlus: () => setting({ designKwh: stepIn(KWH_STEPS, settings.designKwh, 1) }),
    priceMinus: () => setting({ price: stepIn(PRICE_STEPS, settings.price, -1) }),
    pricePlus: () => setting({ price: stepIn(PRICE_STEPS, settings.price, 1) }),
    currency: () => setting({ currency: CURRENCIES[(CURRENCIES.indexOf(settings.currency) + 1) % CURRENCIES.length] }),
    diag: () => showScreen('diag'),
};
function onChange(name, o) {
    if (name === 'hybridTabs' && HYBRID[o.sel]) return setting({ hybrid: HYBRID[o.sel] });
    if (name === 'signTabs') return setting({ powerSign: o.sel === 1 ? 1 : -1 });
    const page = Object.keys(MENUS).find((p) => MENUS[p] === name);
    if (page) {                                       // a tab (o is the shell's opts: read before the set)
        const to = PAGES[o.sel];
        screens.set(name, { sel: PAGES.indexOf(page === 'diag' ? 'settings' : page) });
        goTo(to);
    }
    return null;
}
// Range is the app's first screen, the other tabs open over it, Diagnostics over Settings (BACK returns)
function goTo(page) {
    const cur = screens.st && screens.st.name;
    if (!page || page === cur) return;
    const over = cur === 'diag' ? ['diag', 'settings'] : cur && cur !== 'range' ? [cur] : [];   // open over Range now
    over.forEach((s) => { if (s !== page) closeScreen(s); });
    if (page !== 'range' && over.indexOf(page) < 0) showScreen(page);
}

// ---- RHMI: the host states (the OnlineApp host hands them over) ----------------------------------------------------
let app = null;
const comp = (n) => app.getByName(n);
function showScreen(name) {
    return comp(name).updateResources().then(() => app.openState(name))
        .then(() => log(`opened ${name}`))
        .catch((e) => log(`open ${name} failed:`, e));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed:`, e));

function startScreens(rhmiApp, hosts) {
    app = rhmiApp;
    const design = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
    design.screens.filter((s) => ['range', 'battery', 'log'].indexOf(s.name) >= 0).forEach((s) => s.components.forEach((c) => {
        if (c.gpu !== 'teleShell') (/^noHv/.test(c.name) ? noHvNames : /^mh/.test(c.name) ? mhNames : hvNames).push(c.name);
    }));
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: (m) => log(m), warn: (m) => log(m), error: (m) => log(m) };
    const gpu = new RenderClient('iteriodev_edrive', rlog);
    screens = new ScreenApp(gpu, design, { view: 'id8', log: rlog });
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('event', (n) => { try { if (EVENTS[n]) EVENTS[n](); } catch (e) { log(`${n} failed:`, e); } });
    screens.on('change', (n, o) => { try { onChange(n, o); } catch (e) { log(`${n} failed:`, e); } });
    screens.on('show', () => render());
    // the user left for the HMI (touched it): leave the host states too, or the HMI would show its empty page
    screens.on('closed', (why) => { if (why !== 'hmi') STATES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
    render();
}

// ---- lifecycle: the shared OnlineApp host (start, tile, shutdown) -------------------------------------------------
// The links and the read loop start with the screens and keep running while they are closed (the charge log and the
// range learn from every reading); the state is saved at shutdown.
log('start', process.getuid());
createHost({
    states: STATES,
    log,
    onReady: (rhmiApp, hosts) => {
        startScreens(rhmiApp, hosts); log('screens ready');
        connectTasu(); Object.keys(SOURCES).forEach(connectSource);
        setInterval(tick, TICK);
    },
    onShutdown: () => save(),
});

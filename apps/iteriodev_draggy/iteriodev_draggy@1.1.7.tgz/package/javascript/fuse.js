'use strict';
/*
 * Speed fusion for the drag timer (Node 8, no deps). Turns three imperfect signals into one fast,
 * low-lag, bias-free speed for timer.js:
 *   - wheel  (Vehicle2.statusCarSpeed2): true-ish, mid-rate, LAGGY and tyre/speedo-biased, reads HIGH on wheelspin
 *   - accel  (CDS2 longitudinal, m/s^2): high-rate, low-lag, but DRIFTS when integrated
 *   - gps    (GPSData ground speed, ~1 Hz): absolute + wheel-independent, but slow
 * Accel-driven, drift-corrected: the fused speed is the accel integral (no lag), and the wheel + GPS only
 * correct its slow drift. The wheel correction is GATED - skipped when the wheel reads faster than the
 * accel says is possible (wheelspin), so a spinning launch rides the honest accel, not the wheel. GPS
 * can't spin, so it always corrects; it also auto-calibrates the wheel factor. So:
 *   accuracy, worst->best:  wheel only  <  accel+wheel  <  accel+wheel+gps
 * GPS at 1 Hz is too slow to time splits itself; here it only calibrates + anchors, which is plenty.
 *
 *   const f = new Fuser();
 *   f.wheel(kmh, t); f.accel(ms2, t); f.gps(kmh, fixGood, t);   // feed whatever arrives
 *   const s = f.tick(now);   // -> { t, vKmh, distM }  (call ~every 20 ms; feed s.t/s.vKmh to RunTimer)
 */
const KMH = 1 / 3.6;        // km/h -> m/s

const DEF = {
    Kw: 1.8,                // wheel drift-correction gain /s
    Kg: 1.8,                // gps drift-correction gain /s (good fix)
    leadS: 0.3,             // the wheel's lag (s): the correction target is the wheel led forward by this. Calibrate on car.
    spinMarginKmh: 4,       // wheel ignored when the led wheel exceeds the accel estimate by this + spinMarginPct
    spinMarginPct: 0.08,
    freshWheelMs: 400,      // a reading older than this is ignored
    freshAccelMs: 200,
    freshGpsMs: 2000,       // gps is ~1 Hz
    gpsMaxKmh: 400,         // gps above this is nonsense (a wrong scale)
    gpsTolKmh: 15,          // ...and it only corrects while within this or gpsTolPct of the led wheel
    gpsTolPct: 0.25,
    zuptKmh: 1.0,           // below this + near-zero accel = standing: force 0 (kills drift at launch)
    zuptAcc: 0.4,           // m/s^2
    zuptMaxKmh: 5,          // ...only while the fused speed is this low: a moving car can't stop at once (a wheel 0 = dropout)
    maxOffMs: 2000,         // the wheel is ignored (spin / dropout) for at most this long: then it is right again
    calMinKmh: 30,          // learn the wheel factor only above this speed
    calMaxAcc: 0.6,         // ...and only when roughly steady (so wheelspin / shift don't poison it)
    calRate: 0.03,          // EMA rate for the wheel factor
    biasRate: 0.1,          // EMA rate for the accel zero (learned at standstill)
    accelSign: 1,           // +1 if forward acceleration reads positive; calibrate on the car
};

class Fuser {
    constructor(opts) {
        this.o = Object.assign({}, DEF, opts);
        this.v = 0;                 // fused speed, m/s
        this.s = 0;                 // distance, m
        this.lastT = null;
        this.wheelCal = 1;          // multiplies wheel speed; learned from gps
        this.accelBias = 0;         // subtracted from accel; learned at standstill
        this._w = null; this._a = null; this._g = null;   // { v|a, t, good? }
        this.offSince = null;       // since when the wheel disagrees (spin / dropout)
    }

    wheel(kmh, t) { if (isFinite(kmh)) this._w = { v: kmh * KMH, t }; }
    accel(ms2, t) { if (isFinite(ms2)) this._a = { a: ms2 * this.o.accelSign, t }; }
    gps(kmh, fixGood, t) { if (isFinite(kmh)) this._g = { v: kmh * KMH, t, good: !!fixGood }; }

    reset() { this.v = 0; this.s = 0; this.lastT = null; this.offSince = null; }

    fresh(x, ms, now) { return x && now - x.t <= ms; }

    /** advance to `now`; returns the fused estimate. Call often (demo/car: ~20-50 ms). */
    tick(now) {
        const o = this.o;
        if (this.lastT === null) this.lastT = now;
        let dt = (now - this.lastT) / 1000;
        this.lastT = now;
        if (dt <= 0) return this.out(now);
        if (dt > 0.5) dt = 0.5;                                  // a long gap: don't integrate junk

        const w = this.fresh(this._w, o.freshWheelMs, now) ? this._w : null;
        const a = this.fresh(this._a, o.freshAccelMs, now) ? this._a : null;
        const g = this.fresh(this._g, o.freshGpsMs, now) && this._g.good ? this._g : null;
        const standing = w && w.v < o.zuptKmh * KMH && this.v < o.zuptMaxKmh * KMH && (!a || Math.abs(a.a - this.accelBias) < o.zuptAcc);

        // learn the accel zero only when genuinely standing (wheel ~0 AND accel ~0 - a lagged wheel reads 0
        // at launch while the car already pulls, so wheel alone is not enough); wheel factor from gps when steady
        if (standing && this._a) this.accelBias += o.biasRate * (this._a.a - this.accelBias);
        if (g && w && g.v > o.calMinKmh * KMH && w.v > 1 && a && Math.abs(a.a - this.accelBias) < o.calMaxAcc) {
            const ratio = g.v / w.v;
            if (ratio > 0.8 && ratio < 1.25) this.wheelCal += o.calRate * (ratio - this.wheelCal);
            if (this.wheelCal < 0.9) this.wheelCal = 0.9; else if (this.wheelCal > 1.1) this.wheelCal = 1.1;
        }

        if (standing) { this.v = 0; this.spin = false; return this.out(now); }

        // the fused speed is accel-integrated (no lag); wheel + gps correct its drift
        const acc = a ? (a.a - this.accelBias) : 0;
        this.v += acc * dt;
        // target = wheel led forward to now (de-lagged): valid (now - w.t) + leadS ago
        const target = w ? this.wheelCal * w.v + acc * ((now - w.t) / 1000 + o.leadS) : null;
        if (w) {
            const margin = o.spinMarginKmh * KMH + o.spinMarginPct * this.v;
            // led wheel faster than physics allows = spinning - only while the car pulls (app opened rolling: not spin)
            this.spin = target > this.v + margin && acc > o.zuptAcc;
            // far slower than the accel allows = a dropout (car: the speed read 0 mid-run, the run ended and the
            // spin gate then locked the wheel out). Either way ignored for maxOffMs at most, then the wheel is right.
            const off = this.spin || target < this.v - margin;
            if (!off) this.offSince = null; else if (this.offSince === null) this.offSince = now;
            if (!off || now - this.offSince > o.maxOffMs) this.v += Math.min(1, o.Kw * dt) * (target - this.v);
        }
        // gps can't spin: it corrects - but it is ~1 Hz and its value is held, so lead it forward with accel too
        // (else a 1 s-old fix drags v back during a hard pull). Only a gps that agrees with the wheel: its scale
        // is unknown (on the car speedGPSCAN read ~17000-19000 at 1-60 km/h and dragged the speed there)
        if (g) {
            const gt = g.v + acc * (now - g.t) / 1000;
            const agrees = gt < o.gpsMaxKmh * KMH && (target === null || Math.abs(gt - target) < Math.max(o.gpsTolKmh * KMH, o.gpsTolPct * target));
            if (agrees) this.v += Math.min(1, o.Kg * dt) * (gt - this.v);
        }
        if (this.v < 0) this.v = 0;
        this.s += this.v * dt;
        return this.out(now);
    }

    out(now) { return { t: now, vKmh: this.v / KMH, distM: this.s }; }

    /** which inputs are live + the learned corrections (for the status line) */
    status(now) {
        const o = this.o;
        return {
            wheel: this.fresh(this._w, o.freshWheelMs, now),
            accel: this.fresh(this._a, o.freshAccelMs, now),
            gps: this.fresh(this._g, o.freshGpsMs, now) && this._g.good,
            cal: this.wheelCal, bias: this.accelBias, spin: !!this.spin,
        };
    }
}

module.exports = { Fuser };

// --- self-check (node fuse.js): synthetic 0-100 launches. (1) clean: fused within 0.12 s of truth.
// (2) wheelspin at launch (wheel reads high while the accel is honest): fusion beats the plain wheel.
const { RunTimer } = require('./timer');
function timeRun(samples) {
    const timer = new RunTimer([{ key: '0-100', from: 0, to: 100 }], {});
    let res = null; timer.onDone = (r) => { res = r; };
    for (let t = -1500; t < 0; t += 50) { timer.feed(t, 0); timer.idle(t); }
    samples.forEach((s) => timer.feed(s.t, s.v));
    timer.idle(9000);
    return res ? res.result['0-100'] : timer.result['0-100'];
}
function run(wheelKmh, accelMs2, cruise, gpsKmh) {   // functions of t(ms) -> fused + plain-wheel 0-100 times
    const A = 5.0, truth = (100 / 3.6) / A;
    gpsKmh = gpsKmh || ((t) => A * (t / 1000) * 3.6);
    const f = new Fuser();
    // optional prior steady cruise so gps can calibrate the wheel factor (as on the car, before a run)
    if (cruise) for (let t = -12000, lw = -99999, lg = -99999; t < -1500; t += 20) {
        if (t - lw >= 100) { f.wheel(60 * 1.03, t); lw = t; }      // 60 km/h, wheel reads +3% high
        f.accel(0, t);
        if (t - lg >= 1000) { f.gps(60, true, t); lg = t; }        // gps truth 60 -> learns cal ~0.97
        f.tick(t);
    }
    f.reset();
    const fused = [], wheelS = [];
    let lastW = -1, lastG = -1;
    for (let t = 0; t <= 8000; t += 20) {
        if (t - lastW >= 100) { const wv = wheelKmh(t); f.wheel(wv, t); wheelS.push({ t, v: wv }); lastW = t; }
        f.accel(accelMs2(t), t);
        if (t - lastG >= 1000) { f.gps(gpsKmh(t), true, t); lastG = t; }   // 1 Hz truth
        const s = f.tick(t); fused.push({ t, v: s.vKmh });
    }
    return { truth, fused: timeRun(fused), wheel: timeRun(wheelS), vmax: Math.max(...fused.map((x) => x.v)) };
}
function demo() {
    const assert = require('assert');
    const A = 5.0;
    // 1) clean: wheel lags 250 ms + reads 3% high; accel honest; gps calibrated the +3% out on a prior cruise
    const clean = run((t) => A * Math.max(0, (t - 250) / 1000) * 3.6 * 1.03, () => A + (Math.random() - 0.5) * 0.6, true);
    const ef = Math.abs(clean.fused - clean.truth);
    console.log(`clean:     truth ${clean.truth.toFixed(3)} | fused ${clean.fused.toFixed(3)} (err ${ef.toFixed(3)}) | wheel ${clean.wheel.toFixed(3)} (err ${Math.abs(clean.wheel - clean.truth).toFixed(3)})`);
    assert(ef < 0.08, 'fused 0-100 within 0.08 s of truth (calibrated)');
    assert(ef < Math.abs(clean.wheel - clean.truth), 'fusion beats the plain wheel');
    // 2) wheelspin: the first 1.5 s the wheel reads 1.3x (spinning) then grip returns; accel stays honest
    const spin = run((t) => A * Math.max(0, (t - 100) / 1000) * 3.6 * (t < 1500 ? 1.3 : 1.0), () => A + (Math.random() - 0.5) * 0.6);
    const efs = Math.abs(spin.fused - spin.truth);
    const ews = spin.wheel === undefined ? Infinity : Math.abs(spin.wheel - spin.truth);   // undefined = the run aborted on the grip-return speed drop
    console.log(`wheelspin: truth ${spin.truth.toFixed(3)} | fused ${spin.fused.toFixed(3)} (err ${efs.toFixed(3)}) | wheel ${spin.wheel === undefined ? 'FAILED (run aborted)' : spin.wheel.toFixed(3) + ' (err ' + ews.toFixed(3) + ')'}`);
    assert(spin.fused !== undefined && efs < 0.25, 'fusion still measures a wheelspin launch accurately');
    assert(efs < ews, 'fusion beats the plain wheel under wheelspin');
    // 3) gps in a wrong scale (as on the car: ~17000 + ~33 per km/h): ignored, the speed stays real
    const bad = run((t) => A * Math.max(0, (t - 250) / 1000) * 3.6, () => A + (Math.random() - 0.5) * 0.6, false, (t) => 17000 + 33 * A * (t / 1000) * 3.6);
    console.log(`bad gps:   truth ${bad.truth.toFixed(3)} | fused ${bad.fused === undefined ? '-' : bad.fused.toFixed(3)} | max ${bad.vmax.toFixed(0)} km/h`);
    assert(bad.vmax < 200 && bad.fused !== undefined && Math.abs(bad.fused - bad.truth) < 0.25, 'a wrong-scale gps never drags the speed');
    // 4) dropout (car: the speed read 0 mid-run and ended it): wheel 0 for 100 ms at ~50 km/h, accel silent for 300 ms
    const drop = run((t) => (t >= 2800 && t < 2900 ? 0 : A * Math.max(0, (t - 250) / 1000) * 3.6),
        (t) => (t >= 2700 && t < 3000 ? NaN : A + (Math.random() - 0.5) * 0.6));
    console.log(`dropout:   truth ${drop.truth.toFixed(3)} | fused ${drop.fused === undefined ? 'FAILED (run ended)' : drop.fused.toFixed(3)}`);
    assert(drop.fused !== undefined && Math.abs(drop.fused - drop.truth) < 0.25, 'a short speed dropout neither ends the run nor zeroes the speed');
    console.log('fuse demo: ok');
}
if (require.main === module) demo();

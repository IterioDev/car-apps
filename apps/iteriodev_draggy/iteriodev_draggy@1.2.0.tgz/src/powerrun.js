// Ported from cauliflowermossgrape/idrive7-apps (MIT License, Copyright (c) 2026 cauliflowermossgrape): apps/dyno/main.js @ c67ea17.
'use strict';
/*
 * Drag Timer · Power run: a virtual dyno from one full-throttle pull in one gear. Pure (no I/O, no timers), Node 8.
 * The kit's physics, binning and smoothing; its pull detection made one-gear, with states and abort reasons.
 *   wheel power = m*a*v + 0.5*rho*CdA*v^3 (air) + Crr*m*g*v (rolling)      crank power = wheel / (1 - loss)
 *   torque = crank power / engine angular speed; the DME's torque (FES) binned beside it
 *
 *   const pr = new PowerRun({ weight: 1750, body: 'coupe', loss: 15, powerUnit: 'hp', torqueUnit: 'nm' });
 *   pr.feed({ t: Date.now(), kmh, rpm, accel, torqueNm, pedal });   // in order; accel / torqueNm / pedal optional
 *   pr.state     idle | ready | running | done | aborted      pr.reason (aborted): gear | lift | short | sampling
 *   pr.hpNow     crank hp of the last sample while pulling (else null)
 *   pr.last      the run just finished: { at, points: [{ rpm, hp, nm, ecuNm? }], peak, weight, body, loss, v0, v1 }
 *   pr.view(run) the run in the chosen units + its difference at the peaks to the baseline (pr.pin(run) / pin(null))
 *   JSON.stringify(pr) / pr.fromJSON(obj): the saved runs (newest first, at most MAX_RUNS) and the baseline
 *   pr.settings  change in place (the Car sub-page); a run keeps the weight / body / loss it was measured with
 *   pr.cancel()  the pull in progress thrown away (the app's Cancel); the next one needs a lift first
 *
 * A pull starts at > 0.12 g above 15 km/h and 1200 rpm (pedal >= 90 % when given) and ends on a shift (rpm/speed
 * off by > 4 % twice from its reference, which follows a rise at once for the first 600 ms - a speed signal lagging
 * the engine speed raises the ratio when a pull starts, Drag Timer 1.2.0 - and else slowly), a lift (not pulling for
 * 500 ms) or a hole > 300 ms in the samples. Whatever ended it, it is a
 * run (done) when it covered >= 1500 rpm in >= 16 samples; else aborted: gear (shifted), lift (pedal let go),
 * short (the pull faded: the limiter, or a lift without a pedal signal), sampling (the hole). Samples after the last
 * new rpm high are dropped (the limiter). done / aborted stay 5 s. After a run a new pull needs a lift first (a shift
 * at the limiter starts nothing in the next gear); after an abort it starts at once (a kickdown's lower gear).
 * ready = cruising at 1500-3000 rpm above 15 km/h: floor it.
 */
const BIN = 100, MIN_SPAN = 1500, MIN_PTS = 16, MAX_RUNS = 20;
const RHO = 1.2, CRR = 0.013, G = 9.80665, W_HP = 745.7;
const BODIES = { coupe: { label: 'Coupe / sedan', cda: 0.62 }, wagon: { label: 'Touring / hatch', cda: 0.72 }, suv: { label: 'SUV', cda: 0.95 } };
const POWER = { hp: [W_HP, 'hp'], ps: [735.5, 'PS'], kw: [1000, 'kW'] };      // W per unit, label
const TORQUE = { nm: [1, 'Nm'], lbft: [0.73756, 'lb-ft'] };                    // unit per Nm, label
const DEFAULTS = { weight: 1750, body: 'coupe', loss: 15, powerUnit: 'hp', torqueUnit: 'nm' };
const HARD_G = 0.12, PEDAL_FULL = 90, READY_RPM = [1500, 3000];
const GEAR_TOL = 0.04, LIFT_MS = 500, MAX_GAP_MS = 300, HOLD_MS = 5000, DERIV_MS = 250, TQ_BAND = 0.95;

const num = (x) => typeof x === 'number' && isFinite(x);
const r1 = (x) => Math.round(x * 10) / 10;
const avg = (xs) => xs.reduce((a, x) => a + x, 0) / xs.length;

/* crank power (W) at accel a (m/s^2), speed v (m/s): the kit's formula */
function crankW(set, a, v) {
    const m = +set.weight > 0 ? +set.weight : DEFAULTS.weight;
    const cda = (BODIES[set.body] || {}).cda || 0.65;
    const loss = Math.min(Math.max(+set.loss || 0, 0), 50);
    return (m * a * v + 0.5 * RHO * cda * v * v * v + CRR * m * G * v) / (1 - loss / 100);
}

/* the kit's analyse: bin per 100 rpm, smooth power over 5 bins, torque from the smoothed power; peaks + torque band */
function analyse(pts, at, set) {
    const bins = {};
    pts.forEach((x) => { const b = Math.round(x.rpm / BIN) * BIN; (bins[b] = bins[b] || []).push(x); });
    const raw = Object.keys(bins).map(Number).sort((a, b) => a - b).map((k) => {
        const ecu = bins[k].map((x) => x.ecu).filter(num);
        return { rpm: k, p: avg(bins[k].map((x) => x.p)), ecu: ecu.length ? avg(ecu) : null };
    });
    const points = raw.map((c, i) => {
        const p = Math.max(0, avg(raw.slice(Math.max(0, i - 2), i + 3).map((x) => x.p)));
        const o = { rpm: c.rpm, hp: r1(p / W_HP), nm: r1(p / (c.rpm * Math.PI / 30)) };
        if (c.ecu !== null) o.ecuNm = r1(c.ecu);
        return o;
    });
    let pi = 0, ti = 0;
    points.forEach((c, i) => { if (c.hp > points[pi].hp) pi = i; if (c.nm > points[ti].nm) ti = i; });
    let lo = ti, hi = ti;
    const floor = points[ti].nm * TQ_BAND;
    while (lo > 0 && points[lo - 1].nm >= floor) lo--;
    while (hi < points.length - 1 && points[hi + 1].nm >= floor) hi++;
    return {
        at, points,
        peak: { hp: points[pi].hp, hpRpm: points[pi].rpm, nm: points[ti].nm, nmRpm: points[ti].rpm, band: [points[lo].rpm, points[hi].rpm] },
        weight: set.weight, body: set.body, loss: set.loss, v0: r1(pts[0].v), v1: r1(pts[pts.length - 1].v),
    };
}

class PowerRun {
    constructor(settings) {
        this.settings = Object.assign({}, DEFAULTS, settings);
        this.runs = []; this.baseline = null; this.last = null;
        this.state = 'idle'; this.reason = null; this.hpNow = null;
        this.pull = null; this.prev = null; this.hist = []; this.until = 0; this.wait = false;
    }

    feed(s) {
        if (!s || !num(s.t) || !num(s.kmh) || !num(s.rpm) || (this.prev && s.t <= this.prev.t)) return this.state;
        const gap = this.prev ? s.t - this.prev.t : 0;
        this.prev = s;
        let v = s.kmh / 3.6, rpm = s.rpm, a = s.accel;
        const h = this.hist;
        h.push(s);
        while (h.length > 2 && s.t - h[1].t >= DERIV_MS) h.shift();
        if (!num(a)) {
            // from the speed over the last 250 ms, paired with the window's midpoint (exact for m*a*v at constant power)
            const dt = (s.t - h[0].t) / 1000;
            a = dt >= 0.1 && dt <= 1 ? (v - h[0].kmh / 3.6) / dt : null;
            v = (v + h[0].kmh / 3.6) / 2; rpm = (rpm + h[0].rpm) / 2;
        }
        const lifted = num(s.pedal) && s.pedal < PEDAL_FULL;
        const hard = num(a) && a > HARD_G * G && s.kmh > 15 && s.rpm > 1200 && !lifted;
        const pt = hard ? { rpm, p: crankW(this.settings, a, v), v: s.kmh, ecu: s.torqueNm } : null;
        this.hpNow = pt && pt.p / W_HP;
        if (!hard) this.wait = false;
        const p = this.pull;
        if (p) {
            if (gap > MAX_GAP_MS) return this._end('sampling', hard);
            if (!hard) {
                if (p.soft === null) p.soft = s.t;
                return s.t - p.soft > LIFT_MS ? this._end(lifted ? 'lift' : 'short', false) : this.state;
            }
            p.soft = null;
            const k = s.rpm / s.kmh;
            if (Math.abs(k - p.k) / p.k > GEAR_TOL) return ++p.off >= 2 ? this._end('gear', true) : this.state;
            // a rise is followed at once for the first 600 ms (a speed that lags the engine speed raises k when a pull
            // starts), later and a fall slowly (an upshift lowers k, a downshift or wheelspin raises it: even one spread
            // over 400-500 ms ends the pull)
            p.off = 0; p.k = k > p.k && p.pts.length < 12 ? k : p.k + (k - p.k) * 0.1;
            p.pts.push(pt);
            if (s.rpm > p.max) { p.max = s.rpm; p.top = p.pts.length; }
            return this.state;
        }
        if (hard && !this.wait) {
            this.pull = { at: s.t, k: s.rpm / s.kmh, off: 0, soft: null, max: s.rpm, top: 1, pts: [pt] };
            this.state = 'running'; this.reason = null;
        } else if (!((this.state === 'done' || this.state === 'aborted') && s.t < this.until)) {
            this.state = !hard && s.kmh > 15 && s.rpm >= READY_RPM[0] && s.rpm <= READY_RPM[1] ? 'ready' : 'idle';
            this.reason = null;
        }
        return this.state;
    }

    _end(why, hard) {
        const p = this.pull, pts = p.pts.slice(0, p.top), r = pts.map((x) => x.rpm);
        this.pull = null; this.hpNow = null; this.until = this.prev.t + HOLD_MS;
        if (pts.length >= MIN_PTS && Math.max.apply(null, r) - Math.min.apply(null, r) >= MIN_SPAN) {
            this.last = analyse(pts, p.at, this.settings);
            this.runs = [this.last].concat(this.runs).slice(0, MAX_RUNS);
            this.state = 'done'; this.reason = null; this.wait = hard;
        } else { this.state = 'aborted'; this.reason = why; }
        return this.state;
    }

    /* the app's Cancel while pulling: the pull thrown away (no run, no abort); a new one needs a lift first, as after a run */
    cancel() {
        this.pull = null; this.hpNow = null; this.wait = true; this.state = 'idle'; this.reason = null;
        return this.state;
    }

    pin(run) { this.baseline = run || null; return this.baseline; }

    /* peak differences run - baseline (hp, Nm); null without a baseline or for the baseline itself */
    compare(run, base) {
        const b = base === undefined ? this.baseline : base;
        if (!run || !b || run.at === b.at) return null;
        return { hp: r1(run.peak.hp - b.peak.hp), nm: r1(run.peak.nm - b.peak.nm) };
    }

    /* a run in the settings' units, for the chart and the peak readouts */
    view(run) {
        if (!run) return null;
        const P = POWER[this.settings.powerUnit] || POWER.hp, T = TORQUE[this.settings.torqueUnit] || TORQUE.nm;
        const pw = (hp) => r1(hp * W_HP / P[0]), tq = (nm) => r1(nm * T[0]);
        const d = this.compare(run), pk = run.peak;
        return {
            powerUnit: P[1], torqueUnit: T[1],
            points: run.points.map((c) => {
                const o = { rpm: c.rpm, power: pw(c.hp), torque: tq(c.nm) };
                if (num(c.ecuNm)) o.ecuTorque = tq(c.ecuNm);
                return o;
            }),
            peak: { power: pw(pk.hp), powerRpm: pk.hpRpm, torque: tq(pk.nm), torqueRpm: pk.nmRpm, band: pk.band },
            delta: d && { power: pw(d.hp), torque: tq(d.nm) },
        };
    }

    toJSON() { return { runs: this.runs, baseline: this.baseline }; }

    fromJSON(o) {
        const ok = (r) => !!(r && Array.isArray(r.points) && r.points.length && r.peak && num(r.peak.hp) && num(r.peak.nm));
        this.runs = (o && Array.isArray(o.runs) ? o.runs.filter(ok) : []).slice(0, MAX_RUNS);
        this.baseline = o && ok(o.baseline) ? o.baseline : null;
        this.last = this.runs[0] || null;
        return this;
    }
}

function test() {
    const assert = require('assert');
    const near = (x, y, tol, what) => assert(Math.abs(x - y) <= tol, `${what}: ${x} vs ${y} (+/-${tol})`);
    const nmAt = (hp, rpm) => hp * W_HP / (rpm * Math.PI / 30);
    let t = 1e6;
    // a constant-crank-power car in one gear (k rpm per km/h): m dv/dt = (wheel power - air - rolling) / v, 1 ms steps,
    // a sample every 50 ms (accel from the "sensor" unless derive), the DME torque = the true crank torque; lag: the
    // speed that many samples behind the engine speed (on the car they are two signals)
    function pull(pr, o) {
        const set = pr.settings, m = set.weight, cda = BODIES[set.body].cda, k = o.k || 50;
        const Pw = o.hp * W_HP * (1 - set.loss / 100), seen = [];
        t += 2000;
        let v = o.from / k / 3.6, next = t;
        while (v * 3.6 * k < o.to) {
            const a = (Pw - 0.5 * RHO * cda * v * v * v - CRR * m * G * v) / (m * v);
            if (t >= next) {
                const rpm = v * 3.6 * k;
                seen.push(v * 3.6);
                pr.feed({ t, kmh: seen[Math.max(0, seen.length - 1 - (o.lag || 0))], rpm, accel: o.derive ? undefined : a, torqueNm: nmAt(o.hp, rpm), pedal: o.pedal });
                next += 50;
            }
            v += a / 1000; t += 1;
        }
        return v * 3.6;
    }
    const after = (pr, n, f) => { for (let i = 0; i < n; i++) { t += 50; pr.feed(f()); } return pr.state; };
    const fresh = () => new PowerRun({ weight: 1600, body: 'coupe', loss: 15 });
    const lift = (pr, kmh) => after(pr, 12, () => ({ t, kmh, rpm: kmh * 50, accel: -0.5 }));
    const range = (run) => [Math.min.apply(null, run.points.map((c) => c.hp)), Math.max.apply(null, run.points.map((c) => c.hp))];

    // idle / ready, then the 300 hp pull 2400 -> 7000 rpm with the accel sensor: every bin 300 hp, torque = P / w
    let pr = fresh();
    assert.strictEqual(pr.feed({ t, kmh: 0, rpm: 800, accel: 0 }), 'idle');
    t += 50; assert.strictEqual(pr.feed({ t, kmh: 60, rpm: 2500, accel: 0 }), 'ready');
    let kmh = pull(pr, { hp: 300, from: 2400, to: 7000 });
    assert.strictEqual(pr.state, 'running'); near(pr.hpNow, 300, 0.5, 'power now');
    assert.strictEqual(lift(pr, kmh), 'done');
    const sensor = pr.last, b5 = sensor.points.filter((c) => c.rpm === 5000)[0];
    sensor.points.forEach((c) => near(c.hp, 300, 1.5, `hp @${c.rpm}`));
    near(b5.nm, nmAt(300, 5000), 1, 'Nm @5000'); near(b5.ecuNm, b5.nm, 5, 'DME Nm @5000');
    assert.deepStrictEqual([sensor.points[0].rpm, sensor.points[sensor.points.length - 1].rpm >= 6900], [2400, true]);
    assert.deepStrictEqual([sensor.peak.nmRpm, sensor.peak.band], [2400, [2400, 2500]]);     // constant power: torque falls with rpm
    // the same pull without the accel sensor: derived from the speed
    pr = fresh(); kmh = pull(pr, { hp: 300, from: 2400, to: 7000, derive: true });
    assert.strictEqual(after(pr, 20, () => ({ t, kmh, rpm: kmh * 50 })), 'done');     // the derived accel lags 250 ms
    const derived = pr.last;
    derived.points.forEach((c) => near(c.hp, 300, 3, `derived hp @${c.rpm}`));

    // aborts: a shift at 3400 rpm (50 -> 35 rpm per km/h) still pulling; the lower gear's pull starts at once (kickdown)
    pr = fresh(); kmh = pull(pr, { hp: 300, from: 2400, to: 3400 });
    after(pr, 2, () => ({ t, kmh, rpm: kmh * 35, accel: 5 }));
    assert.deepStrictEqual([pr.state, pr.reason], ['aborted', 'gear']);
    assert.strictEqual(after(pr, 1, () => ({ t, kmh, rpm: kmh * 35, accel: 5 })), 'running');
    // the pedal let go at 3400 rpm
    pr = fresh(); kmh = pull(pr, { hp: 300, from: 2400, to: 3400, pedal: 100 });
    after(pr, 12, () => ({ t, kmh, rpm: kmh * 50, accel: -0.5, pedal: 0 }));
    assert.deepStrictEqual([pr.state, pr.reason], ['aborted', 'lift']);
    // from 6000 rpm into the 7000 limiter, pedal still down: too short
    pr = fresh(); kmh = pull(pr, { hp: 300, from: 6000, to: 7000, pedal: 100 });
    after(pr, 12, () => ({ t, kmh, rpm: 7000, accel: 0.2, pedal: 100 }));
    assert.deepStrictEqual([pr.state, pr.reason], ['aborted', 'short']);
    // a 400 ms hole in the samples
    pr = fresh(); kmh = pull(pr, { hp: 300, from: 2400, to: 3000 });
    t += 400; pr.feed({ t, kmh, rpm: kmh * 50, accel: 5 });
    assert.deepStrictEqual([pr.state, pr.reason], ['aborted', 'sampling']);
    // a shift at the limiter after a full pull is a run; pulling on in the next gear starts nothing; done stays 5 s
    pr = fresh(); kmh = pull(pr, { hp: 300, from: 2400, to: 6800 });
    assert.strictEqual(after(pr, 2, () => ({ t, kmh, rpm: kmh * 35, accel: 5 })), 'done');
    assert.strictEqual(after(pr, 20, () => ({ t, kmh, rpm: kmh * 35, accel: 5 })), 'done');
    t += HOLD_MS; assert.strictEqual(pr.feed({ t, kmh: 60, rpm: 2500, accel: 0 }), 'ready');

    // baseline: 300 hp pinned, then 330 hp: +30 hp, +89 Nm at the peaks (both at 2400 rpm)
    pr = fresh(); lift(pr, pull(pr, { hp: 300, from: 2400, to: 7000 }));
    const base = pr.pin(pr.last);
    lift(pr, pull(pr, { hp: 330, from: 2400, to: 7000 }));
    const d = pr.compare(pr.last);
    near(d.hp, 30, 0.5, 'delta hp'); near(d.nm, nmAt(30, 2400), 1, 'delta Nm');
    assert.strictEqual(pr.compare(base), null);
    // units
    assert.deepStrictEqual([pr.view(pr.last).powerUnit, pr.view(pr.last).torqueUnit], ['hp', 'Nm']);
    pr.settings.powerUnit = 'kw'; pr.settings.torqueUnit = 'lbft';
    let vw = pr.view(pr.last);
    assert.deepStrictEqual([vw.powerUnit, vw.torqueUnit], ['kW', 'lb-ft']);
    near(vw.peak.power, 330 * 0.7457, 0.5, 'kW'); near(vw.delta.power, 30 * 0.7457, 0.3, 'delta kW');
    near(vw.peak.torque, pr.last.peak.nm * 0.73756, 0.2, 'lb-ft'); near(vw.points[0].ecuTorque, vw.points[0].torque, 10, 'DME lb-ft');
    pr.settings.powerUnit = 'ps'; vw = pr.view(pr.last);
    near(vw.peak.power, 330 * W_HP / 735.5, 0.5, 'PS'); assert.strictEqual(vw.powerUnit, 'PS');

    // saved runs: 20 more pulls keep the newest 20; JSON round trip keeps the baseline (no longer in the list)
    for (let i = 0; i < 20; i++) lift(pr, pull(pr, { hp: 250 + i, from: 2400, to: 4200 }));
    assert.strictEqual(pr.runs.length, MAX_RUNS); assert.strictEqual(pr.runs[0], pr.last);
    const back = new PowerRun().fromJSON(JSON.parse(JSON.stringify(pr)));
    assert.deepStrictEqual([back.runs.length, back.baseline.at, back.runs.some((r) => r.at === base.at)], [MAX_RUNS, base.at, false]);
    near(back.compare(back.runs[0]).hp, 269 - 300, 0.5, 'delta after load');
    assert.deepStrictEqual(new PowerRun().fromJSON({ runs: [null, {}, { points: [] }], baseline: 'x' }).toJSON(), { runs: [], baseline: null });
    assert.strictEqual(new PowerRun().fromJSON(null).last, null);

    // Drag Timer 1.2.0: the speed late behind the engine speed is no shift (its ratio rises when the pull starts: followed
    // at once for 600 ms, not by the slow average); a shift still is, with the speed late or spread out
    [3, 6].forEach((lag) => {
        pr = fresh(); kmh = pull(pr, { hp: 300, from: 2400, to: 7000, lag });
        assert.strictEqual(lift(pr, kmh), 'done', `the speed ${lag * 50} ms late: a run`);
        assert.strictEqual(pr.last.points[0].rpm, 2400, `the speed ${lag * 50} ms late: one pull from its first sample (no abort and restart)`);
        near(pr.last.peak.hp, 300, 2 * lag, `peak hp with the speed ${lag * 50} ms late`);
    });
    // a gearbox, 2 s into a 250 hp pull of a 1750 kg coupe from 50 km/h (ramp: the ratio k0 -> k1 rpm per km/h over n
    // samples from sample `at`), the speed lag samples late, no torque while cut(i): 'done' (ended there) or the abort's reason
    const ramp = (k0, k1, at, n) => (i) => (i < at ? k0 : i >= at + n ? k1 : k0 + (k1 - k0) * (i - at) / n);
    function gearbox(o) {
        const p2 = new PowerRun({ weight: 1750, body: 'coupe', loss: 15 }), m = 1750, Pw = 250 * W_HP * 0.85, seen = [];
        let v = 50 / 3.6;
        for (let i = 0; i < 160; i++) {
            const a = o.cut && o.cut(i) ? -0.3 : (Pw - 0.5 * RHO * BODIES.coupe.cda * v * v * v - CRR * m * G * v) / (m * v);
            seen.push(v * 3.6); t += 50;
            const st = p2.feed({ t, kmh: seen[Math.max(0, seen.length - 1 - (o.lag || 0))], rpm: v * 3.6 * o.k(i), accel: a });
            if (st === 'done' || st === 'aborted') return st === 'done' ? st : p2.reason;
            v += a * 0.05;
        }
        return p2.state;
    }
    assert.strictEqual(gearbox({ k: () => 50, lag: 8 }), 'running', 'the speed 400 ms late, no shift: one clean pull');
    assert.strictEqual(gearbox({ k: ramp(40, 50, 30, 10) }), 'gear', 'a downshift (+25 %) over 500 ms: a shift');
    assert.strictEqual(gearbox({ k: ramp(40, 50, 30, 10), lag: 2 }), 'gear', 'a downshift over 500 ms, the speed 100 ms late: a shift');
    [['at once', ramp(50, 37.5, 40, 0), 2], ['over 400 ms', ramp(50, 37.5, 40, 8), 2], ['-16 % over 600 ms', ramp(50, 42, 40, 12), 6],
        ['with a 150 ms torque cut', ramp(50, 37.5, 40, 3), 2, (i) => i >= 40 && i < 43]].forEach((c) =>
        assert.strictEqual(gearbox({ k: c[1], lag: c[2], cut: c[3] }), 'done', `an upshift ${c[0]}, the speed ${c[2] * 50} ms late: ends the pull`));
    pr = fresh(); kmh = pull(pr, { hp: 300, from: 2400, to: 3400, lag: 3 });
    after(pr, 2, () => ({ t, kmh, rpm: kmh * 35, accel: 5 }));
    assert.deepStrictEqual([pr.state, pr.reason], ['aborted', 'gear'], 'a shift with the speed late: still a shift');
    pr = fresh(); kmh = pull(pr, { hp: 300, from: 2400, to: 3400 });
    let why = null;
    for (let i = 1; i <= 8 && !why; i++) { t += 50; pr.feed({ t, kmh, rpm: kmh * Math.max(40, 50 - 10 * i / 6), accel: 5 }); if (pr.state === 'aborted') why = pr.reason; }
    assert.strictEqual(why, 'gear', 'an upshift spread over 300 ms (20 % in six samples): still a shift');
    // Cancel (the app's button while pulling): the pull thrown away (no run, no abort), nothing new until it stops pulling
    pr = fresh(); kmh = pull(pr, { hp: 300, from: 2400, to: 4500 });
    assert.deepStrictEqual([pr.cancel(), pr.last, pr.hpNow], ['idle', null, null]);
    assert.strictEqual(after(pr, 5, () => ({ t, kmh, rpm: kmh * 50, accel: 5 })), 'idle', 'still on the throttle: no new pull');
    lift(pr, kmh);
    assert.strictEqual(pr.last, null, 'Cancel, then a lift: still no run');
    assert.strictEqual(after(pr, 1, () => ({ t, kmh, rpm: kmh * 50, accel: 5 })), 'running', 'after a lift: a new pull');

    const f = (x) => x.toFixed(1);
    console.log(`powerrun self-check ok: 300 hp pull 2400-7000 rpm -> sensor ${range(sensor).map(f).join('-')} hp (${sensor.points.length} bins), `
        + `derived ${range(derived).map(f).join('-')} hp, ${b5.nm} Nm @5000 (DME ${b5.ecuNm}), torque band ${sensor.peak.band.join('-')}`);
}

module.exports = { PowerRun, analyse, BODIES, POWER, TORQUE, DEFAULTS, MAX_RUNS, test };
if (require.main === module) test();

'use strict';
/*
 * iteriodev_draggy: a drag/acceleration timer (tile "Drag Timer"). Research: analysis/idrive7-apps-merge.md,
 * the repo's draggy. Improved for ID8 with sensor fusion (fuse.js): the timer is fed a FUSED speed from
 *   - Vehicle2.statusCarSpeed2  (wheel/CoG speed, laggy + tyre-biased)
 *   - CDS2 longitudinal accel   (high-rate, low-lag; de-lags and rejects wheelspin)
 *   - GPSData ground speed      (~1 Hz; auto-calibrates the wheel factor and anchors the absolute)
 * so a wheelspin launch rides the honest accel and the tyre/speedo bias is calibrated out. The run timer
 * (timer.js, ported from the repo, MIT) arms itself at a standstill and interpolates each split.
 *
 * Screens: drawn by the GPU renderer (mgu-renderd, scripts/renderd), designed in the HMI UI builder:
 * apps/hmi-ui-builder/projects/drag-timer.json, made by scripts/oap-tools/make_draggy_project.js and exported into
 * this folder (rhmiData/ = one empty RHMI host state per screen, renderer/ = screens.json + the builder's runtime).
 * 1.2.0, the Telemetry design (iDrive 8 only): tabs Run (home: run time, speed, the run's speed over time, splits,
 * units / distance, reset) | Power run (power, and its Car sub-page car with Back) | Best times (bests). Timed from
 * the launch (no one-foot rollout). Power run (powerrun.js, ported from idrive7-apps' dyno, MIT): one full-throttle
 * pull in one gear, fed only while its page is open (a drag launch is no power run) with the wheel speed (as the
 * kit: the fused speed's lead overshoots when a pull starts), the CDS2 accel, CDS engine speed and FES crankshaft
 * torque (as Car Data reads them, car-confirmed there); no pedal (the bus pedal reads 100 % at a light touch, Car
 * Data 1.0.7), so a lift ends a pull as a run or "too short".
 * The renderer gives the app the touches on its screens; the HMI's BACK / HOME / popups work through the host
 * states (screenapp.js bindHosts). Start, tile and shutdown: the shared OnlineApp host (oap-shared/online-host.js);
 * a source package since 1.1.8 (1.1.8: ID7 + ID8 RHMI; 1.2.0: iDrive 8 only).
 * 1.1.7 (car: the speed sometimes read 0 mid-run and the time started over): one wheel reading of 0 pulled the
 * fused speed >5 km/h down (run ended) or zeroed it (standstill rule), then the wheelspin gate locked the wheel
 * out, so the speed sat near 0, the timer re-armed and launched again. fuse.js now ignores a wheel the accel
 * contradicts (either way, 2 s at most), zeroes only a near-stopped speed, and calls it spin only while pulling.
 */
const fs = require('fs');
const path = require('path');
const util = require('util');
const someipBuilders                   = require('oap-sdk/src/someip/someipBuilders');
const { createHost }                   = require('./online-host.js');
const { RunTimer } = require('./timer.js');
const { Fuser }    = require('./fuse.js');
const { PowerRun, analyse, BODIES, POWER, TORQUE } = require('./powerrun.js');

const LOG = '[iteriodev_draggy]';
const STATES = ['home', 'bests', 'power', 'car'];   // screens = their RHMI host states (same names)

const DATA = path.join(__dirname, '..', '..', 'data');      // the app's data folder, beside the package root (the Store's)
const LOG_FILE = `${DATA}/draggy.log`;
const STORE_FILE = `${DATA}/draggy.json`;
const TICK_MS = 50;             // fuse tick + timer feed rate (poll handlers update the raw values between)
const POLL = { speed: 50, accel: 50, gps: 1000 };
const RETRY_MS = 30e3;

// ---- calibration (raw bus -> unit), car-confirmed in oap-cardash ---------------------------------
const kmh = (raw) => raw / 64;                       // Vehicle2.speedVehicleCentreOfGravity
const accelMs2 = (raw) => raw * 0.002 - 65;          // CDS2 longitudinal, m/s^2
const rpmOf = (raw) => raw * 0.25;                   // CDS AVL_RPM_ENG_CRSH
const nmOf = (raw) => raw * 0.5 - 1023.5;            // FES net crankshaft torque (0 Nm at raw 2047)
// GPSData speedGPSCAN scale is unknown -> a knob; the source row shows the raw value to calibrate, and a
// wrong scale only disables gps calibration (the fuser rejects an out-of-band ratio), it never harms.
let gpsScale = 1;                                    // speedGPSCAN * gpsScale = km/h (default: assume km/h)

const MPH = 1.609344;
const SPLITS = {
    kmh: [{ key: '0-50', label: '0-50 km/h', from: 0, to: 50 }, { key: '0-100', label: '0-100 km/h', from: 0, to: 100 },
        { key: '100-200', label: '100-200 km/h', from: 100, to: 200 }, { key: '0-200', label: '0-200 km/h', from: 0, to: 200 }],
    mph: [{ key: '0-30mph', label: '0-30 mph', from: 0, to: 30 * MPH }, { key: '0-60mph', label: '0-60 mph', from: 0, to: 60 * MPH },
        { key: '60-130mph', label: '60-130 mph', from: 60 * MPH, to: 130 * MPH }, { key: '0-100mph', label: '0-100 mph', from: 0, to: 100 * MPH }],
};
const DIST = {
    qm: { key: 'qm', label: '1/4 mile', dist: 402.336 }, em: { key: 'em', label: '1/8 mile', dist: 201.168 }, m1000: { key: 'm1000', label: '1000 m', dist: 1000 },
};
const UNIT_OPTS = ['kmh', 'mph'], DIST_OPTS = ['em', 'qm', 'm1000'];   // the order of the screens' tabs

// ---- log + store -----------------------------------------------------------------------------------
const errText = (e) => String(e && e.message || e).slice(0, 120);
function log() {
    const line = [new Date().toISOString()].concat([].slice.call(arguments)
        .map((x) => (typeof x === 'string' ? x : util.inspect(x, { depth: 4 }).slice(0, 2000)))).join(' ');
    console.error(LOG, line);
    try { if (fs.statSync(LOG_FILE).size > 256 * 1024) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* no file yet */ }
    try { fs.appendFileSync(LOG_FILE, `${line}\n`); } catch (e) { /* no data folder */ }
}
let store = { units: 'kmh', distance: 'qm', best: {} };
try { store = Object.assign(store, JSON.parse(fs.readFileSync(STORE_FILE, 'utf8'))); } catch (e) { /* defaults */ }
// the Power run: its Car settings (store.car) and the saved runs + baseline (store.power; fromJSON drops broken ones)
const power = new PowerRun(store.car).fromJSON(store.power);
const save = () => {
    try { fs.writeFileSync(STORE_FILE, JSON.stringify({ units: store.units, distance: store.distance, best: store.best, car: power.settings, power })); }
    catch (e) { log('store not saved:', e); }
};

// ---- sources + fusion ------------------------------------------------------------------------------
const raw = {};                 // name -> { v, t }
const link = {};                // source -> 'connecting' | 'ok' | 'ERR ...'
const fuse = new Fuser();
let speedKmh = 0;               // the fused speed, last tick

const SOURCES = {
    speed: ['de.bmw.infotainment.vehicle.Vehicle2', 'statusCarSpeed2', (x, t) => { if (x && typeof x.speedVehicleCentreOfGravity === 'number' && x.speedVehicleCentreOfGravity !== 65535) raw.speed = { v: kmh(x.speedVehicleCentreOfGravity), t }; }],
    accel: ['de.bmw.infotainment.vehicle.CDS2', 'statusLongitudinalAccelerationMassCenter', (x, t) => { if (x && typeof x.longitudinalAccelerationCentreOfGravity === 'number' && x.longitudinalAccelerationCentreOfGravity !== 65535) raw.accel = { v: accelMs2(x.longitudinalAccelerationCentreOfGravity), t }; }],
    gps: ['de.bmw.infotainment.GPSData', 'GPSPositionExtendedCAN', (x, t) => { if (x && typeof x.speedGPSCAN === 'number') { raw.gps = { v: x.speedGPSCAN * gpsScale, q: x.statusQualityPositionGPSCAN, t }; logGps(x, t); } }],
    // 1.2.0, the Power run: engine speed and the DME's crankshaft torque, where Car Data reads them
    rpm: ['de.bmw.infotainment.vehicle.CDS', 'statusEngineSpeed2', (x, t) => { if (x && typeof x.actualValueRPMEngineCrankshaft === 'number' && x.actualValueRPMEngineCrankshaft !== 65535) raw.rpm = { v: rpmOf(x.actualValueRPMEngineCrankshaft), t }; }],
    torque: ['de.bmw.infotainment.drivingexcitement.FES', 'statusActualValueTorque2', (x, t) => { if (x && typeof x.actualValueTorqueCrankshaft === 'number' && x.actualValueTorqueCrankshaft !== 65535) raw.torque = { v: nmOf(x.actualValueTorqueCrankshaft), t }; }],
};
// speedGPSCAN's scale is still unknown (car: ~17000-19000 at 1-60 km/h): the whole record once, then raw vs wheel
// speed every 2 s while moving, into draggy.log - enough points to fit the scale
let gpsLogged = 0;
function logGps(x, t) {
    if (!gpsLogged) log('gps record:', x);
    if (gpsLogged && (!raw.speed || raw.speed.v < 2 || t - gpsLogged < 2000)) return;
    gpsLogged = t;
    if (raw.speed) log('gps raw', x.speedGPSCAN, 'quality', x.statusQualityPositionGPSCAN, 'wheel kmh', raw.speed.v.toFixed(1));
}
const proxies = {};
function connect(name) {
    const [ifName, field, handler] = SOURCES[name];
    link[name] = link[name] || 'connecting';
    return someipBuilders.buildAndInitTypedProxy(ifName, '1', { timeoutMs: 10000 })
        .then((p) => { proxies[name] = { p, field, handler }; link[name] = 'ok'; log(`${name} connected`); })
        .catch((e) => { link[name] = `ERR ${errText(e)}`; if (name !== 'gps') log(`${name}:`, e); setTimeout(() => connect(name), RETRY_MS); });
}
function pollAll() {
    const now = Date.now();
    Object.keys(SOURCES).forEach((name) => {
        const pr = proxies[name];
        if (!pr) return;
        Promise.resolve().then(() => pr.p[pr.field].getValue()).then((v) => pr.handler(v, Date.now()), () => null);
    });
}

// ---- timer -----------------------------------------------------------------------------------------
const splitsNow = () => SPLITS[store.units].concat([DIST[store.distance]]);
let timer = null;
function newTimer() {
    timer = new RunTimer(splitsNow(), { onDone });
}
function onDone(run) {
    // save a new best per split
    Object.keys(run.result).forEach((k) => {
        const b = store.best[k];
        if (!b || run.result[k] < b.s) store.best[k] = { s: run.result[k], at: run.at, trap: run.trap[k] };
    });
    save();
    log('run done:', Object.keys(run.result).map((k) => `${k} ${run.result[k].toFixed(2)}`).join(' '), '| vmax', run.vmax.toFixed(0));
}

let dropLogged = false;
function tick() {
    const now = Date.now();
    if (raw.speed) fuse.wheel(raw.speed.v, raw.speed.t);
    if (raw.accel) fuse.accel(raw.accel.v, raw.accel.t);
    // gps only when the fix looks usable (quality field small = good; unknown scale is tolerated by the fuser)
    if (raw.gps && (raw.gps.q === undefined || raw.gps.q < 1000)) fuse.gps(raw.gps.v, true, raw.gps.t);
    const s = fuse.tick(now);
    // 1.1.7: a wheel speed the fuser ignores as a dropout (car: it read 0 mid-run) goes into draggy.log, once per dropout
    const drop = fuse.offSince !== null && !fuse.spin;
    if (drop && !dropLogged) log(`wheel speed ignored (dropout): reads ${raw.speed.v.toFixed(1)} km/h, fused ${s.vKmh.toFixed(1)} km/h`);
    dropLogged = drop;
    speedKmh = s.vKmh;
    if (timer) { timer.feed(s.t, s.vKmh); timer.idle(now); }
    feedPower(now);
}

// ---- what the screens show -------------------------------------------------------------------------
const V = (kmhVal) => (store.units === 'mph' ? kmhVal / MPH : kmhVal);
const vU = () => (store.units === 'mph' ? 'mph' : 'km/h');
const secs = (s) => (s === undefined ? '-' : `${s.toFixed(2)} s`);
const when = (ms) => { const d = new Date(ms); const p = (n) => (n < 10 ? '0' : '') + n; return `${p(d.getDate())}.${p(d.getMonth() + 1)}. ${p(d.getHours())}:${p(d.getMinutes())}`; };
const DIM = '#8b9099', OK = '#5bd68a', CRIT = '#ff3b30';    // text elements take '#rrggbb' (the tele ones token names)

// ---- Run: the page line and the chips of the frame (the timer's state, the speed's sources), the splits
function runLine() {
    if (!timer) return 'Starting...';
    if (timer.state === 'run') return `Timing: stops at the ${DIST[store.distance].label}`;
    if (Object.keys(timer.result).length) return `Last run: ${timer.elapsed(Date.now()).toFixed(2)} s to ${V(timer.vmax).toFixed(0)} ${vU()}`;
    return 'Stop, then launch: the timer arms itself';
}
function runChips() {
    const st = fuse.status(Date.now()), parts = [];
    if (st.wheel) parts.push('wheel'); if (st.accel) parts.push('accel'); if (st.gps) parts.push('GPS');
    const errs = ['speed', 'accel', 'gps'].filter((k) => /ERR/.test(link[k] || ''));
    const out = [timer && timer.state === 'run' ? ['Running', 'accent'] : timer && timer.state === 'ready' ? ['Ready', 'ok'] : ['Stop to arm', 'dim']];
    if (st.spin) out.push(['Wheelspin', 'warn']);
    // (the GPS wheel factor as 1.1.8's sensor line showed it)
    out.push([`${parts.length ? `Sensors: ${parts.join(' + ')}` : 'No sensors'}${st.gps ? ` · cal ${st.cal.toFixed(2)}` : ''}${errs.length ? ` · no ${errs.join(', ')}` : ''}`,
        parts.length ? 'dim' : 'crit']);
    return out;
}
// split | this run (+ trap speed for distances; amber while timing) | best (green when this run set it)
function splitRows(running) {
    return splitsNow().map((s) => {
        const t = timer && timer.result[s.key], trap = timer && timer.trapSpeed[s.key], best = store.best[s.key];
        const trapTxt = s.dist && trap !== undefined ? ` @ ${Math.round(V(trap))} ${vU()}` : '';
        return [s.label, t !== undefined ? [secs(t) + trapTxt, running ? 'accent' : 'text'] : '-',
            best ? [secs(best.s), !running && t !== undefined && best.s === t ? 'ok' : 'text'] : '-'];
    });
}
// split | time | trap speed | when: the splits of the units chosen on Run, then the distances
function bestRows() {
    const rows = [];
    SPLITS[store.units].concat(DIST_OPTS.map((d) => DIST[d])).forEach((s) => {
        const b = store.best[s.key];
        if (b) rows.push([s.label, secs(b.s), b.trap ? `${Math.round(V(b.trap))} ${vU()}` : '-', when(b.at)]);
    });
    return rows;
}

// ---- Power run (powerrun.js). While a pull runs main.js keeps its samples (as analyse() takes them) for the
// running view; an aborted pull stays on the page (abort) until Try again or the next pull
const PW_UNITS = ['hp', 'ps', 'kw'], TQ_UNITS = ['nm', 'lbft'], BODY_KEYS = ['coupe', 'wagon', 'suv'];
const REASON = {                                     // aborted: heading, what to do
    gear: ['Gear changed', 'A run needs one gear from 2500 rpm to the limiter: it ended with a shift.'],
    lift: ['Throttle lifted', 'A run needs full throttle from 2500 rpm to the limiter.'],
    short: ['Too short', 'It covered less than 1500 rpm: floor it in one gear from 2500 rpm.'],
    sampling: ['Data gap', 'The car\'s data stopped for a moment: try again.'],
};
const RUN_EL = ['rnRpmLabel', 'rnRpm', 'rnProg', 'rnPwLabel', 'rnPw', 'rnTqLabel', 'rnTq', 'cancelBtn'];
const ABORT_EL = ['abTitle', 'abHead', 'abLine', 'abKv', 'retryBtn'];
const DONE_EL = ['pkPwLabel', 'pkPw', 'pkPwLine', 'pkTqLabel', 'pkTq', 'pkTqLine', 'carKv', 'carBtn', 'pinBtn'];
let live = [];          // this pull's samples { rpm, p (W), v, ecu }
let abort = null;       // { reason, rpm, hp }
const isBase = (run) => !!run && !!power.baseline && run.at === power.baseline.at;
const sign = (x) => `${x < 0 ? '-' : '+'}${Math.abs(x)}`;
const axisTop = (v, min) => Math.max(min, Math.ceil(v * 1.15 / 100) * 100);    // an axis end above the curve: 5 steps

// tick(): fed only while the Power run page is open (a drag launch is no power run); a pull the page left (a tab,
// the HMI's BACK / HOME; Car can't be opened while pulling) is thrown away as by Cancel - unfed it would come back as
// a data gap or a part run
function feedPower(now) {
    const fresh = (r) => !!r && now - r.t < 500, open = !!screens && !!screens.st && screens.st.name === 'power';
    if (!open && power.state === 'running') { power.cancel(); live = []; }
    if (!open || !fresh(raw.rpm) || !fresh(raw.speed)) return;
    const was = power.state, ecu = fresh(raw.torque) ? raw.torque.v : undefined;
    power.feed({ t: now, kmh: raw.speed.v, rpm: raw.rpm.v, accel: fresh(raw.accel) ? raw.accel.v : undefined, torqueNm: ecu });
    if (power.state === 'running') {
        if (was !== 'running') { live = []; abort = null; }
        if (power.hpNow !== null) live.push({ rpm: raw.rpm.v, p: power.hpNow * POWER.hp[0], v: raw.speed.v, ecu });
    } else if (was === 'running' && power.state === 'aborted' && live.length) {
        const top = live.reduce((a, x) => (x.rpm > a.rpm ? x : a));            // the highest sample: where it got to
        abort = { reason: power.reason, rpm: Math.round(top.rpm / 10) * 10, hp: top.p / POWER.hp[0] };
        log(`power run aborted (${power.reason}) at ${abort.rpm} rpm`);
    } else if (was === 'running' && power.state === 'done') {
        const pk = power.last.peak;
        log(`power run: ${pk.hp} hp @${pk.hpRpm}, ${pk.nm} Nm @${pk.nmRpm} (${power.last.points.length} bins)`);
        save();
    }
}
function renderPower() {
    const st = power.state, running = st === 'running', now = Date.now(), set = power.settings;
    const pu = POWER[set.powerUnit] || POWER.hp, tu = (TORQUE[set.torqueUnit] || TORQUE.nm)[1];
    const run = running || abort ? (live.length ? analyse(live, now, set) : null) : power.last;
    const vw = power.view(run), base = isBase(run) ? null : power.view(power.baseline);
    const rpmOk = !!raw.rpm && now - raw.rpm.t < 2000;
    const chip = !rpmOk ? ['No engine speed', 'crit'] : running ? ['Running', 'accent'] : abort ? ['Aborted', 'warn']
        : st === 'done' ? ['Saved', 'ok'] : st === 'ready' ? ['Ready', 'ok'] : null;
    screens.set('powerMenu', { chips: chip ? [chip] : [],
        sub: running ? 'Recording · keep full throttle to the limiter' : 'Full throttle in one gear, from 2500 rpm to the limiter' });
    // the chart: power on the left axis (the main line), torque on the right; the DME's torque, the baseline, an abort
    const pts = (v, k) => (v ? v.points.filter((c) => typeof c[k] === 'number').map((c) => [c.rpm, c[k]]) : []);
    const all = (vw ? vw.points : []).concat(base ? base.points : []), most = (k) => Math.max.apply(null, [0].concat(all.map((c) => c[k] || 0)));
    const rpms = all.map((c) => c.rpm), yMax = axisTop(most('power'), 300), y2Max = axisTop(Math.max(most('torque'), most('ecuTorque')), 400);
    const series = [];
    if (base) series.push({ points: pts(base, 'power'), color: 'faint' }, { points: pts(base, 'torque'), color: 'faint', axis: 2 });
    series.push({ points: pts(vw, 'ecuTorque'), color: 'info', axis: 2 }, { points: pts(vw, 'torque'), color: 'text', axis: 2, width: 4, dot: running || !!abort });
    if (abort) series.push({ points: [[abort.rpm, 0], [abort.rpm, yMax]], color: 'warn', width: 3 });
    screens.set('powerChart', { hidden: !vw, points: pts(vw, 'power'), series, yMax, yStep: yMax / 5, y2Max, y2Step: y2Max / 5, yUnit: pu[1], y2Unit: tu,
        xMin: Math.min(2000, Math.floor(Math.min.apply(null, rpms.concat([2000])) / 1000) * 1000),
        xMax: Math.max(7000, Math.ceil(Math.max.apply(null, rpms.concat([7000])) / 1000) * 1000) })
        .set('powerEmpty', { hidden: !!vw })
        .set('lgPw', { hidden: !vw }).set('lgTq', { hidden: !vw })
        .set('lgEcu', { hidden: !pts(vw, 'ecuTorque').length }).set('lgBase', { hidden: !base });
    RUN_EL.forEach((n) => screens.set(n, { hidden: !running }));
    ABORT_EL.forEach((n) => screens.set(n, { hidden: running || !abort }));
    DONE_EL.forEach((n) => screens.set(n, { hidden: running || !!abort }));
    if (running) {               // engine speed, from the pull's start towards the last run's top, power and torque now
        const c = vw && vw.points[vw.points.length - 1], rpm = Math.round(raw.rpm.v), from = Math.round((live.length ? live[0].rpm : rpm) / 100) * 100;
        const top = power.last ? power.last.points[power.last.points.length - 1].rpm : 7000;
        screens.set('rnRpm', { value: String(rpm) })
            .set('rnProg', { label: `From ${from}`, right: power.last ? `Limiter ${top}` : `${top} rpm`, value: top > from ? (rpm - from) / (top - from) : 0 })
            .set('rnPw', { value: c ? String(Math.round(c.power)) : '--', unit: pu[1] })
            .set('rnTq', { value: c ? String(Math.round(c.torque)) : '--', unit: tu });
    } else if (abort) {
        const why = REASON[abort.reason] || REASON.short;
        screens.set('abHead', { text: why[0] }).set('abLine', { text: why[1] })
            .set('abKv', { rows: [['Reached', `${abort.rpm} rpm`], ['Power there', `${Math.round(abort.hp * POWER.hp[0] / pu[0])} ${pu[1]}`]] });
    }
    // the peaks (and the difference to the baseline), the car the run was measured with (before any run: the Car page's)
    const pk = vw && vw.peak, d = vw && vw.delta, car = run || set, body = BODIES[car.body] || BODIES.coupe;
    screens.set('pkPw', { value: pk ? String(Math.round(pk.power)) : '--', unit: pu[1] })
        .set('pkPwLine', { text: pk ? `at ${pk.powerRpm} rpm${d ? ` · ${sign(Math.round(d.power))} ${pu[1]} to baseline` : isBase(run) ? ' · the baseline' : ''}` : 'No run yet',
            color: d ? (d.power < 0 ? CRIT : OK) : DIM })
        .set('pkTq', { value: pk ? String(Math.round(pk.torque)) : '--', unit: tu })
        .set('pkTqLine', { text: pk ? `${pk.band[0]} - ${pk.band[1]} rpm${d ? ` · ${sign(Math.round(d.torque))} ${tu}` : ''}` : '',
            color: d ? (d.torque < 0 ? CRIT : OK) : DIM })
        .set('carKv', { rows: [['Weight', `${car.weight} kg`], ['Body · loss', `${body.label} · ${car.loss} %`]] })
        .set('pinBtn', { text: isBase(power.last) ? 'Unpin baseline' : 'Pin as baseline', icon: isBase(power.last) ? 'unlock' : 'lock', disabled: !power.last });
}
function renderCar() {
    const s = power.settings;
    screens.set('weightRow', { value: s.weight }).set('lossRow', { value: s.loss }).set('bodyRow', { sel: BODY_KEYS.indexOf(s.body) })
        .set('powerUnitRow', { sel: PW_UNITS.indexOf(s.powerUnit) }).set('torqueUnitRow', { sel: TQ_UNITS.indexOf(s.torqueUnit) });
}
// chart1: the run's speed (y) over seconds from the launch (x) - the timer's trace. The axes grow past the
// design's 15 s / 300 km/h (200 mph) when the run does. Rebuilt only when the trace or the units changed.
let chart = { key: null, opts: null };
function chartOpts() {
    const tr = timer ? timer.trace : [], last = tr[tr.length - 1];
    const key = `${store.units} ${tr.length} ${last ? last[0] : ''}`;
    if (key === chart.key) return chart.opts;
    const up = (v, step) => Math.ceil(v / step) * step;
    chart = { key, opts: {
        points: tr.map(([s, v]) => [Math.round(s * 100) / 100, Math.round(V(v) * 10) / 10]),
        xMax: Math.max(15, up(last ? last[0] : 0, 5)),
        yMax: Math.max(store.units === 'mph' ? 200 : 300, up(V(timer ? timer.vmax : 0), 50)),
        yUnit: vU(),
    } };
    return chart.opts;
}

// ---- screens (the renderer) ------------------------------------------------------------------------
// renderer/ is the builder's export: screens.json + its runtime. Loaded with a computed path: the linked app.js
// leaves it to the platform require (plain files in the package, Node 8).
// the linked bundle is javascript/app.js: the package root is one up
const SOURCE = typeof __dirname === 'string' ? path.join(__dirname, '..') : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
let screens = null;

// the app's values on the shown screen (ScreenApp.set: drawn only when something changed)
function render() {
    if (!screens || !screens.st) return;
    const run = !!timer && timer.state === 'run', el = timer ? timer.elapsed(Date.now()) : 0, bests = bestRows();
    // units / distance greyed while timing (a tap there would start the run over)
    screens.set('homeMenu', { sub: runLine(), chips: runChips() })
        .set('timeReadout', { value: el.toFixed(2), color: run ? 'accent' : '' })
        .set('speedReadout', { value: String(Math.max(0, Math.round(V(speedKmh)))), unit: vU() })
        .set('chart1', chartOpts())
        .set('splitTable', { rows: splitRows(run) })
        .set('unitTabs', { sel: UNIT_OPTS.indexOf(store.units), disabled: run })
        .set('distTabs', { sel: DIST_OPTS.indexOf(store.distance), disabled: run })
        .set('resetBtn', { text: run ? 'Stop run' : 'Reset run', icon: run ? 'pause' : 'refresh' })
        .set('bestTable', { rows: bests }).set('bestEmpty', { hidden: bests.length > 0 });
    renderPower();
    renderCar();
}

// touches: units / distance, the Car page's rows, a tab (o is the element's opts: read before the set)
function onChange(name, o) {
    const ps = power.settings;
    if (name === 'unitTabs' && UNIT_OPTS[o.sel] && UNIT_OPTS[o.sel] !== store.units) { store.units = UNIT_OPTS[o.sel]; newTimer(); }
    else if (name === 'distTabs' && DIST_OPTS[o.sel] && DIST_OPTS[o.sel] !== store.distance) { store.distance = DIST_OPTS[o.sel]; newTimer(); }
    else if (name === 'weightRow') ps.weight = Math.round(o.value / 5) * 5;
    else if (name === 'lossRow') ps.loss = Math.round(o.value);
    else if (name === 'bodyRow' && BODY_KEYS[o.sel]) ps.body = BODY_KEYS[o.sel];
    else if (name === 'powerUnitRow' && PW_UNITS[o.sel]) ps.powerUnit = PW_UNITS[o.sel];
    else if (name === 'torqueUnitRow' && TQ_UNITS[o.sel]) ps.torqueUnit = TQ_UNITS[o.sel];
    else {
        const page = Object.keys(MENUS).find((p) => MENUS[p] === name);
        const to = TABS[o.sel];
        if (page) { screens.set(name, { sel: TABS.indexOf(page === 'car' ? 'power' : page) }); goTo(to); }
        return;
    }
    save(); render();
}
function onEvent(name) {
    if (name === 'reset' && timer) timer.reset();                       // Reset run / Stop run: thrown away, re-armed
    else if (name === 'pin' && power.last) { power.pin(isBase(power.last) ? null : power.last); save(); }
    else if (name === 'cancel') { power.cancel(); live = []; }          // the pull thrown away
    else if (name === 'retry') { abort = null; live = []; }
    else return;
    render();
}

// ---- RHMI: the host states (the shared OnlineApp host, oap-shared/online-host.js, builds the rest) -----
let app = null;
const comp = (n) => app.getByName(n);
function showScreen(name) {
    return comp(name).updateResources().then(() => app.openState(name))
        .then(() => log(`opened ${name}`))
        .catch((e) => log(`open ${name} failed:`, e));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed:`, e));
// the tabs: Run is the entry state, the other two open over it; Car opens over Power run (its Back closes it)
const TABS = ['home', 'power', 'bests'];
const MENUS = { home: 'homeMenu', power: 'powerMenu', car: 'carMenu', bests: 'bestsMenu' };
function goTo(page) {
    const cur = screens.st && screens.st.name;
    if (!page || page === cur) return;
    const open = cur === 'car' ? ['car', 'power'] : cur && cur !== 'home' ? [cur] : [];
    open.filter((n) => n !== page).forEach(closeScreen);
    if (page !== 'home' && open.indexOf(page) < 0) showScreen(page);
}

function startScreens(rhmiApp, hosts) {
    app = rhmiApp;
    const design = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: (m) => log(m), warn: (m) => log(m), error: (m) => log(m) };
    const gpu = new RenderClient('iteriodev_draggy', rlog);
    screens = new ScreenApp(gpu, design, { view: 'id8', log: rlog });
    // a host state per screen: the HMI shows it -> the screen shows; BACK / HOME / popups through them
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('change', onChange);
    screens.on('event', onEvent);
    // the user left for the HMI (touched it, or a "close" tap): leave the host states too, or the HMI would show
    // their empty pages
    screens.on('closed', (why) => { if (why !== 'hmi') STATES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
    log('screens ready');
}

// Start, tile and shutdown: the shared host (iDrive 8 only since 1.2.0). The sensors and the timer start with the screens
// (a tile tap starts the app in the foreground); a run in progress ends with the process at shutdown.
log('start', process.getuid());
newTimer();
createHost({
    states: STATES,
    log,
    onReady: (rhmiApp, hosts) => {
        startScreens(rhmiApp, hosts);
        Object.keys(SOURCES).forEach(connect);
        setInterval(pollAll, POLL.speed);           // poll the getters (notifiers silent on this car)
        setInterval(() => { tick(); render(); }, TICK_MS);
    },
});

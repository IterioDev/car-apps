'use strict';
/*
 * iteriodev_draggy: a drag/acceleration timer (tile "Drag Timer"). Research: analysis/idrive7-apps-merge.md,
 * the repo's draggy. Improved for ID8 with sensor fusion (fuse.js): the timer is fed a FUSED speed from
 *   - Vehicle2.statusCarSpeed2  (wheel/CoG speed, laggy + tyre-biased)
 *   - CDS2 longitudinal accel   (high-rate, low-lag; de-lags and rejects wheelspin)
 *   - GPSData ground speed      (~1 Hz; auto-calibrates the wheel factor and anchors the absolute)
 * so a wheelspin launch rides the honest accel and the tyre/speedo bias is calibrated out. The run timer
 * (timer.js, ported from the repo, MIT) arms itself at a standstill and interpolates each split.
 *
 * Screens (1.1.x): drawn by the GPU renderer (mgu-renderd, scripts/renderd), designed in the HMI UI builder:
 * apps/hmi-ui-builder/projects/drag-timer.json, exported into this folder (rhmiData/ = one empty RHMI host state
 * per screen, renderer/ = screens.json + the builder's runtime: screenapp.js, kit, fonts). home: run time, speed,
 * speed-over-time chart of the run, splits table, units / distance tabs, reset + best times buttons -> bests:
 * best times table. Timed from the launch (no one-foot rollout).
 * The renderer gives the app the touches on its screens; the HMI's BACK / HOME / popups work through the host
 * states (screenapp.js bindHosts). Bootstrap and tile tap are the oap-cardash / oap-dtcscan ones.
 */
const fs = require('fs');
const path = require('path');
const util = require('util');
const RhmiManager                      = require('oap-sdk/src/rhmi/RhmiManager');
const RhmiResourcesLocator             = require('oap-sdk/src/rhmi/RhmiResourcesLocator');
const MultiLanguageStringBundleFactory = require('oap-sdk/src/rhmi/MultiLanguageStringBundleFactory');
const RhmiApplicationFactory           = require('oap-sdk/src/rhmi/RhmiApplicationFactory');
const ResourceManager                  = require('oap-sdk/src/rhmi/ResourceManager');
const CurrentVehicleUnits              = require('oap-sdk/src/core/CurrentVehicleUnits');
const someipBuilders                   = require('oap-sdk/src/someip/someipBuilders');
const OnlineAppBackground              = require('oap-sdk/src/core/OnlineAppBackground');
const { RunTimer } = require('./timer');
const { Fuser }    = require('./fuse');

const APPLET_ID       = 20109;  // = rhmiData/application.json "appletId"
const ENTRY_UUID      = 'b9c2f6a1-3e74-4d85-a0c6-1f7b9d3e5c82';
const APPLETID_OFFSET = 3000;
const LOG = '[iteriodev_draggy]';
const STATES = ['home', 'bests'];         // screens = their RHMI host states (same names)

const DATA = `/var/opt/public/oap/oap_${process.getuid()}/data`;
const LOG_FILE = `${DATA}/draggy.log`;
const STORE_FILE = `${DATA}/draggy.json`;
const TICK_MS = 50;             // fuse tick + timer feed rate (poll handlers update the raw values between)
const POLL = { speed: 50, accel: 50, gps: 1000 };
const RETRY_MS = 30e3;

// ---- calibration (raw bus -> unit), car-confirmed in oap-cardash ---------------------------------
const kmh = (raw) => raw / 64;                       // Vehicle2.speedVehicleCentreOfGravity
const accelMs2 = (raw) => raw * 0.002 - 65;          // CDS2 longitudinal, m/s^2
// GPSData speedGPSCAN scale is unknown -> a knob; the source row shows the raw value to calibrate, and a
// wrong scale only disables gps calibration (the fuser rejects an out-of-band ratio), it never harms.
let gpsScale = 1;                                    // speedGPSCAN * gpsScale = km/h (default: assume km/h)

const MPH = 1.609344;
const SPLITS = {
    kmh: [{ key: '0-50', label: '0-50 km/h', from: 0, to: 50 }, { key: '0-100', label: '0-100 km/h', from: 0, to: 100 },
        { key: '100-200', label: '100-200 km/h', from: 100, to: 200 }, { key: '0-200', label: '0-200 km/h', from: 0, to: 200 }],
    mph: [{ key: '0-30mph', label: '0-30 mph', from: 0, to: 30 * MPH }, { key: '0-60mph', label: '0-60 mph', from: 0, to: 60 * MPH },
        { key: '60-130mph', label: '60-130 mph', from: 60 * MPH, to: 130 * MPH }, { key: '0-100mph', label: '0-100 mph', from: 0, to: 100 * MPH }],
};
const DIST = {
    qm: { key: 'qm', label: '1/4 mile', dist: 402.336 }, em: { key: 'em', label: '1/8 mile', dist: 201.168 }, m1000: { key: 'm1000', label: '1000 m', dist: 1000 },
};
const UNIT_OPTS = ['kmh', 'mph'], DIST_OPTS = ['em', 'qm', 'm1000'];   // the order of the screens' tabs

// ---- log + store -----------------------------------------------------------------------------------
const errText = (e) => String(e && e.message || e).slice(0, 120);
function log() {
    const line = [new Date().toISOString()].concat([].slice.call(arguments)
        .map((x) => (typeof x === 'string' ? x : util.inspect(x, { depth: 4 }).slice(0, 2000)))).join(' ');
    console.error(LOG, line);
    try { if (fs.statSync(LOG_FILE).size > 256 * 1024) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* no file yet */ }
    try { fs.appendFileSync(LOG_FILE, `${line}\n`); } catch (e) { /* no data folder */ }
}
let store = { units: 'kmh', distance: 'qm', best: {} };
try { store = Object.assign(store, JSON.parse(fs.readFileSync(STORE_FILE, 'utf8'))); } catch (e) { /* defaults */ }
const save = () => { try { fs.writeFileSync(STORE_FILE, JSON.stringify(store)); } catch (e) { log('store not saved:', e); } };

// ---- sources + fusion ------------------------------------------------------------------------------
const raw = {};                 // name -> { v, t }
const link = {};                // source -> 'connecting' | 'ok' | 'ERR ...'
const fuse = new Fuser();
let speedKmh = 0;               // the fused speed, last tick

const SOURCES = {
    speed: ['de.bmw.infotainment.vehicle.Vehicle2', 'statusCarSpeed2', (x, t) => { if (x && typeof x.speedVehicleCentreOfGravity === 'number' && x.speedVehicleCentreOfGravity !== 65535) raw.speed = { v: kmh(x.speedVehicleCentreOfGravity), t }; }],
    accel: ['de.bmw.infotainment.vehicle.CDS2', 'statusLongitudinalAccelerationMassCenter', (x, t) => { if (x && typeof x.longitudinalAccelerationCentreOfGravity === 'number' && x.longitudinalAccelerationCentreOfGravity !== 65535) raw.accel = { v: accelMs2(x.longitudinalAccelerationCentreOfGravity), t }; }],
    gps: ['de.bmw.infotainment.GPSData', 'GPSPositionExtendedCAN', (x, t) => { if (x && typeof x.speedGPSCAN === 'number') { raw.gps = { v: x.speedGPSCAN * gpsScale, q: x.statusQualityPositionGPSCAN, t }; logGps(x, t); } }],
};
// speedGPSCAN's scale is still unknown (car: ~17000-19000 at 1-60 km/h): the whole record once, then raw vs wheel
// speed every 2 s while moving, into draggy.log - enough points to fit the scale
let gpsLogged = 0;
function logGps(x, t) {
    if (!gpsLogged) log('gps record:', x);
    if (gpsLogged && (!raw.speed || raw.speed.v < 2 || t - gpsLogged < 2000)) return;
    gpsLogged = t;
    if (raw.speed) log('gps raw', x.speedGPSCAN, 'quality', x.statusQualityPositionGPSCAN, 'wheel kmh', raw.speed.v.toFixed(1));
}
const proxies = {};
function connect(name) {
    const [ifName, field, handler] = SOURCES[name];
    link[name] = link[name] || 'connecting';
    return someipBuilders.buildAndInitTypedProxy(ifName, '1', { timeoutMs: 10000 })
        .then((p) => { proxies[name] = { p, field, handler }; link[name] = 'ok'; log(`${name} connected`); })
        .catch((e) => { link[name] = `ERR ${errText(e)}`; if (name !== 'gps') log(`${name}:`, e); setTimeout(() => connect(name), RETRY_MS); });
}
function pollAll() {
    const now = Date.now();
    Object.keys(SOURCES).forEach((name) => {
        const pr = proxies[name];
        if (!pr) return;
        Promise.resolve().then(() => pr.p[pr.field].getValue()).then((v) => pr.handler(v, Date.now()), () => null);
    });
}

// ---- timer -----------------------------------------------------------------------------------------
const splitsNow = () => SPLITS[store.units].concat([DIST[store.distance]]);
let timer = null;
function newTimer() {
    timer = new RunTimer(splitsNow(), { onDone });
}
function onDone(run) {
    // save a new best per split
    Object.keys(run.result).forEach((k) => {
        const b = store.best[k];
        if (!b || run.result[k] < b.s) store.best[k] = { s: run.result[k], at: run.at, trap: run.trap[k] };
    });
    save();
    log('run done:', Object.keys(run.result).map((k) => `${k} ${run.result[k].toFixed(2)}`).join(' '), '| vmax', run.vmax.toFixed(0));
}

function tick() {
    const now = Date.now();
    if (raw.speed) fuse.wheel(raw.speed.v, raw.speed.t);
    if (raw.accel) fuse.accel(raw.accel.v, raw.accel.t);
    // gps only when the fix looks usable (quality field small = good; unknown scale is tolerated by the fuser)
    if (raw.gps && (raw.gps.q === undefined || raw.gps.q < 1000)) fuse.gps(raw.gps.v, true, raw.gps.t);
    const s = fuse.tick(now);
    speedKmh = s.vKmh;
    if (timer) { timer.feed(s.t, s.vKmh); timer.idle(now); }
}

// ---- what the screens show -------------------------------------------------------------------------
const V = (kmhVal) => (store.units === 'mph' ? kmhVal / MPH : kmhVal);
const vU = () => (store.units === 'mph' ? 'mph' : 'km/h');
const secs = (s) => (s === undefined ? '-' : `${s.toFixed(2)} s`);
const when = (ms) => { const d = new Date(ms); const p = (n) => (n < 10 ? '0' : '') + n; return `${p(d.getDate())}.${p(d.getMonth() + 1)}. ${p(d.getHours())}:${p(d.getMinutes())}`; };
const cells = (r) => r.map((c) => String(c).replace(/,/g, ' ')).join(',');    // a table row: cells comma separated

function statusText() {
    if (!timer) return 'Starting...';
    const st = timer.state, el = timer.elapsed(Date.now());
    if (st === 'run') return 'Launched - timing';
    if (st === 'ready') return 'Ready - go!';
    if (Object.keys(timer.result).length) return `Run: ${el.toFixed(2)} s to ${V(timer.vmax).toFixed(0)} ${vU()}`;
    return 'Stop, then launch - arms itself';
}
// split | this run (+ trap speed for distances) | best
function splitRows() {
    return splitsNow().map((s) => {
        const t = timer && timer.result[s.key], trap = timer && timer.trapSpeed[s.key];
        const best = store.best[s.key];
        const trapTxt = s.dist && trap !== undefined ? ` @ ${Math.round(V(trap))} ${vU()}` : '';
        return cells([s.label, t !== undefined ? secs(t) + trapTxt : '-', best ? secs(best.s) : '-']);
    }).join('\n');
}
function sourceText() {
    const st = fuse.status(Date.now());
    const parts = [];
    if (st.wheel) parts.push('wheel'); if (st.accel) parts.push('accel'); if (st.gps) parts.push('GPS');
    let s = parts.length ? parts.join('+') : 'no sensors';
    if (st.gps) s += ` · cal ${st.cal.toFixed(2)}`;
    if (st.spin) s += ' · WHEELSPIN';
    const errs = Object.keys(link).filter((k) => /ERR/.test(link[k]));
    return `Sensors: ${s}${errs.length ? ` · no ${errs.join(', ')}` : ''}`;
}
// split | time | trap speed | when
function bestRows() {
    const rows = [];
    for (const u of UNIT_OPTS) for (const s of SPLITS[u].concat(UNIT_OPTS.indexOf(u) === 0 ? DIST_OPTS.map((d) => DIST[d]) : [])) {
        const b = store.best[s.key];
        if (!b) continue;
        rows.push(cells([s.label, secs(b.s), b.trap ? `${Math.round(V(b.trap))} ${vU()}` : '-', when(b.at)]));
    }
    return rows.length ? rows.join('\n') : 'No runs yet,-,-,-';
}
// chart1: the run's speed (y) over seconds from the launch (x) - the timer's trace. The axes grow past the
// design's 15 s / 300 km/h (200 mph) when the run does. Rebuilt only when the trace or the units changed.
let chart = { key: null, opts: null };
function chartOpts() {
    const tr = timer ? timer.trace : [], last = tr[tr.length - 1];
    const key = `${store.units} ${tr.length} ${last ? last[0] : ''}`;
    if (key === chart.key) return chart.opts;
    const up = (v, step) => Math.ceil(v / step) * step;
    chart = { key, opts: {
        points: tr.map(([s, v]) => [Math.round(s * 100) / 100, Math.round(V(v) * 10) / 10]),
        xMax: Math.max(15, up(last ? last[0] : 0, 5)),
        yMax: Math.max(store.units === 'mph' ? 200 : 300, up(V(timer ? timer.vmax : 0), 50)),
        yUnit: vU(), empty: 'Launch to draw speed over time',
    } };
    return chart.opts;
}

// ---- screens (the renderer) ------------------------------------------------------------------------
// renderer/ is the builder's export: screens.json + its runtime. Loaded with a computed path: build_bundle.py
// leaves it to the platform require (plain files beside bundle.js, Node 8).
const SOURCE = typeof __dirname === 'string' ? __dirname : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
let screens = null;

// the app's values on the shown screen (ScreenApp.set: drawn only when something changed)
function render() {
    if (!screens || !screens.st) return;
    const el = timer ? timer.elapsed(Date.now()) : 0;
    screens.set('timeReadout', { value: el })
        .set('speedReadout', { value: Math.max(0, Math.round(V(speedKmh))), unit: vU() })
        .set('statusText', { text: statusText() })
        .set('sourceText', { text: sourceText() })
        .set('chart1', chartOpts())
        .set('splitTable', { rows: splitRows() })
        .set('unitTabs', { sel: UNIT_OPTS.indexOf(store.units) })
        .set('distTabs', { sel: DIST_OPTS.indexOf(store.distance) })
        .set('bestTable', { rows: bestRows() });
}

// touches on the screens: settings (tabs) and the "reset" tap; the rest (best times / back) is screen navigation
function onChange(name, o) {
    if (name === 'unitTabs' && UNIT_OPTS[o.sel] && UNIT_OPTS[o.sel] !== store.units) store.units = UNIT_OPTS[o.sel];
    else if (name === 'distTabs' && DIST_OPTS[o.sel] && DIST_OPTS[o.sel] !== store.distance) store.distance = DIST_OPTS[o.sel];
    else return;
    save(); newTimer(); render();
}
function onEvent(name) {
    if (name === 'reset' && timer) { timer.reset(); render(); }     // throw the current run away / re-arm
}

// ---- RHMI: the host states ---------------------------------------------------------------------------
const rhmiManager          = new RhmiManager();
const resourceManager      = new ResourceManager(APPLET_ID);
const rhmiResourcesLocator = new RhmiResourcesLocator({ rhmiConfigKey: 'rhmiData' });
const multiLanguageStringBundleFactory = new MultiLanguageStringBundleFactory({ currentVehicleUnits: new CurrentVehicleUnits(), resourceManager, rhmiResourcesLocator });
const rhmiApplicationFactory = new RhmiApplicationFactory({ multiLanguageStringBundleFactory, resourceManager, rhmiManager, rhmiResourcesLocator });

let app = null;
const comp = (n) => app.getByName(n);
function showScreen(name, open) {
    return comp(name).updateResources().then(open || (() => app.openState(name)))
        .then(() => log(`opened ${name}`))
        .catch((e) => log(`open ${name} failed:`, e));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed:`, e));

function startScreens(rhmiApp) {
    app = rhmiApp;
    const design = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: (m) => log(m), warn: (m) => log(m), error: (m) => log(m) };
    const gpu = new RenderClient('iteriodev_draggy', rlog);
    screens = new ScreenApp(gpu, design, { view: 'id8', log: rlog });
    // a host state per screen: the HMI shows it -> the screen shows; BACK / HOME / popups through them
    const hosts = {};
    STATES.forEach((s) => { hosts[s] = comp(s); });
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('change', onChange);
    screens.on('event', onEvent);
    // the user left for the HMI (touched it, or a "close" tap): leave the host states too, or the HMI would show
    // their empty pages
    screens.on('closed', (why) => { if (why !== 'hmi') STATES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
    log('screens ready');
}

function onChangeVisibility(args) {
    const a = args || {};
    if (a.visible && app) showScreen('home', () => app.openEntryState(a.entryPointUuid || ENTRY_UUID));
    return Promise.resolve({});
}

const onlineApp = OnlineAppBackground.create();
onlineApp.createAppStatusService = function () {
    const instanceName = `${process.getuid() - this.extendedConfig.get('someip', 'instanceIdOffset')}`;
    return someipBuilders.buildTypedService('de.bmw.infotainment.telematic.oap.AppStatus', instanceName, {
        changeVisibility: onChangeVisibility, configureStartWidgetApp: () => Promise.resolve({}),
        appStatus: { getValue: () => Promise.resolve(this.appStatus) }, hmiStatus: { getValue: () => Promise.resolve(this.hmiStatus) }, audioStatus: { getValue: () => Promise.resolve(this.audioStatus) },
    }).then((service) => service.init()).then((service) => { this.emit('appStatusProxyReady'); return service; });
};
onlineApp.on('terminated', () => onlineApp.shutdown().catch(() => {}).then(() => process.exit(0)));
onlineApp.on('appStatusProxyReady', () => onlineApp.registerActive());

const startRhmi = () => rhmiResourcesLocator.init()
    .then(() => Promise.all([rhmiManager.init(), resourceManager.init(), rhmiApplicationFactory.init()]))
    .then(() => rhmiApplicationFactory.create(process.getuid(), { appletIdOffset: APPLETID_OFFSET }))
    .then((rhmiApp) => rhmiApp.init().then(() => rhmiApp.setActive(true))
        .then(() => rhmiApp.mapEntryState(ENTRY_UUID, rhmiApp.getByName('home')))
        .then(() => startScreens(rhmiApp)));

log('start', process.getuid());
newTimer();
onlineApp.start()
    .then(() => Promise.all([onlineApp.initialized(), startRhmi()]))
    .then(() => {
        Object.keys(SOURCES).forEach(connect);
        setInterval(pollAll, POLL.speed);           // poll the getters (notifiers silent on this car)
        setInterval(() => { tick(); render(); }, TICK_MS);
    })
    .catch((e) => log('init failed:', e));

'use strict';
/*
 * oap-liveadjust ("Live Adjustments"): MHD live adjustments and the exhaust flap over the head unit's own
 * diagnostic link (TASU) to the DME 0x12. Port of cauliflowermossgrape/idrive7-apps apps/live_adjustments
 * (MIT) @421c113 - MHD only (BM3 left out, user 2026-10-30), no simulator: a press goes to the car.
 *
 *   Engine map 1..4 : 2F 01 <map-1>  -> 6F 01 <map-1>    MHD, car standing still only (user decision)
 *   Max Cooling     : 2F 03 01 | 00  -> 6F 03 01 | 00    MHD, any speed; On only with the engine running
 *                     (OBD rpm over 500, as upstream 1a81d0a), Off any time and shown until a press
 *   MHD presses count only when the DME echoes the request (an untuned DME refuses them). MHD has no
 *   read-back of the map or cooling, so the screen says "accepted", never "confirmed".
 *   Exhaust flap    : 2F 60FD 03 03E8 open (10 %), 03 2328 close (90 %), 00 back to the DME, any speed.
 *   BMW's own job (SGBD dme8ff_r / dme_bx8 EL_AGK, only the 8-12 % / 88-92 % bands). The DME ends an override
 *   by itself after ~20 s. 22 64FD (ASG_EL_AGK, duty cycle % x 100) = where the DME drives the flap now:
 *   <= 20 % open, >= 80 % closed. A DME that refuses 22 64FD has no electric flap.
 *
 * Opening the app only reads: OBD speed + rpm (the gates) + 22 64FD every 2 s while the screen shows. Nothing is
 * undone when the app closes (the DME ends a flap override itself).
 *
 * Screen: drawn by the GPU renderer, designed in the HMI UI builder: apps/hmi-ui-builder/projects/live-adjustments.json,
 * exported into this folder (rhmiData/ = one empty RHMI host state, renderer/ = screens.json + the builder's runtime).
 * Bootstrap and tile tap are the oap-dynomode ones.
 */
const fs = require('fs');
const path = require('path');
const util = require('util');
const RhmiManager                      = require('oap-sdk/src/rhmi/RhmiManager');
const RhmiResourcesLocator             = require('oap-sdk/src/rhmi/RhmiResourcesLocator');
const MultiLanguageStringBundleFactory = require('oap-sdk/src/rhmi/MultiLanguageStringBundleFactory');
const RhmiApplicationFactory           = require('oap-sdk/src/rhmi/RhmiApplicationFactory');
const ResourceManager                  = require('oap-sdk/src/rhmi/ResourceManager');
const CurrentVehicleUnits              = require('oap-sdk/src/core/CurrentVehicleUnits');
const someipBuilders                   = require('oap-sdk/src/someip/someipBuilders');
const OnlineAppBackground              = require('oap-sdk/src/core/OnlineAppBackground');
const { Diag, hex, NRC }               = require('./diag');
const { createGuard }                  = require('../../oap-shared/tasu-guard');

const APPLET_ID       = 20117;  // = rhmiData/application.json "appletId"
const ENTRY_UUID      = 'de2e6cd0-6590-4688-adac-f9eb27646afd';   // = entryPoints[0].uuid (project entryUuid)
const APPLETID_OFFSET = 3000;
const LOG = '[iteriodev_liveadjust]';
const STATES = ['home'];          // screens = their RHMI host states

const SOURCE = typeof __dirname === 'string' ? __dirname : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const DATA = `/var/opt/public/oap/oap_${process.getuid()}/data`;
const LOG_FILE = `${DATA}/liveadjust.log`;

const TASU_IF = 'com.harman.infotainment.systemfunctions.tasu.tasu.InternalTasu';
const TASU_INST = 'SystemFunctionsInternalTasuInst1';
const DME = 0x12;
const FLAP_DID = [0x60, 0xFD];    // 2F: EL_AGK
const FLAP_READ = [0x64, 0xFD];   // 22: ASG_EL_AGK
const FLAP = { open: [0x03, 0x03, 0xE8], close: [0x03, 0x23, 0x28], oem: [0x00] };
const OVERRIDE_MS = 20000;        // the DME's own override timer (SGBD default)
const POLL_MS = 2000;
const FRESH_MS = 2 * POLL_MS + 1000;
const MIN_COOLING_RPM = 500;      // Max Cooling On: the engine must be running
const MSG_MS = 8000;              // an action's message replaces the card's state line this long
const RED = '#e22718', ICE = '#81c4ff', GREEN = '#3ecf6e', AMBER = '#ffb020', DIM = '#5a6170';

// ---- state + log ------------------------------------------------------------------------------------
const errText = (e) => String(e && e.message || e).slice(0, 120);
function log() {
    const line = [new Date().toISOString()].concat([].slice.call(arguments)
        .map((x) => (typeof x === 'string' ? x : util.inspect(x, { depth: 4 }).slice(0, 2000)))).join(' ');
    console.error(LOG, line);
    try { if (fs.statSync(LOG_FILE).size > 256 * 1024) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* no file yet */ }
    try { fs.appendFileSync(LOG_FILE, `${line}\n`); } catch (e) { /* no data folder */ }
}

// standing still is the map switch's gate (the engine may run); cooling and the flap go at any speed (user)
const still = createGuard({ engineRunning: true, freshMs: FRESH_MS });
const anySpeed = (sid, d) => sid === 0x2F && ((d[0] === 0x03 && d.length === 2) || (d[0] === FLAP_DID[0] && d[1] === FLAP_DID[1]));
const guard = Object.assign({}, still, { check: (sid, d) => (anySpeed(sid, d) ? { ok: true, why: '' } : still.check(sid, d)) });

let diag = null;                  // Diag over TASU
let dmeOk = null;                 // the DME answered the last poll (null = not asked yet)
let map = null;                   // 1..4, the map the DME last accepted (this app's press)
let cooling = 'OFF';              // 'ON' | 'OFF': Off until a press (user: Off is the default)
let rpm = null, rpmAt = 0;        // OBD engine speed and when it was read
let flapPct = null;               // duty cycle the DME drives the flap with (22 64FD)
let flapFound = null;             // false: the DME has no electric flap
let override = null;              // 'open' | 'close' while our override runs
let overrideUntil = 0;
let busy = null;                  // the card whose command is running
let polling = false;
const msgs = {};                  // card -> { text, color, at }

// ---- UDS --------------------------------------------------------------------------------------------
const nrcText = (u) => (u && u[0] === 0x7F ? (NRC[u[2]] || `NRC ${hex(u[2])}`) : 'no reply');

function readSpeed() {
    return diag.physical(DME, 0x01, [0x0D], 1200, (u) => (u[0] === 0x41 && u[1] === 0x0D) || (u[0] === 0x7F && u[1] === 0x01))
        .then((u) => { if (u && u[0] === 0x41) guard.speed(u[2]); return !!u; }, () => false);
}

function readRpm() {
    return diag.physical(DME, 0x01, [0x0C], 1200, (u) => (u[0] === 0x41 && u[1] === 0x0C) || (u[0] === 0x7F && u[1] === 0x01))
        .then((u) => { if (u && u[0] === 0x41 && u.length >= 4) { rpm = ((u[2] << 8) | u[3]) / 4; rpmAt = Date.now(); } return !!u; }, () => false);
}
const rpmKnown = () => rpm !== null && Date.now() - rpmAt <= FRESH_MS;
const engineStopped = () => rpmKnown() && rpm <= MIN_COOLING_RPM;

function readFlap() {
    const ours = (u) => (u[0] === 0x62 && u[1] === FLAP_READ[0] && u[2] === FLAP_READ[1]) || (u[0] === 0x7F && u[1] === 0x22);
    return diag.physical(DME, 0x22, FLAP_READ, 2000, ours).then((u) => {
        if (u && u[0] === 0x62 && u.length >= 5) {
            const raw = (u[3] << 8) | u[4];
            flapPct = (raw > 0x7FFF ? raw - 0x10000 : raw) / 100;
            flapFound = true;
        } else if (u && u[0] === 0x7F && u[2] !== 0x21 && u[2] !== 0x22) { flapFound = false; flapPct = null; }
        return !!u;
    }, () => false);
}

function poll() {
    if (!diag || polling || busy) return Promise.resolve();
    polling = true;
    return Promise.all([readSpeed(), readRpm(), readFlap()])
        .then((r) => { dmeOk = r[0] || r[1] || r[2]; }, (e) => log('poll failed:', e))
        .then(() => { polling = false; if (override && Date.now() > overrideUntil) override = null; render(); });
}

/** MHD: the press counts only when the DME echoes it back */
function sendMhd(data) {
    return diag.physical(DME, 0x2F, data, 3000).then((u) => {
        log('MHD 2F', data.map((b) => hex(b)).join(' '), '->', u ? u.map((b) => hex(b)).join(' ') : 'no reply');
        if (u && u[0] === 0x6F && data.every((b, i) => u[i + 1] === b)) return;
        throw new Error(u && u[0] === 0x7F ? 'Not available on this car (no MHD answer)' : 'No answer from the DME');
    });
}

function say(card, text, color) { msgs[card] = { text, color, at: Date.now() }; render(); }

/** One command per card at a time; the card's line shows what the DME said, or why nothing was sent */
function run(card, label, fn) {
    if (busy || !diag) { if (!diag) say(card, 'No diagnostic link yet', AMBER); return Promise.resolve(); }
    busy = card;
    say(card, `Sending ${label}...`, DIM);
    return Promise.resolve().then(fn)
        .then((t) => say(card, t, GREEN), (e) => { log(label, 'failed:', errText(e)); say(card, errText(e), AMBER); })
        .then(() => { busy = null; render(); });
}

function setMap(n) {
    return run('map', `map ${n}`, () => readSpeed().then(() => {   // fresh speed right before the switch
        const p = guard.parked();
        if (!p.ok) throw new Error(`Map change needs the car standing still (${p.why})`);
        return sendMhd([0x01, n - 1]);
    }).then(() => { map = n; return `Map ${n} · accepted by the DME`; }));
}

function setCooling(on) {
    return run('cool', `Max Cooling ${on ? 'on' : 'off'}`, () => (on ? readRpm() : Promise.resolve()).then(() => {   // fresh rpm for On
        if (on && !rpmKnown()) throw new Error('Engine speed unknown · nothing sent');
        if (on && engineStopped()) throw new Error('Start the engine first');
        return sendMhd([0x03, on ? 0x01 : 0x00]);
    }).then(() => { cooling = on ? 'ON' : 'OFF'; return `Max Cooling ${on ? 'on' : 'off'} · accepted by the DME`; }));
}

function setFlap(k) {
    return run('flap', `flap ${k}`, () => diag.physical(DME, 0x2F, FLAP_DID.concat(FLAP[k]), 3000).then((u) => {
        log('flap', k, '->', u ? u.map((b) => hex(b)).join(' ') : 'no reply');
        if (!u) throw new Error('No answer from the DME');
        if (u[0] === 0x7F) throw new Error(`The DME refused: ${nrcText(u)}`);
        override = k === 'oem' ? null : k;
        overrideUntil = Date.now() + OVERRIDE_MS;
        return readFlap().then(() => (k === 'oem' ? 'Handed back to the DME' : `${k === 'open' ? 'Open' : 'Closed'} · accepted by the DME`));
    }));
}

// ---- screens (the renderer) ----------------------------------------------------------------------------
// renderer/ is the builder's export: screens.json + its runtime. Loaded with a computed path: build_bundle.py
// leaves it to the platform require (plain files beside bundle.js, Node 8).
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
let screens = null;

const fresh = (card) => msgs[card] && Date.now() - msgs[card].at <= MSG_MS && msgs[card];
const line = (card, text, color) => { const m = fresh(card); return m ? { text: m.text, color: m.color } : { text, color }; };
const btn = (on, color, off) => ({ style: on ? 'primary' : 'outline', color: on ? color : '', disabled: !!(busy || off) });

function render() {
    if (!screens) return;
    const p = guard.parked();
    screens.set('checkChips', { items: [
        { text: dmeOk === null ? 'DME not asked yet' : dmeOk ? 'DME answers' : 'DME not answering', color: dmeOk ? GREEN : AMBER, dot: true },
        { text: p.ok ? 'Standing still' : `Map locked · ${p.why}`, color: p.ok ? GREEN : AMBER, dot: true },
    ] });

    screens.set('mapValue', { text: map ? `MAP ${map}` : 'MAP --', color: map ? 'text' : DIM })
        .set('mapSub', line('map', map ? 'Accepted by the DME' : 'Tap a map: it switches at once', map ? GREEN : DIM));
    [1, 2, 3, 4].forEach((n) => screens.set(`map${n}`, btn(map === n, RED, !p.ok)));

    // the flap: where the DME drives it (22 64FD); our override's countdown while it runs
    const left = override ? Math.max(0, Math.ceil((overrideUntil - Date.now()) / 1000)) : 0;
    const pos = flapPct === null ? null : flapPct <= 20 ? 'OPEN' : flapPct >= 80 ? 'CLOSED' : `${flapPct} %`;
    const open = pos === 'OPEN', none = flapFound === false;
    screens.set('flapValue', { text: none ? 'NONE' : pos || '--', color: open ? ICE : pos === 'CLOSED' ? RED : DIM });
    ['pipeL', 'pipeR'].forEach((t) => screens.set(`${t}Open`, { hidden: !open }).set(`${t}Shut`, { hidden: open })
        .set(`${t}Glow`, { hidden: !open }));
    screens.set('flapSub', line('flap', none ? 'This DME has no electric exhaust flap'
        : left ? `${override === 'open' ? 'Open' : 'Closed'} for ${left} s more, then the DME decides`
            : flapPct === null ? 'Flap position not read yet' : `The DME drives the flap: ${flapPct} %`, DIM))
        .set('flapOpen', btn(override === 'open', ICE, none))
        .set('flapClose', btn(override === 'close', RED, none))
        .set('flapOem', btn(!override && flapFound === true, ICE, none));

    // On needs the engine running; the line speaks only when it is stopped (no rpm on screen: user)
    const stopped = engineStopped();
    screens.set('coolValue', { text: cooling, color: cooling === 'ON' ? ICE : 'text' })
        .set('coolIcon', { color: cooling === 'ON' ? ICE : DIM })
        .set('coolSub', line('cool', stopped ? 'Engine stopped · On needs it running' : '', AMBER))
        .set('coolOn', btn(cooling === 'ON', ICE, stopped))
        .set('coolOff', btn(cooling === 'OFF', ICE));
}

const EVENTS = {
    map1: () => setMap(1), map2: () => setMap(2), map3: () => setMap(3), map4: () => setMap(4),
    open: () => setFlap('open'), close: () => setFlap('close'), oem: () => setFlap('oem'),
    coolOn: () => setCooling(true), coolOff: () => setCooling(false),
};
const onEvent = (name) => { if (EVENTS[name]) Promise.resolve().then(EVENTS[name]).catch((e) => log(`${name} failed:`, e)); };

// ---- RHMI: the host state -----------------------------------------------------------------------------
const rhmiManager          = new RhmiManager();
const resourceManager      = new ResourceManager(APPLET_ID);
const rhmiResourcesLocator = new RhmiResourcesLocator({ rhmiConfigKey: 'rhmiData' });
const multiLanguageStringBundleFactory = new MultiLanguageStringBundleFactory({ currentVehicleUnits: new CurrentVehicleUnits(), resourceManager, rhmiResourcesLocator });
const rhmiApplicationFactory = new RhmiApplicationFactory({ multiLanguageStringBundleFactory, resourceManager, rhmiManager, rhmiResourcesLocator });

let app = null;
const comp = (n) => app.getByName(n);
function showScreen(name, open) {
    return comp(name).updateResources().then(open || (() => app.openState(name)))
        .then(() => log(`opened ${name}`))
        .catch((e) => log(`open ${name} failed:`, e));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed:`, e));

function startScreens(rhmiApp) {
    app = rhmiApp;
    const design = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: (m) => log(m), warn: (m) => log(m), error: (m) => log(m) };
    const gpu = new RenderClient('iteriodev_liveadjust', rlog);
    screens = new ScreenApp(gpu, design, { view: 'id8', log: rlog });
    const hosts = {};
    STATES.forEach((s) => { hosts[s] = comp(s); });
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('event', onEvent);
    screens.on('show', () => { poll(); render(); });
    // the user left for the HMI (touched it): leave the host state too, or the HMI would show its empty page
    screens.on('closed', (why) => { if (why !== 'hmi') STATES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
    render();
    // reads only while the screen shows
    setInterval(() => { if (screens.st && !screens.paused) poll(); }, POLL_MS);
}

// Tile tap: MainApp calls AppStatus.changeVisibility(visible, reason, entryPointUuid, ...).
// The SDK's background class ignores it, so open the entry screen ourselves.
function onChangeVisibility(args) {
    const a = args || {};
    log('tile:', a, app ? '' : '(screens not ready)');
    if (a.visible && app) showScreen('home', () => app.openEntryState(a.entryPointUuid || ENTRY_UUID));
    return Promise.resolve({});
}

// ---- TASU link --------------------------------------------------------------------------------------
function connectTasu() {
    return someipBuilders.buildAndInitTypedProxy(TASU_IF, TASU_INST, { timeoutMs: 10000 })
        .then((proxy) => { diag = new Diag(log, guard); return diag.attach(proxy); })
        .then(() => { log('TASU connected'); return poll(); })
        .catch((e) => { dmeOk = false; log('TASU failed:', e); setTimeout(connectTasu, 30000); render(); });
}

// ---- lifecycle --------------------------------------------------------------------------------------
const onlineApp = OnlineAppBackground.create();
onlineApp.createAppStatusService = function () {
    const instanceName = `${process.getuid() - this.extendedConfig.get('someip', 'instanceIdOffset')}`;
    return someipBuilders.buildTypedService('de.bmw.infotainment.telematic.oap.AppStatus', instanceName, {
        changeVisibility: onChangeVisibility,
        configureStartWidgetApp: () => Promise.resolve({}),
        appStatus: { getValue: () => Promise.resolve(this.appStatus) },
        hmiStatus: { getValue: () => Promise.resolve(this.hmiStatus) },
        audioStatus: { getValue: () => Promise.resolve(this.audioStatus) },
    }).then((service) => service.init())
        .then((service) => { this.emit('appStatusProxyReady'); return service; });
};
// nothing to hand back: the DME ends a flap override itself
onlineApp.on('terminated', () => onlineApp.shutdown().catch(() => {}).then(() => process.exit(0)));
onlineApp.on('appStatusProxyReady', () => onlineApp.registerActive());

const startRhmi = () => rhmiResourcesLocator.init()
    .then(() => Promise.all([rhmiManager.init(), resourceManager.init(), rhmiApplicationFactory.init()]))
    .then(() => rhmiApplicationFactory.create(process.getuid(), { appletIdOffset: APPLETID_OFFSET }))
    .then((rhmiApp) => rhmiApp.init().then(() => rhmiApp.setActive(true))
        .then(() => rhmiApp.mapEntryState(ENTRY_UUID, rhmiApp.getByName('home')))
        .then(() => startScreens(rhmiApp))
        .then(() => log('screens ready')));

log('start', process.getuid());
onlineApp.start()
    .then(() => Promise.all([onlineApp.initialized(), startRhmi()]))
    .then(() => connectTasu())
    .catch((e) => log('startup failed:', e));

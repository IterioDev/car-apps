'use strict';
/*
 * oap-liveadjust ("Live Adjustments"): MHD live adjustments and the exhaust flap over the head unit's own
 * diagnostic link (TASU) to the DME 0x12. Port of cauliflowermossgrape/idrive7-apps apps/live_adjustments
 * (MIT) @421c113 - MHD only (BM3 left out, user 2026-10-30), no simulator: a press goes to the car.
 *
 *   Engine map 1..4 : 2F 01 <map-1>  -> 6F 01 <map-1>    MHD, car standing still only (user decision)
 *   Max Cooling     : 2F 03 01 | 00  -> 6F 03 01 | 00    MHD, any speed; On only with the engine running
 *                     (OBD rpm over 500, as upstream 1a81d0a), Off any time and shown until a press
 *   MHD presses count only when the DME echoes the request (an untuned DME refuses them). MHD has no
 *   read-back of the map or cooling, so the screen says "accepted", never "confirmed".
 *   Exhaust flap    : any speed. MHD's own flap control first: 2F 02 01 open, 02 close, 00 back to the tune, echoed
 *     6F 02 nn, held while driving (car-apps issue #3: BMW's jobs drop once the car moves). A DME that refuses it for
 *     good (untuned) gets BMW's own jobs (SGBD dme8ff_r), two kinds (flap.js):
 *     regulated (S58 and others): 2F 611E 03 0333 open (10 %), 03 1CCD close (90 %), position 22 651E (% x 81.92)
 *     plain: 2F 60FD 03 03E8 open (10 %), 03 2328 close (90 %), position 22 64FD (% x 100)
 *   00 hands the flap back to the DME; it ends a BMW override by itself after ~20 s. <= 20 % open, >= 80 % closed.
 *   The first read asks 22 651E; a DME that refuses it for good is plain; one that refuses both has no electric flap.
 *
 * Opening the app only reads: OBD speed + rpm (the gates) + the flap position every 2 s while the screen shows.
 * Nothing is undone when the app closes (the DME ends a flap override itself).
 *
 * Screen: drawn by the GPU renderer, designed in the HMI UI builder: apps/hmi-ui-builder/projects/live-adjustments.json,
 * exported into this folder (rhmiData/ = one empty RHMI host state per HMI, ID7 + ID8, renderer/ = screens.json + the
 * builder's runtime). Start, tile and shutdown on iDrive 7 and 8: the shared OnlineApp host (oap-shared/online-host.js).
 */
const fs = require('fs');
const path = require('path');
const util = require('util');
const someipBuilders                   = require('oap-sdk/src/someip/someipBuilders');
const { Diag, hex, NRC }               = require('./diag.js');
const { createGuard }                  = require('./tasu-guard.js');
const { createHost }                   = require('./online-host.js');
const flap                             = require('./flap.js');

const LOG = '[iteriodev_liveadjust]';
const STATES = ['home'];          // screens = their RHMI host states (uiDescriptions ID7 + ID8), the entry state first

// the linked bundle is javascript/app.js: the package root is one up, the app's data folder beside it (the Store's)
const SOURCE = typeof __dirname === 'string' ? path.join(__dirname, '..') : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const DATA = path.join(__dirname, '..', '..', 'data');
const LOG_FILE = `${DATA}/liveadjust.log`;

const TASU_IF = 'com.harman.infotainment.systemfunctions.tasu.tasu.InternalTasu';
const TASU_INST = 'SystemFunctionsInternalTasuInst1';
const DME = 0x12;
const OVERRIDE_MS = 20000;        // the DME's own override timer (SGBD default)
const POLL_MS = 2000;
const FRESH_MS = 2 * POLL_MS + 1000;
const MIN_COOLING_RPM = 500;      // Max Cooling On: the engine must be running
const MSG_MS = 8000;              // an action's message replaces the card's state line this long
const RED = '#e22718', ICE = '#81c4ff', GREEN = '#3ecf6e', AMBER = '#ffb020', DIM = '#5a6170';

// ---- state + log ------------------------------------------------------------------------------------
const errText = (e) => String(e && e.message || e).slice(0, 120);
function log() {
    const line = [new Date().toISOString()].concat([].slice.call(arguments)
        .map((x) => (typeof x === 'string' ? x : util.inspect(x, { depth: 4 }).slice(0, 2000)))).join(' ');
    console.error(LOG, line);
    try { if (fs.statSync(LOG_FILE).size > 256 * 1024) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* no file yet */ }
    try { fs.appendFileSync(LOG_FILE, `${line}\n`); } catch (e) { /* no data folder */ }
}

// standing still is the map switch's gate (the engine may run); cooling and the flap go at any speed (user)
const still = createGuard({ engineRunning: true, freshMs: FRESH_MS });
const anySpeed = (sid, d) => sid === 0x2F && ((d[0] === 0x03 && d.length === 2) || flap.isFlapSet(d));
const guard = Object.assign({}, still, { check: (sid, d) => (anySpeed(sid, d) ? { ok: true, why: '' } : still.check(sid, d)) });

let diag = null;                  // Diag over TASU
let dmeOk = null;                 // the DME answered the last poll (null = not asked yet)
let map = null;                   // 1..4, the map the DME last accepted (this app's press)
let cooling = 'OFF';              // 'ON' | 'OFF': Off until a press (user: Off is the default)
let rpm = null, rpmAt = 0;        // OBD engine speed and when it was read
let flapPct = null;               // where the DME drives the flap, %
let flapFound = null;             // false: the DME has no electric flap
let flapKind = null;              // 'regulated' | 'plain' once a read told (flap.js)
let flapMhd = null;               // false: MHD's flap control refused for good (BMW's job then)
let override = null;              // 'open' | 'close' while our override runs
let overrideUntil = 0;
let busy = null;                  // the card whose command is running
let polling = false;
const msgs = {};                  // card -> { text, color, at }

// ---- UDS --------------------------------------------------------------------------------------------
const nrcText = (u) => (u && u[0] === 0x7F ? (NRC[u[2]] || `NRC ${hex(u[2])}`) : 'no reply');

function readSpeed() {
    return diag.physical(DME, 0x01, [0x0D], 1200, (u) => (u[0] === 0x41 && u[1] === 0x0D) || (u[0] === 0x7F && u[1] === 0x01))
        .then((u) => { if (u && u[0] === 0x41) guard.speed(u[2]); return !!u; }, () => false);
}

function readRpm() {
    return diag.physical(DME, 0x01, [0x0C], 1200, (u) => (u[0] === 0x41 && u[1] === 0x0C) || (u[0] === 0x7F && u[1] === 0x01))
        .then((u) => { if (u && u[0] === 0x41 && u.length >= 4) { rpm = ((u[2] << 8) | u[3]) / 4; rpmAt = Date.now(); } return !!u; }, () => false);
}
const rpmKnown = () => rpm !== null && Date.now() - rpmAt <= FRESH_MS;
const engineStopped = () => rpmKnown() && rpm <= MIN_COOLING_RPM;

/** the flap position; the first answers decide which kind of flap this DME has */
function readFlap() {
    const kind = flapKind || 'regulated';
    return diag.physical(DME, 0x22, flap.KINDS[kind].read, 2000, (u) => flap.isRead(kind, u)).then((u) => {
        const r = flap.onRead(kind, u);
        if (r.kind) { log('flap: no regulated flap job (22 651E', nrcText(u), '), using the plain one'); flapKind = r.kind; return readFlap(); }
        if (r.none) { flapFound = false; flapPct = null; }
        if (r.pct !== undefined) { flapPct = r.pct; flapFound = true; if (!flapKind) log('flap: regulated (22 651E)'); flapKind = kind; }
        return !!u;
    }, () => false);
}

function poll() {
    if (!diag || polling || busy) return Promise.resolve();
    polling = true;
    return Promise.all([readSpeed(), readRpm(), readFlap()])
        .then((r) => { dmeOk = r[0] || r[1] || r[2]; }, (e) => log('poll failed:', e))
        .then(() => { polling = false; if (override && Date.now() > overrideUntil) override = null; render(); });
}

/** MHD: the press counts only when the DME echoes it back */
function sendMhd(data) {
    return diag.physical(DME, 0x2F, data, 3000).then((u) => {
        log('MHD 2F', data.map((b) => hex(b)).join(' '), '->', u ? u.map((b) => hex(b)).join(' ') : 'no reply');
        if (u && u[0] === 0x6F && data.every((b, i) => u[i + 1] === b)) return;
        throw new Error(u && u[0] === 0x7F ? 'Not available on this car (no MHD answer)' : 'No answer from the DME');
    });
}

function say(card, text, color) { msgs[card] = { text, color, at: Date.now() }; render(); }

/** One command per card at a time; the card's line shows what the DME said, or why nothing was sent */
function run(card, label, fn) {
    if (busy || !diag) { if (!diag) say(card, 'No diagnostic link yet', AMBER); return Promise.resolve(); }
    busy = card;
    say(card, `Sending ${label}...`, DIM);
    return Promise.resolve().then(fn)
        .then((t) => say(card, t, GREEN), (e) => { log(label, 'failed:', errText(e)); say(card, errText(e), AMBER); })
        .then(() => { busy = null; render(); });
}

function setMap(n) {
    return run('map', `map ${n}`, () => readSpeed().then(() => {   // fresh speed right before the switch
        const p = guard.parked();
        if (!p.ok) throw new Error(`Map change needs the car standing still (${p.why})`);
        return sendMhd([0x01, n - 1]);
    }).then(() => { map = n; return `Map ${n} · accepted by the DME`; }));
}

function setCooling(on) {
    return run('cool', `Max Cooling ${on ? 'on' : 'off'}`, () => (on ? readRpm() : Promise.resolve()).then(() => {   // fresh rpm for On
        if (on && !rpmKnown()) throw new Error('Engine speed unknown · nothing sent');
        if (on && engineStopped()) throw new Error('Start the engine first');
        return sendMhd([0x03, on ? 0x01 : 0x00]);
    }).then(() => { cooling = on ? 'ON' : 'OFF'; return `Max Cooling ${on ? 'on' : 'off'} · accepted by the DME`; }));
}

/** MHD's flap control: 'mhd' when the tune holds it, null when this DME has none (then BMW's job) */
function mhdFlap(k) {
    if (flapMhd === false) return Promise.resolve(null);
    return diag.physical(DME, 0x2F, flap.MHD[k], 3000).then((u) => {
        log('flap MHD', k, '->', u ? u.map((b) => hex(b)).join(' ') : 'no reply');
        const r = flap.onMhd(k, u);
        if (r === 'busy') throw new Error(u ? `The DME refused: ${nrcText(u)}` : 'No answer from the DME');
        flapMhd = r === 'held';
        return flapMhd ? 'mhd' : null;
    });
}

/** BMW's own flap job (a diagnostic override: the DME drops it when the car moves or after ~20 s) */
function bmwFlap(k) {
    return (flapKind ? Promise.resolve() : readFlap()).then(() => {
        if (!flapKind) throw new Error('Flap not read yet · nothing sent');
        return diag.physical(DME, 0x2F, flap.command(flapKind, k), 3000);
    }).then((u) => {
        log('flap', flapKind, k, '->', u ? u.map((b) => hex(b)).join(' ') : 'no reply');
        if (!u) throw new Error('No answer from the DME');
        if (u[0] === 0x7F) throw new Error(`The DME refused: ${nrcText(u)}`);
        return 'bmw';
    });
}

function setFlap(k) {
    return run('flap', `flap ${k}`, () => mhdFlap(k).then((via) => via || bmwFlap(k)).then((via) => {
        override = k === 'oem' ? null : k;
        overrideUntil = via === 'mhd' ? Infinity : Date.now() + OVERRIDE_MS;
        return readFlap().then(() => (k === 'oem' ? 'Handed back to the DME'
            : `${k === 'open' ? 'Open' : 'Closed'} · ${via === 'mhd' ? 'held by MHD' : 'accepted by the DME'}`));
    }));
}

// ---- screens (the renderer) ----------------------------------------------------------------------------
// renderer/ is the builder's export: screens.json + its runtime. Loaded with a computed path: the linker
// (oap_link.js) leaves it to the platform require (plain files in the package, Node 8).
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
let screens = null;

const fresh = (card) => msgs[card] && Date.now() - msgs[card].at <= MSG_MS && msgs[card];
const line = (card, text, color) => { const m = fresh(card); return m ? { text: m.text, color: m.color } : { text, color }; };
const btn = (on, color, off) => ({ style: on ? 'primary' : 'outline', color: on ? color : '', disabled: !!(busy || off) });

function render() {
    if (!screens) return;
    const p = guard.parked();
    screens.set('checkChips', { items: [
        { text: dmeOk === null ? 'DME not asked yet' : dmeOk ? 'DME answers' : 'DME not answering', color: dmeOk ? GREEN : AMBER, dot: true },
        { text: p.ok ? 'Standing still' : `Map locked · ${p.why}`, color: p.ok ? GREEN : AMBER, dot: true },
    ] });

    screens.set('mapValue', { text: map ? `MAP ${map}` : 'MAP --', color: map ? 'text' : DIM })
        .set('mapSub', line('map', map ? 'Accepted by the DME' : 'Tap a map: it switches at once', map ? GREEN : DIM));
    [1, 2, 3, 4].forEach((n) => screens.set(`map${n}`, btn(map === n, RED, !p.ok)));

    // the flap: where the DME drives it; our override's countdown while it runs
    const held = !!override && overrideUntil === Infinity;      // MHD holds it until the next press
    const left = override && !held ? Math.max(0, Math.ceil((overrideUntil - Date.now()) / 1000)) : 0;
    const pos = flap.state(flapPct);
    const open = pos === 'OPEN', none = flapFound === false;
    screens.set('flapValue', { text: none ? 'NONE' : pos || '--', color: open ? ICE : pos === 'CLOSED' ? RED : DIM });
    ['pipeL', 'pipeR'].forEach((t) => screens.set(`${t}Open`, { hidden: !open }).set(`${t}Shut`, { hidden: open })
        .set(`${t}Glow`, { hidden: !open }));
    screens.set('flapSub', line('flap', none ? 'This DME has no electric exhaust flap'
        : held ? `${override === 'open' ? 'Open' : 'Closed'} · MHD holds it until you change it`
        : left ? `${override === 'open' ? 'Open' : 'Closed'} for ${left} s more, then the DME decides`
            : flapPct === null ? 'Flap position not read yet' : `The DME drives the flap: ${flapPct} %`, DIM))
        .set('flapOpen', btn(override === 'open', ICE, none))
        .set('flapClose', btn(override === 'close', RED, none))
        .set('flapOem', btn(!override && flapFound === true, ICE, none));

    // On needs the engine running; the line speaks only when it is stopped (no rpm on screen: user)
    const stopped = engineStopped();
    screens.set('coolValue', { text: cooling, color: cooling === 'ON' ? ICE : 'text' })
        .set('coolIcon', { color: cooling === 'ON' ? ICE : DIM })
        .set('coolSub', line('cool', stopped ? 'Engine stopped · On needs it running' : '', AMBER))
        .set('coolOn', btn(cooling === 'ON', ICE, stopped))
        .set('coolOff', btn(cooling === 'OFF', ICE));
}

const EVENTS = {
    map1: () => setMap(1), map2: () => setMap(2), map3: () => setMap(3), map4: () => setMap(4),
    open: () => setFlap('open'), close: () => setFlap('close'), oem: () => setFlap('oem'),
    coolOn: () => setCooling(true), coolOff: () => setCooling(false),
};
const onEvent = (name) => { if (EVENTS[name]) Promise.resolve().then(EVENTS[name]).catch((e) => log(`${name} failed:`, e)); };

// ---- RHMI: the host state (the OnlineApp host hands it over) ------------------------------------------
let app = null;
const comp = (n) => app.getByName(n);
function showScreen(name) {
    return comp(name).updateResources().then(() => app.openState(name))
        .then(() => log(`opened ${name}`))
        .catch((e) => log(`open ${name} failed:`, e));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed:`, e));

function startScreens(rhmiApp, hosts) {
    app = rhmiApp;
    const design = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: (m) => log(m), warn: (m) => log(m), error: (m) => log(m) };
    const gpu = new RenderClient('iteriodev_liveadjust', rlog);
    screens = new ScreenApp(gpu, design, { view: 'id8', log: rlog });
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('event', onEvent);
    screens.on('show', () => { poll(); render(); });
    // the user left for the HMI (touched it): leave the host state too, or the HMI would show its empty page
    screens.on('closed', (why) => { if (why !== 'hmi') STATES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
    render();
    // reads only while the screen shows
    setInterval(() => { if (screens.st && !screens.paused) poll(); }, POLL_MS);
}

// ---- TASU link --------------------------------------------------------------------------------------
function connectTasu() {
    return someipBuilders.buildAndInitTypedProxy(TASU_IF, TASU_INST, { timeoutMs: 10000 })
        .then((proxy) => { diag = new Diag(log, guard); return diag.attach(proxy); })
        .then(() => { log('TASU connected'); return poll(); })
        .catch((e) => { dmeOk = false; log('TASU failed:', e); setTimeout(connectTasu, 30000); render(); });
}

// ---- lifecycle: the shared OnlineApp host (start, tile, shutdown; iDrive 7 + 8) -------------------------
// The TASU link and its reads start with the screens; nothing to hand back at shutdown (the DME ends a flap
// override itself).
log('start', process.getuid());
createHost({
    states: STATES,
    log,
    onReady: (rhmiApp, hosts) => { startScreens(rhmiApp, hosts); log('screens ready'); connectTasu(); },
});

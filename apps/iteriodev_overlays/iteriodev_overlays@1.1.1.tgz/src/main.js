'use strict';
/*
 * oap-overlays ("Overlays"): the control panel of the iteriodev-overlays tool, the QuickSelect strip in the climate
 * bar (iDrive 8): what each of the four shortcuts opens, the shortcuts / seat / wheel buttons on or off, the tap
 * order, the shift lights on the cluster (any car: drawn by cluster-render, lit from the engine speed or an M car's
 * own shift-light signal), and on M cars which M Mode M1 / M2 switch to. Everything is the tool's: this app talks to it over its control
 * socket (JSON lines, CTL) and shows what it says. The tool pushes every change: a slot saved by a hold in the bar,
 * the seats the car has, the car found to be an M car (its M setup reported; the M Mode page shows only then).
 *   -> { op: 'get' | 'targets' | 'reset' } | { op: 'set', settings } | { op: 'slot', i, target }
 *   <- { state: { settings, slots: [{ kind, title, icon?, app? }], car: { backend, seats, wheel, mcar, setups } } }
 *      | { targets: { bmw: [{ title, state, applet, icon }], apps: [{ id, title, state, offset, pic (PNG base64) }] } }
 *
 * Screens: drawn by the GPU renderer, designed in the HMI UI builder: apps/hmi-ui-builder/projects/overlays.json
 * (scripts/oap-tools/make_overlays_project.js), exported into this folder (rhmiData/ = one empty RHMI host state per
 * screen, renderer/ = screens.json + the builder's runtime). Start, tile and shutdown: the shared OnlineApp host
 * (oap-shared/online-host.js).
 */
const fs = require('fs');
const net = require('net');
const path = require('path');
const util = require('util');
const { createHost }                   = require('./online-host.js');

const LOG = '[iteriodev_overlays]';
const STATES = ['shortcuts', 'pick', 'climate', 'shift', 'mmode'];   // screens = their RHMI host states
const CTL = process.env.OVERLAYS_CTL || '/run/iteriodev-overlays/ctl.sock';
const RETRY_MS = 2000;
const MODES = ['road', 'sport', 'track'];
const AMBER = '#ffb020';

// the linked bundle is javascript/app.js: the package root (next to renderer/) is its parent folder, the app's data
// folder beside that (the Store's)
const SOURCE = typeof __dirname === 'string' ? path.join(__dirname, '..') : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const DATA = path.join(__dirname, '..', '..', 'data');
const LOG_FILE = `${DATA}/overlays.log`;

function log() {
    const line = [new Date().toISOString()].concat([].slice.call(arguments)
        .map((x) => (typeof x === 'string' ? x : util.inspect(x, { depth: 4 }).slice(0, 2000)))).join(' ');
    console.error(LOG, line);
    try { if (fs.statSync(LOG_FILE).size > 256 * 1024) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* no file yet */ }
    try { fs.appendFileSync(LOG_FILE, `${line}\n`); } catch (e) { /* no data folder */ }
}

// ---- the tool ---------------------------------------------------------------------------------------------
let tool = null;                  // its last state, null = no connection
let targets = null;               // what a slot can open (asked for when the picker shows)
let sock = null;
let sel = 0;                      // the slot picked on the shortcuts page
let busy = false;                 // a connection being made

function connect() {
    if (sock || busy) return;
    busy = true;
    const s = net.connect(CTL);
    let buf = '';
    s.setEncoding('utf8');
    s.on('connect', () => { busy = false; sock = s; log('tool connected'); if (targets === null) send({ op: 'targets' }); });
    s.on('data', (d) => {
        buf += d;
        for (let n; (n = buf.indexOf('\n')) >= 0; buf = buf.slice(n + 1)) {
            let m;
            try { m = JSON.parse(buf.slice(0, n)); } catch (e) { continue; }
            if (m.state) tool = m.state;
            if (m.targets) { targets = m.targets; pictures(); }
            render();
        }
    });
    s.on('error', (e) => { if (!/ENOENT|ECONNREFUSED/.test(e.code)) log('tool:', e.message); });
    s.on('close', () => { busy = false; sock = null; tool = null; render(); setTimeout(connect, RETRY_MS); });
}
const send = (q) => { if (sock) sock.write(`${JSON.stringify(q)}\n`); };
const setting = (s) => send({ op: 'set', settings: s });

// ---- screens (the renderer) ----------------------------------------------------------------------------
// renderer/ is the builder's export: screens.json + its runtime. Loaded with a computed path: the linked app.js
// leaves it to the platform require (plain files in the package, Node 8).
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
let screens = null;
const pics = {};                  // app id -> { len, img }: its picture, uploaded as 'p:<id>'

function pictures() {
    const { makeImage, dropImage } = runtime('kit/record.js'), png = runtime('kit/png.js');
    (targets.apps || []).forEach((a) => {
        if (!a.pic || (pics[a.id] && pics[a.id].len === a.pic.length)) return;
        try {
            const p = png.decode(Buffer.from(a.pic, 'base64')), img = makeImage(p.w, p.h, p.data);
            if (pics[a.id]) dropImage(pics[a.id].img);
            pics[a.id] = { len: a.pic.length, img };
            screens.setImage(`p:${a.id}`, img);
        } catch (e) { log(`picture of ${a.id}:`, e.message); }
    });
}

/* the cluster's bars (the tool's shiftlights.js shader, on the CPU) with 5 of 8 lit: the shift page's picture of them,
 * the band they sit in (702 x 68 of its 702 x 213) */
function barsPicture() {
    const W = 702, H = 68, d = Buffer.alloc(W * H * 4);
    for (let y = 0; y < H; y++) {
        for (let x = 0; x < W; x++) {
            const px = x + 0.5, py = y + 64.5, xx = px < W / 2 ? px : W - px;
            const xs = xx - 20 - (132 - py) * 0.35, i = Math.floor(xs / 38);
            if (xs < 0 || i > 7 || xs % 38 > 30) continue;
            const c = i >= 5 ? [140, 145, 155, 56] : i < 3 ? [255, 184, 0, 255] : [255, 107, 0, 255];
            d.set(c, (y * W + x) * 4);
        }
    }
    return runtime('kit/record.js').makeImage(W, H, d);
}

const PAGES = () =>['shortcuts', 'climate', 'shift'].concat(tool && tool.car.mcar ? ['mmode'] : []);
const MENU = { shortcuts: 'Shortcuts, FavoriteAdd', climate: 'Climate, Fan', shift: 'Shift lights, Motordynamic', mmode: 'M Mode, MMODE' };
const MENUS = { shortcuts: 'shortcutsMenu', pick: 'pickMenu', climate: 'climateMenu', shift: 'shiftMenu', mmode: 'mmodeMenu' };
const CR_STATE = { connected: 'Connected', connecting: 'Starting', 'not running': 'Not running', missing: 'Not installed' };
// the M Mode page's rows A B C: SP21 cars tell M1 from M2, SP18 cars only "an M setup on"
const ROWS = () => (tool && tool.car.setups === 2
    ? [['m1', 'M1 on', 'The M Mode while M1 is active'], ['m2', 'M2 on', 'The M Mode while M2 is active'], ['off', 'M1 / M2 off', 'Back to this one']]
    : [['m1', 'M1 / M2 on', 'The M Mode while an M setup is active'], ['off', 'M1 / M2 off', 'Back to this one']]);
const fnText = (s) => (s.heat && s.cool ? 'Heat · Vent' : s.heat ? 'Heat' : s.cool ? 'Vent' : 'None');
const BACKEND = { legacy: 'Climate (G series)', master: 'Climate master', demo: 'Demo seats' };
const slotSub = (i) => `Slot ${i + 1} · ${i < 2 ? 'left' : 'right'} of CLIMATE MENU`;

function render() {
    if (!screens) return;
    const t = tool, pages = PAGES(), items = pages.map((p) => MENU[p]).join('\n');
    Object.keys(MENUS).forEach((p) => screens.set(MENUS[p], { items, sel: Math.max(0, pages.indexOf(p === 'pick' ? 'shortcuts' : p)) }));
    // shortcuts
    screens.set('scTitle', t ? { text: 'SHORTCUTS IN THE CLIMATE BAR  ·  TAP ONE TO CHANGE IT', color: 'dim' }
        : { text: 'THE OVERLAYS TOOL IS NOT RUNNING  ·  INSTALL IT FROM THE STORE, THEN RESTART THE HEAD UNIT', color: AMBER });
    for (let i = 0; i < 4; i++) {
        const d = t && t.slots[i], pic = d && d.kind === 'app' && pics[d.app];
        screens.set(`slot${i}`, { title: d ? d.title : '--', sub: d && d.missing ? 'App not installed' : slotSub(i),
            icon: d && d.kind === 'bmw' ? d.icon : pic ? '' : 'Display', selected: i === sel });
        screens.set(`slotPic${i}`, { src: `key:p:${d && d.app}`, hidden: !pic });
    }
    const cur = t && t.slots[sel];
    screens.set('showShortcuts', { on: !t || t.settings.shortcuts })
        .set('slotNow', { label: `Slot ${sel + 1}`, sub: cur ? `${cur.title} · ${cur.kind === 'app' ? 'App' : 'BMW screen'}` : '--',
            icon: cur && cur.kind === 'bmw' ? cur.icon : 'Display' })
        .set('pickTitle', { text: `SLOT ${sel + 1}  ·  PICK WHAT IT OPENS` });
    // pick
    const bmw = (targets && targets.bmw) || [], apps = ((targets && targets.apps) || []).slice(0, 12);
    for (let i = 0; i < 6; i++) {
        const b = bmw[i];
        screens.set(`bmw${i}`, b ? { title: b.title, icon: b.icon, hidden: false, selected: !!cur && cur.kind === 'bmw' && cur.title === b.title } : { hidden: true });
    }
    screens.set('appsTitle', { text: targets ? (apps.length ? 'APPS ON THIS CAR' : 'APPS ON THIS CAR  ·  NONE WITH A TILE') : 'APPS ON THIS CAR  ·  READING...' });
    for (let i = 0; i < 12; i++) {
        const a = apps[i];
        screens.set(`app${i}`, a ? { title: a.title, icon: pics[a.id] ? '' : 'Display', hidden: false, selected: !!cur && cur.app === a.id } : { hidden: true });
        screens.set(`appPic${i}`, { src: `key:p:${a && a.id}`, hidden: !a || !pics[a.id] });
    }
    // climate
    const car = t ? t.car : null;
    screens.set('seatsRow', { on: !t || t.settings.seats }).set('wheelRow', { on: !t || t.settings.wheel })
        .set('orderRow', { text: t && t.settings.order === 'down' ? '3 → 2 → 1 → off' : '1 → 2 → 3 → off' })
        .set('drRow', { text: car && car.backend ? fnText(car.seats.driver) : '--' })
        .set('psRow', { text: car && car.backend ? fnText(car.seats.passenger) : '--' })
        .set('swRow', { text: car ? (car.wheel ? 'Heat' : 'None') : '--' })
        .set('beRow', { text: car ? BACKEND[car.backend] || 'Not found yet' : '--' });
    // shift lights
    const sh = t && t.settings.shift, ss = t && t.shift;
    if (sh) {
        screens.set('shiftRow', { on: sh.on }).set('autoRow', { on: sh.auto })
            .set('autoNow', { hidden: !sh.auto, text: ss ? `${ss.th.start} → ${ss.th.flash} rpm` : '--',
                sub: ss && ss.limit ? 'Start, then all flash at' : 'Start, then all flash at (no limit from the engine yet: the set values)' })
            .set('startRow', { hidden: sh.auto, value: sh.start }).set('flashRow', { hidden: sh.auto, value: sh.flash })
            .set('hudRow', { on: sh.hud, hidden: !sh.auto || t.car.mcar }).set('hudRow2', { on: sh.hud, hidden: sh.auto || t.car.mcar });
    }
    screens.set('srcRow', { text: ss && ss.dme ? 'The DME (M car)' : 'Engine speed' })
        .set('limitRow', { text: ss && ss.limit ? `${ss.limit} rpm` : 'Not reported' })
        .set('crRow', { text: ss ? (ss.layer && /refused|error/.test(ss.layer) ? `Refused: ${ss.layer.replace(/^refused: /, '')}`.slice(0, 40)
            : CR_STATE[ss.renderer] || ss.renderer) : '--' });
    // M Mode
    const rows = ROWS(), mm = t ? t.settings.mmode : null;
    screens.set('linkRow', { on: !mm || mm.on }).set('bootRow', { on: !!(mm && mm.boot) });
    ['A', 'B', 'C'].forEach((k, i) => {
        const r = rows[i];
        screens.set(`row${k}`, r ? { label: r[1], sub: r[2], hidden: false } : { hidden: true });
        screens.set(`tabs${k}`, r ? { sel: Math.max(0, MODES.indexOf(mm ? mm[r[0]] : 'sport')), hidden: false } : { hidden: true });
    });
}

// ---- what the user does ---------------------------------------------------------------------------------
function pick(target) {
    send({ op: 'slot', i: sel, target });
    closeScreen('pick');
}
const EVENTS = {
    change: () => showScreen('pick'),                // (its 'show' asks the tool for what a slot can open)
    reset: () => send({ op: 'reset' }),
    order: () => tool && setting({ order: tool.settings.order === 'down' ? 'up' : 'down' }),
};
function onEvent(name) {
    let m;
    if ((m = /^slot(\d)$/.exec(name))) { sel = +m[1]; render(); return; }
    if ((m = /^bmw(\d)$/.exec(name))) { const b = targets && targets.bmw[+m[1]]; if (b) pick({ state: b.state, applet: b.applet }); return; }
    if ((m = /^app(\d+)$/.exec(name))) { const a = targets && targets.apps[+m[1]]; if (a) pick({ app: a.id, state: a.state, offset: a.offset }); return; }
    if (EVENTS[name]) EVENTS[name]();
}
const TOGGLES = { showShortcuts: 'shortcuts', seatsRow: 'seats', wheelRow: 'wheel' };
function onChange(name, o) {
    if (TOGGLES[name]) return setting({ [TOGGLES[name]]: !!o.on });
    if (name === 'linkRow') return setting({ mmode: { on: !!o.on } });
    if (name === 'bootRow') return setting({ mmode: { boot: !!o.on } });
    if (name === 'shiftRow') return setting({ shift: { on: !!o.on } });
    if (name === 'autoRow') return setting({ shift: { auto: !!o.on } });
    if (name === 'hudRow' || name === 'hudRow2') return setting({ shift: { hud: !!o.on } });
    if (name === 'startRow' || name === 'flashRow') return setting({ shift: { [name === 'startRow' ? 'start' : 'flash']: Math.round(o.value / 100) * 100 } });
    const t = /^tabs([ABC])$/.exec(name), r = t && ROWS()['ABC'.indexOf(t[1])];
    if (r) return setting({ mmode: { [r[0]]: MODES[o.sel] } });
    const page = Object.keys(MENUS).find((p) => MENUS[p] === name);
    if (page) {                                       // the side menu (o is the element's opts: read before the set)
        const to = PAGES()[o.sel];
        screens.set(name, { sel: Math.max(0, PAGES().indexOf(page === 'pick' ? 'shortcuts' : page)) });
        goTo(to);
    }
    return null;
}
// shortcuts is the app's first screen, the other pages open over it (BACK returns to it)
function goTo(page) {
    const cur = screens.st && screens.st.name;
    if (!page || page === cur) return;
    if (cur && cur !== 'shortcuts') closeScreen(cur);
    if (page !== 'shortcuts') showScreen(page);
}

// ---- RHMI: the host states (the shared OnlineApp host hands over the RHMI application) -------------------
let app = null;
const comp = (n) => app.getByName(n);
function showScreen(name) {
    return comp(name).updateResources().then(() => app.openState(name))
        .then(() => log(`opened ${name}`))
        .catch((e) => log(`open ${name} failed:`, e));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed:`, e));

function startScreens(rhmiApp) {
    app = rhmiApp;
    const design = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: (m) => log(m), warn: (m) => log(m), error: (m) => log(m) };
    const gpu = new RenderClient('iteriodev_overlays', rlog);
    screens = new ScreenApp(gpu, design, { view: 'id8', log: rlog });
    try { screens.setImage('shiftPreview', barsPicture()); } catch (e) { log('shift preview:', e.message); }
    const hosts = {};
    STATES.forEach((s) => { hosts[s] = comp(s); });
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('event', (n) => { try { onEvent(n); } catch (e) { log(`${n} failed:`, e); } });
    screens.on('change', (n, o) => { try { onChange(n, o); } catch (e) { log(`${n} failed:`, e); } });
    screens.on('show', (name) => { if (name === 'pick') send({ op: 'targets' }); render(); });
    // the user left for the HMI (touched it): leave the host states too, or the HMI would show its empty page
    screens.on('closed', (why) => { if (why !== 'hmi') STATES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
    connect();
    render();
}

// ---- lifecycle: the shared OnlineApp host (start, tile, shutdown) -----------------------------------------
log('start', process.getuid());
createHost({
    states: STATES,
    log,
    onReady: (rhmiApp) => { startScreens(rhmiApp); log('screens ready'); },
});

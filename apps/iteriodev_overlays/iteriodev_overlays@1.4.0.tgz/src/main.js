'use strict';
/*
 * oap-overlays ("Overlays"): the control panel of the iteriodev-overlays tool, the QuickSelect strip in the climate
 * bar (iDrive 8): what each of the four shortcuts opens, the shortcuts / seat / wheel buttons on or off, the tap
 * order, the shift lights on the cluster (cars without their own: drawn by cluster-render, lit from the engine speed;
 * an M car shows its own, so the tool hides ours there), and on M cars which M Mode M1 / M2 switch to. Everything is the tool's: this app talks to it over its control
 * socket (JSON lines, CTL) and shows what it says. The tool pushes every change: a slot saved by a hold in the bar,
 * the seats the car has, the car found to be an M car (its M setup reported). The user can override both: each seat /
 * wheel button AUTO / ON / OFF, the M car AUTO / YES / NO.
 *   -> { op: 'get' | 'targets' | 'reset' } | { op: 'set', settings } | { op: 'slot', i, target }
 *      | { op: 'icons', q, page } | { op: 'icons', ids } | { op: 'icon', i, icon: id | null }   (tool 0.5.0)
 *   <- { state: { settings, slots: [{ kind, title, icon?, app?, hmiIcon?, iconName? }], car: { backend, seats, wheel, mcar, setups } } }
 *      | { targets: { bmw: [{ title, state, applet, icon }], apps: [{ id, title, state, offset, pic (PNG base64) }] } }
 *      | { icons: { q, page, pages, total, suggested, items: [{ id, name, pic }] } | { ids: true, items } }
 * A slot's picture can be one of the head unit's own icons (1.4.0, user 2026-11-12): the tool reads them on the car
 * (its hmiicons.js) and sends them as PNGs; the picker shows 24 a page, a search over their names, Default icon.
 *
 * Screens: drawn by the GPU renderer, designed in the HMI UI builder: apps/hmi-ui-builder/projects/overlays.json
 * (scripts/oap-tools/make_overlays_project.js), exported into this folder (rhmiData/ = one empty RHMI host state per
 * screen, renderer/ = screens.json + the builder's runtime). Start, tile and shutdown: the shared OnlineApp host
 * (oap-shared/online-host.js).
 */
const fs = require('fs');
const net = require('net');
const path = require('path');
const util = require('util');
const { createHost }                   = require('./online-host.js');

const LOG = '[iteriodev_overlays]';
const STATES = ['shortcuts', 'pick', 'icons', 'iconSearch', 'climate', 'shift', 'mmode'];   // screens = their RHMI host states
const SUB = ['pick', 'icons', 'iconSearch'];        // sub-pages of Shortcuts (its tab stays selected)
const CTL = process.env.OVERLAYS_CTL || '/run/iteriodev-overlays/ctl.sock';
const RETRY_MS = 2000;
const MODES = ['road', 'sport', 'track'];

// the linked bundle is javascript/app.js: the package root (next to renderer/) is its parent folder, the app's data
// folder beside that (the Store's)
const SOURCE = typeof __dirname === 'string' ? path.join(__dirname, '..') : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const DATA = path.join(__dirname, '..', '..', 'data');
const LOG_FILE = `${DATA}/overlays.log`;

function log() {
    const line = [new Date().toISOString()].concat([].slice.call(arguments)
        .map((x) => (typeof x === 'string' ? x : util.inspect(x, { depth: 4 }).slice(0, 2000)))).join(' ');
    console.error(LOG, line);
    try { if (fs.statSync(LOG_FILE).size > 256 * 1024) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* no file yet */ }
    try { fs.appendFileSync(LOG_FILE, `${line}\n`); } catch (e) { /* no data folder */ }
}

// ---- the tool ---------------------------------------------------------------------------------------------
let tool = null;                  // its last state, null = no connection
let targets = null;               // what a slot can open (asked for when the picker shows)
let sock = null;
let sel = 0;                      // the slot picked on the shortcuts page
let busy = false;                 // a connection being made

function connect() {
    if (sock || busy) return;
    busy = true;
    const s = net.connect(CTL);
    let buf = '';
    s.setEncoding('utf8');
    s.on('connect', () => { busy = false; sock = s; log('tool connected'); if (targets === null) send({ op: 'targets' }); });
    s.on('data', (d) => {
        buf += d;
        for (let n; (n = buf.indexOf('\n')) >= 0; buf = buf.slice(n + 1)) {
            let m;
            try { m = JSON.parse(buf.slice(0, n)); } catch (e) { continue; }
            if (m.state) { tool = m.state; slotIcons(); }
            if (m.targets) { targets = m.targets; pictures(); }
            if (m.icons) iconReply(m.icons);
            render();
        }
    });
    s.on('error', (e) => { if (!/ENOENT|ECONNREFUSED/.test(e.code)) log('tool:', e.message); });
    s.on('close', () => { busy = false; sock = null; tool = null; render(); setTimeout(connect, RETRY_MS); });
}
const send = (q) => { if (sock) sock.write(`${JSON.stringify(q)}\n`); };
const setting = (s) => send({ op: 'set', settings: s });

// ---- screens (the renderer) ----------------------------------------------------------------------------
// renderer/ is the builder's export: screens.json + its runtime. Loaded with a computed path: the linked app.js
// leaves it to the platform require (plain files in the package, Node 8).
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
let screens = null, gpu = null;
const pics = {};                 // app id -> { len, img }: its picture, uploaded as 'p:<id>'

function pictures() {
    const { makeImage, dropImage } = runtime('kit/record.js'), png = runtime('kit/png.js');
    (targets.apps || []).forEach((a) => {
        if (!a.pic || (pics[a.id] && pics[a.id].len === a.pic.length)) return;
        try {
            const p = png.decode(Buffer.from(a.pic, 'base64')), img = makeImage(p.w, p.h, p.data);
            if (pics[a.id]) dropImage(pics[a.id].img);
            pics[a.id] = { len: a.pic.length, img };
            screens.setImage(`p:${a.id}`, img);
        } catch (e) { log(`picture of ${a.id}:`, e.message); }
    });
}

// the head unit's icons (the tool's PNGs): uploaded as 'h:<id>'; kept: the page shown and the slots' own
const hpics = {};                 // id -> { len, img }
let icons = null;                 // the picker's page (the tool's reply), null = asked
let iconQ = '', typing = '', shiftOn = false, keyN = 0, iconsTotal = 0;
const NAME_MAX = 15;
function hpic(it) {
    if (!it.pic || (hpics[it.id] && hpics[it.id].len === it.pic.length)) return;
    try {
        const { makeImage } = runtime('kit/record.js'), p = runtime('kit/png.js').decode(Buffer.from(it.pic, 'base64'));
        dropHpic(it.id);
        hpics[it.id] = { len: it.pic.length, img: makeImage(p.w, p.h, p.data) };
        screens.setImage(`h:${it.id}`, hpics[it.id].img);
    } catch (e) { log(`icon ${it.id}:`, e.message); }
}
function dropHpic(id) {
    const v = hpics[id];
    if (!v) return;
    delete hpics[id];
    screens.setImage(`h:${id}`, null);
    try { if (gpu) gpu.dropImage(v.img); runtime('kit/record.js').dropImage(v.img); } catch (e) { /* gone already */ }
}
const slotIconIds = () => ((tool && tool.slots) || []).map((s) => s.hmiIcon).filter(Boolean);
function slotIcons() {                            // the slots' picked icons: asked for once each
    const want = slotIconIds().filter((id) => !hpics[id]);
    if (want.length) send({ op: 'icons', ids: want });
}
function iconReply(r) {
    if (!screens) return;
    (r.items || []).forEach(hpic);
    if (r.ids) { render(); return; }
    icons = r;
    if (!r.q) iconsTotal = r.total;
    const keep = new Set(slotIconIds().concat(r.items.map((x) => x.id)));
    Object.keys(hpics).forEach((id) => { if (!keep.has(id)) dropHpic(id); });
}
const askIcons = (page) => { icons = null; send({ op: 'icons', q: iconQ, page }); render(); };

/* the cluster's bars (the tool's shiftlights.js shader, on the CPU) with 5 of 8 lit: the shift page's picture of them,
 * the band they sit in (702 x 68 of its 702 x 213) */
function barsPicture() {
    const W = 702, H = 68, d = Buffer.alloc(W * H * 4);
    for (let y = 0; y < H; y++) {
        for (let x = 0; x < W; x++) {
            const px = x + 0.5, py = y + 64.5, xx = px < W / 2 ? px : W - px;
            const xs = xx - 20 - (132 - py) * 0.35, i = Math.floor(xs / 38);
            if (xs < 0 || i > 7 || xs % 38 > 30) continue;
            const c = i >= 5 ? [140, 145, 155, 56] : i < 3 ? [255, 184, 0, 255] : [255, 107, 0, 255];
            d.set(c, (y * W + x) * 4);
        }
    }
    return runtime('kit/record.js').makeImage(W, H, d);
}

// M Mode is always there (its first row says whether this is an M car: auto / yes / no); 2026-11-04 a client's M2 never
// saw it while it showed only once the tool had seen an M setup
const PAGES = () => ['shortcuts', 'climate', 'shift', 'mmode'];
// the bar's buttons: row name -> the tool's key; tabs AUTO / ON / OFF
const SHOW_ROWS = { showWheel: 'driver.wheel', showDrHeat: 'driver.heat', showDrCool: 'driver.cool', showPsHeat: 'passenger.heat', showPsCool: 'passenger.cool' };
const SHOW = ['auto', 'on', 'off'], MCAR = ['auto', 'yes', 'no'];
const found = (car, key) => {                     // what the car reports for a button key
    if (!car || !car.backend) return null;
    if (key === 'driver.wheel') return !!car.wheel;
    const [seat, kind] = key.split('.');
    return !!car.seats[seat][kind];
};
// each screen's frame (teleShell, tabs Shortcuts | Climate | Shift lights | M Mode; the picker under Shortcuts)
const MENUS = { shortcuts: 'shortcutsMenu', pick: 'pickMenu', icons: 'iconsMenu', iconSearch: 'iconSearchMenu', climate: 'climateMenu', shift: 'shiftMenu', mmode: 'mmodeMenu' };
const tabOf = (p) => (SUB.indexOf(p) >= 0 ? 'shortcuts' : p);
const CR_STATE = { connected: 'Connected', connecting: 'Starting', 'not running': 'Not running', missing: 'Not installed' };
// the M Mode page's rows A B C: SP21 cars tell M1 from M2, SP18 cars only "an M setup on"
const ROWS = () => (tool && tool.car.setups === 2
    ? [['m1', 'M1 on', 'The M Mode while M1 is active'], ['m2', 'M2 on', 'The M Mode while M2 is active'], ['off', 'M1 / M2 off', 'Back to this one']]
    : [['m1', 'M1 / M2 on', 'The M Mode while an M setup is active'], ['off', 'M1 / M2 off', 'Back to this one']]);
const BACKEND = { legacy: 'Climate (G series)', master: 'Climate master', demo: 'Demo seats' };
const SIDES = ['left', 'right'];                  // where the steering wheel is (tool 0.4.0: the bar's seat buttons follow)
const slotSub = (i) => `Slot ${i + 1} · ${i < 2 ? 'left' : 'right'}`;
// the tool names BMW screens by the HMI's icons; the screens draw vector icons only (renderer kit/vicons.js)
const VICON = { Playlist: 'play', Navigation: 'route', Smartphone: 'phone', Menu: 'grid', MainMenu: 'display', Fan: 'fan' };
const vicon = (hmi) => VICON[hmi] || 'display';

function render() {
    if (!screens) return;
    const t = tool, pages = PAGES();
    Object.keys(MENUS).forEach((p) => screens.set(MENUS[p], { sel: Math.max(0, pages.indexOf(tabOf(p))) }));
    // shortcuts
    // the tool not running, or a shortcut whose BMW screen did not open on this car: a chip in the frame, what to do in
    // the page line (the tool learns the screen from a hold)
    const nt = t && t.notice;
    screens.set('shortcutsMenu', !t ? { chips: [['Overlays tool not running', 'crit']], sub: 'Install it from the Store, then restart the head unit' }
        : nt ? { chips: [[`${nt.title} did not open`, 'warn']], sub: `Open it yourself, then hold shortcut ${nt.slot + 1} in the bar for 1 s` }
            : { chips: [], sub: 'In the climate bar · tap one to change it' });
    for (let i = 0; i < 4; i++) {
        // the picture: the head unit's icon picked for it, else an app's own, else the vector icon
        const d = t && t.slots[i], hk = d && d.hmiIcon && hpics[d.hmiIcon] ? `h:${d.hmiIcon}` : null;
        const pk = hk || (d && d.kind === 'app' && pics[d.app] ? `p:${d.app}` : null);
        screens.set(`slot${i}`, { title: d ? d.title : '--', sub: d && d.missing ? 'App not installed' : slotSub(i),
            icon: pk ? '' : d && d.kind === 'bmw' ? vicon(d.icon) : 'display', selected: i === sel });
        screens.set(`slotPic${i}`, { src: pk ? `key:${pk}` : '', hidden: !pk });
    }
    const cur = t && t.slots[sel], curIcon = cur && cur.hmiIcon;
    screens.set('showShortcuts', { on: !t || t.settings.shortcuts })
        .set('slotNow', { label: `Slot ${sel + 1}`, sub: cur ? `${cur.title} · ${cur.kind === 'app' ? 'App' : 'BMW screen'}` : '--' })
        .set('slotIcon', { sub: curIcon ? `${cur.iconName} · from the head unit` : 'Its own' })
        .set('slotIconPic', { src: curIcon && hpics[curIcon] ? `key:h:${curIcon}` : '', hidden: !(curIcon && hpics[curIcon]) })
        .set('pickMenu', { title: `Slot ${sel + 1}` });
    // icons: the page from the tool, the slot's icon marked
    const its = icons ? icons.items : [];
    screens.set('iconsMenu', { title: `Slot ${sel + 1} · icon` })
        .set('iconSearchMenu', { title: `Slot ${sel + 1} · search` })
        .set('iconField', { text: iconQ, hint: iconsTotal ? `Search ${iconsTotal} icons from this car` : 'Search the icons of this car' })
        .set('iconDefault', { disabled: !curIcon })
        .set('iconPage', { text: !icons ? 'Reading...' : icons.q ? `${icons.total} found · ${icons.page + 1} / ${icons.pages}`
            : icons.suggested ? `Suggested · 1 / ${icons.pages}` : `${icons.page + 1} / ${icons.pages}` })
        .set('iconPrev', { disabled: !icons || icons.page <= 0 })
        .set('iconNext', { disabled: !icons || icons.page >= icons.pages - 1 })
        .set('iconsEmpty', { hidden: !icons || its.length > 0, line: `Nothing on this car matches "${iconQ}". Try a shorter part of the name.` })
        .set('searchField', { text: typing, focus: true })
        .set('searchKeys', { shift: shiftOn });
    for (let i = 0; i < 24; i++) {
        const it = its[i], has = !!(it && hpics[it.id]);
        const nm = it ? (it.name.length > NAME_MAX ? `${it.name.slice(0, NAME_MAX - 1)}…` : it.name) : '';
        screens.set(`ic${i}`, { hidden: !it }).set(`icSel${i}`, { hidden: !it || it.id !== curIcon })
            .set(`icPic${i}`, { src: has ? `key:h:${it.id}` : '', hidden: !has }).set(`icName${i}`, { text: nm, hidden: !it });
    }
    // pick
    const bmw = (targets && targets.bmw) || [], apps = ((targets && targets.apps) || []).slice(0, 12);
    for (let i = 0; i < 6; i++) {
        const b = bmw[i];
        screens.set(`bmw${i}`, b ? { title: b.title, icon: vicon(b.icon), hidden: false, selected: !!cur && cur.kind === 'bmw' && cur.title === b.title } : { hidden: true });
    }
    screens.set('appsTitle', { text: targets ? (apps.length ? 'APPS ON THIS CAR' : 'APPS ON THIS CAR  ·  NONE WITH A TILE') : 'APPS ON THIS CAR  ·  READING...' });
    for (let i = 0; i < 12; i++) {
        const a = apps[i];
        // its own picture once uploaded (pictures(): 'p:<id>'), its first letter until then
        screens.set(`app${i}`, a ? { title: a.title, pic: `key:p:${a.id}`, letter: String(a.title || '?').charAt(0).toUpperCase(), hidden: false,
            selected: !!cur && cur.app === a.id } : { hidden: true });
    }
    // climate
    const car = t ? t.car : null;
    screens.set('ambientRow', { on: !t || t.settings.ambient !== false })
        .set('ambHeatRow', { hidden: !!t && t.settings.ambient === false, value: (t && t.settings.ambientHeat) || 3 })
        .set('ambCoolRow', { hidden: !!t && t.settings.ambient === false, value: (t && t.settings.ambientCool) || 9 })
        .set('orderRow', { text: t && t.settings.order === 'down' ? '3 → 2 → 1 → off' : '1 → 2 → 3 → off' })
        .set('sideRowTabs', { sel: t && t.settings.side === 'right' ? 1 : 0 })
        .set('sideRow', { sub: t && t.settings.side === 'right' ? 'The driver\'s buttons on the right, the wheel at the far right' : 'Right: the driver\'s buttons on the right' })
        // the climate control found (none: the bar's AUTO buttons stay hidden, the tool shows one on AUTO only when the car has it)
        .set('climateMenu', { sub: !car ? 'Seat and steering wheel controls in the climate bar'
            : BACKEND[car.backend] ? `Seat and steering wheel controls in the climate bar · ${BACKEND[car.backend]} found`
                : 'Climate control not found yet · set a button ON to show it' });
    Object.keys(SHOW_ROWS).forEach((name) => {
        const key = SHOW_ROWS[name], f = found(car, key), v = (t && t.settings.show && t.settings.show[key]) || 'auto';
        // ON / OFF by hand: what the car reports matters less, its line fainter
        screens.set(name, { sub: f === null ? 'Auto: the car has not said yet' : `Auto: ${f ? 'found' : 'not found'} on this car`,
            subColor: v === 'auto' ? '' : 'faint' });
        screens.set(`${name}Tabs`, { sel: Math.max(0, SHOW.indexOf(v)) });
    });
    // shift lights
    const sh = t && t.settings.shift, ss = t && t.shift;
    if (sh) {
        screens.set('shiftRow', { on: sh.on }).set('autoRow', { on: sh.auto })
            .set('autoNow', { hidden: !sh.auto, text: ss ? `${ss.th.start} → ${ss.th.flash} rpm` : '--',
                sub: ss && ss.limit ? 'Start, then all flash at' : 'Start, then all flash at (no limit from the engine yet: the set values)' })
            .set('startRow', { hidden: sh.auto, value: sh.start }).set('flashRow', { hidden: sh.auto, value: sh.flash })
            .set('hudRow', { on: sh.hud, hidden: !sh.auto || t.car.mcar }).set('hudRow2', { on: sh.hud, hidden: sh.auto || t.car.mcar });
    }
    // the cluster renderer: green when it draws them, red when it is missing / not running / refuses (missing: a chip in
    // the frame and where to get it, the preview marked not shown)
    const refused = !!ss && !!ss.layer && /refused|error/.test(ss.layer), missing = !!ss && ss.renderer === 'missing';
    screens.set('srcRow', { text: ss && ss.own ? 'Not shown: M car' : ss && ss.dme ? 'The DME (M car)' : 'Engine speed' })
        .set('limitRow', { text: ss && ss.limit ? `${ss.limit} rpm` : 'Not reported' })
        .set('crRow', { text: ss ? (refused ? `Refused: ${ss.layer.replace(/^refused: /, '')}`.slice(0, 40) : CR_STATE[ss.renderer] || ss.renderer) : '--',
            textColor: !ss || ss.renderer === 'connecting' ? '' : ss.renderer === 'connected' && !refused ? 'ok' : 'crit',
            sub: missing ? 'Install robertnisipeanu/idrive-apps 0.3.6 or newer' : 'robertnisipeanu/idrive-apps, 0.3.6 or newer', subColor: missing ? 'warn' : '' })
        .set('noPreview', { hidden: !missing })
        .set('shiftMenu', { chips: missing ? [['Cluster renderer missing', 'crit']] : [] });
    // M Mode
    const rows = ROWS(), mm = t ? t.settings.mmode : null, isM = !!(t && t.car.mcar);
    screens.set('mcarRow', { sub: !t ? '--' : t.car.mfound ? 'Auto: found on this car' : 'Auto: not seen yet',
        subColor: mm && mm.car && mm.car !== 'auto' ? 'faint' : '' })     // YES / NO by hand: fainter, as Climate's rows
        .set('mcarTabs', { sel: Math.max(0, MCAR.indexOf((mm && mm.car) || 'auto')) })
        .set('linkRow', { on: !mm || mm.on, hidden: !isM }).set('bootRow', { on: !!(mm && mm.boot), hidden: !isM })
        .set('mmNote', { hidden: !isM }).set('mmHint', { hidden: isM });
    ['A', 'B', 'C'].forEach((k, i) => {
        const r = isM && rows[i];
        screens.set(`row${k}`, r ? { label: r[1], sub: r[2], hidden: false } : { hidden: true });
        screens.set(`tabs${k}`, r ? { sel: Math.max(0, MODES.indexOf(mm ? mm[r[0]] : 'sport')), hidden: false } : { hidden: true });
    });
}

// ---- what the user does ---------------------------------------------------------------------------------
function pick(target) {
    send({ op: 'slot', i: sel, target });
    closeScreen('pick');
}
function pickIcon(id) {                          // id null: the slot's own picture again
    send({ op: 'icon', i: sel, icon: id });
    closeScreen('icons');
}
/* a key of the search keyboard: typed into the field; Show = the results on the icons page */
function key(k) {
    if (k === 'Shift') return;                    // (the keyboard keeps its shift: read from its opts)
    if (k === 'Delete') typing = typing.slice(0, -1);
    else if (k === 'Show') { iconQ = typing.trim(); closeScreen('iconSearch'); askIcons(0); return; }
    else if (typing.length < 30) {
        typing += k === 'Space' ? ' ' : k;
        if (shiftOn && /^[A-Z]$/.test(k)) shiftOn = false;   // one capital, like a phone
    }
    render();
}
const EVENTS = {
    change: () => showScreen('pick'),                // (its 'show' asks the tool for what a slot can open)
    icon: () => { iconQ = ''; askIcons(0); showScreen('icons'); },
    search: () => { typing = iconQ; showScreen('iconSearch'); },
    default: () => pickIcon(null),
    prev: () => icons && icons.page > 0 && askIcons(icons.page - 1),
    next: () => icons && icons.page < icons.pages - 1 && askIcons(icons.page + 1),
    reset: () => send({ op: 'reset' }),
    order: () => tool && setting({ order: tool.settings.order === 'down' ? 'up' : 'down' }),
};
function onEvent(name) {
    let m;
    if ((m = /^slot(\d)$/.exec(name))) { sel = +m[1]; render(); return; }
    if ((m = /^bmw(\d)$/.exec(name))) { const b = targets && targets.bmw[+m[1]]; if (b) pick({ state: b.state, applet: b.applet }); return; }
    if ((m = /^app(\d+)$/.exec(name))) { const a = targets && targets.apps[+m[1]]; if (a) pick({ app: a.id, state: a.state, offset: a.offset }); return; }
    if ((m = /^ic(\d+)$/.exec(name))) { const it = icons && icons.items[+m[1]]; if (it) pickIcon(it.id); return; }
    if (EVENTS[name]) EVENTS[name]();
}
const TOGGLES = { showShortcuts: 'shortcuts', ambientRow: 'ambient' };
function onChange(name, o) {
    if (TOGGLES[name]) return setting({ [TOGGLES[name]]: !!o.on });
    if (name === 'searchKeys' && o.key) {             // once per key press (n counts them)
        shiftOn = !!o.shift;
        if (o.key.n !== keyN) { keyN = o.key.n; key(o.key.text); }
        return null;
    }
    const sr = /^(show\w+)Tabs$/.exec(name);
    if (sr && SHOW_ROWS[sr[1]] && SHOW[o.sel]) return setting({ show: { [SHOW_ROWS[sr[1]]]: SHOW[o.sel] } });
    if (name === 'mcarTabs' && MCAR[o.sel]) return setting({ mmode: { car: MCAR[o.sel] } });
    if (name === 'sideRowTabs' && SIDES[o.sel]) return setting({ side: SIDES[o.sel] });
    if (name === 'linkRow') return setting({ mmode: { on: !!o.on } });
    if (name === 'bootRow') return setting({ mmode: { boot: !!o.on } });
    if (name === 'shiftRow') return setting({ shift: { on: !!o.on } });
    if (name === 'autoRow') return setting({ shift: { auto: !!o.on } });
    if (name === 'hudRow' || name === 'hudRow2') return setting({ shift: { hud: !!o.on } });
    if (name === 'ambHeatRow' || name === 'ambCoolRow') return setting({ [name === 'ambHeatRow' ? 'ambientHeat' : 'ambientCool']: Math.round(o.value) });
    if (name === 'startRow' || name === 'flashRow') return setting({ shift: { [name === 'startRow' ? 'start' : 'flash']: Math.round(o.value / 100) * 100 } });
    const t = /^tabs([ABC])$/.exec(name), r = t && ROWS()['ABC'.indexOf(t[1])];
    if (r) return setting({ mmode: { [r[0]]: MODES[o.sel] } });
    const page = Object.keys(MENUS).find((p) => MENUS[p] === name);
    if (page) {                                       // a tab (o is the shell's opts: read before the set)
        const to = PAGES()[o.sel];
        screens.set(name, { sel: Math.max(0, PAGES().indexOf(tabOf(page))) });
        goTo(to);
    }
    return null;
}
// shortcuts is the app's first screen, the other pages open over it (BACK returns to it); the search sits over icons
function goTo(page) {
    const cur = screens.st && screens.st.name;
    if (!page || page === cur) return;
    if (cur === 'iconSearch') closeScreen('iconSearch').then(() => closeScreen('icons'));
    else if (cur && cur !== 'shortcuts') closeScreen(cur);
    if (page !== 'shortcuts') showScreen(page);
}

// ---- RHMI: the host states (the shared OnlineApp host hands over the RHMI application) -------------------
let app = null;
const comp = (n) => app.getByName(n);
function showScreen(name) {
    return comp(name).updateResources().then(() => app.openState(name))
        .then(() => log(`opened ${name}`))
        .catch((e) => log(`open ${name} failed:`, e));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed:`, e));

function startScreens(rhmiApp) {
    app = rhmiApp;
    const design = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: (m) => log(m), warn: (m) => log(m), error: (m) => log(m) };
    gpu = new RenderClient('iteriodev_overlays', rlog);
    screens = new ScreenApp(gpu, design, { view: 'id8', log: rlog });
    try { screens.setImage('shiftPreview', barsPicture()); } catch (e) { log('shift preview:', e.message); }
    const hosts = {};
    STATES.forEach((s) => { hosts[s] = comp(s); });
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('event', (n) => { try { onEvent(n); } catch (e) { log(`${n} failed:`, e); } });
    screens.on('change', (n, o) => { try { onChange(n, o); } catch (e) { log(`${n} failed:`, e); } });
    screens.on('show', (name) => { if (name === 'pick') send({ op: 'targets' }); render(); });
    // the user left for the HMI (touched it): leave the host states too, or the HMI would show its empty page
    screens.on('closed', (why) => { if (why !== 'hmi') STATES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
    connect();
    render();
}

// ---- lifecycle: the shared OnlineApp host (start, tile, shutdown) -----------------------------------------
log('start', process.getuid());
createHost({
    states: STATES,
    log,
    onReady: (rhmiApp) => { startScreens(rhmiApp); log('screens ready'); },
});

'use strict';
/*
 * Tailscale's LocalAPI over the daemon's unix socket (Node 8, http only): what `tailscale status / up / logout` use.
 * The tool iteriodev-tailscale runs tailscaled with --socket=/run/iteriodev-tailscale/tailscaled.sock (0666); it is
 * built without per-user LocalAPI checks, so this app's uid has full access. The daemon refuses any Host but its
 * own name, and any Referer / Origin.
 */
const http = require('http');

const SOCKET = '/run/iteriodev-tailscale/tailscaled.sock';
const HOST = 'local-tailscaled.sock';

/** method, path ('status'), body -> parsed JSON (or the text), rejects on a socket error or a non-2xx reply */
function call(method, path, body, opts) {
    const o = opts || {};
    return new Promise((resolve, reject) => {
        const data = body === undefined ? null : Buffer.from(JSON.stringify(body));
        const req = http.request({ socketPath: o.socket || SOCKET, method, path: `/localapi/v0/${path}`,
            headers: Object.assign({ Host: HOST }, data ? { 'Content-Type': 'application/json', 'Content-Length': data.length } : {}) }, (res) => {
            const chunks = [];
            res.on('data', (c) => chunks.push(c));
            res.on('end', () => {
                const text = Buffer.concat(chunks).toString('utf8');
                if (res.statusCode < 200 || res.statusCode > 299) return reject(new Error(`${path}: ${res.statusCode} ${text.trim().slice(0, 120)}`));
                try { resolve(text ? JSON.parse(text) : null); } catch (e) { resolve(text); }
                return null;
            });
        });
        req.setTimeout(o.timeoutMs || 5000, () => req.abort());
        req.on('error', reject);
        req.end(data || undefined);
    });
}

module.exports = {
    SOCKET,
    status: (o) => call('GET', 'status', undefined, o),
    /** want it connected (what `up` sets), then a fresh login link: status().AuthURL */
    login: (o) => call('PATCH', 'prefs', { WantRunningSet: true, WantRunning: true }, o)
        .then(() => call('POST', 'login-interactive', undefined, o)),
    connect: (o) => call('PATCH', 'prefs', { WantRunningSet: true, WantRunning: true }, o),
    logout: (o) => call('POST', 'logout', undefined, o),
    prefs: (o) => call('GET', 'prefs', undefined, o),
    /** the name on the tailnet (`tailscale set --hostname`); '' = the head unit's own hostname (mgu) */
    setHostname: (name, o) => call('PATCH', 'prefs', { HostnameSet: true, Hostname: name }, o),
};

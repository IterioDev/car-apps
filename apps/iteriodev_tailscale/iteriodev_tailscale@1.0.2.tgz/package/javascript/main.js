'use strict';
/*
 * oap-tailscale ("Tailscale"): the head unit's Tailscale state and login, without a computer. The tool
 * iteriodev-tailscale runs tailscaled (userspace networking, through mgu-uplink); this app talks to it over its
 * LocalAPI socket (./tsapi.js): status every 2 s while the screen is up, a login link when it needs one (shown as a
 * QR code, ./qr.js, and as text), Log out (two taps), Connect when it was switched off, Rename: the name on the
 * tailnet (Tailscale's Hostname pref, '' = the head unit's own hostname mgu). Nothing here touches the car.
 *
 * Screen: drawn by the GPU renderer (any installed one: mgu-render / mgu-renderd), designed in the HMI UI builder:
 * apps/hmi-ui-builder/projects/tailscale.json (sketch A), exported into this folder (rhmiData/ = one empty RHMI host
 * state, renderer/ = screens.json + the builder's runtime). One screen holds both panels: the QR + steps while
 * logging in, how to reach the head unit when connected; the app hides the other. Bootstrap as in oap-dtcscan.
 */
const fs = require('fs');
const path = require('path');
const util = require('util');
const RhmiManager                      = require('oap-sdk/src/rhmi/RhmiManager');
const RhmiResourcesLocator             = require('oap-sdk/src/rhmi/RhmiResourcesLocator');
const MultiLanguageStringBundleFactory = require('oap-sdk/src/rhmi/MultiLanguageStringBundleFactory');
const RhmiApplicationFactory           = require('oap-sdk/src/rhmi/RhmiApplicationFactory');
const ResourceManager                  = require('oap-sdk/src/rhmi/ResourceManager');
const CurrentVehicleUnits              = require('oap-sdk/src/core/CurrentVehicleUnits');
const someipBuilders                   = require('oap-sdk/src/someip/someipBuilders');
const OnlineAppBackground              = require('oap-sdk/src/core/OnlineAppBackground');
const tsapi                            = require('./tsapi');
const { qrRgba }                       = require('./qr');

const APPLET_ID       = 20115;  // = rhmiData/application.json "appletId"
const ENTRY_UUID      = 'f4f7fd15-002b-47d7-9f83-ee195e449616';   // = entryPoints[0].uuid (project entryUuid)
const APPLETID_OFFSET = 3000;
const LOG = '[iteriodev_tailscale]';
const STATES = ['home', 'rename'];   // screens = their RHMI host states
const POLL_MS = 2000;
const CONFIRM_MS = 5000;          // the second tap on Log out must come within this
const MSG_MS = 8000;              // an action's message replaces the state's small line this long
const QR_PX = 540;                // = the design's qrImage box

// runner.js gives the bundle its own folder as __dirname (the package root, next to renderer/)
const SOURCE = typeof __dirname === 'string' ? __dirname : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const DATA = `/var/opt/public/oap/oap_${process.getuid()}/data`;
const LOG_FILE = `${DATA}/tailscale.log`;
const UPLINK = '/run/mgu-uplink/status.json';
const GREEN = '#3ecf6e', AMBER = '#ffb020', RED = '#ff5a4f', GREY = '#8a94a6', BLUE = '#4fa3e0';

const errText = (e) => String(e && e.message || e).slice(0, 120);
function log() {
    const line = [new Date().toISOString()].concat([].slice.call(arguments)
        .map((x) => (typeof x === 'string' ? x : util.inspect(x, { depth: 4 }).slice(0, 2000)))).join(' ');
    console.error(LOG, line);
    try { if (fs.statSync(LOG_FILE).size > 256 * 1024) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* no file yet */ }
    try { fs.appendFileSync(LOG_FILE, `${line}\n`); } catch (e) { /* no data folder */ }
}

// ---- state ------------------------------------------------------------------------------------------
let ts = null;                    // tailscaled's status, null = no answer
let tsWhy = 'not read yet';       // why ts is null
let uplink = null;                // mgu-uplink's status.json, null = not there
let busy = false;
let msg = '';
let msgAt = 0;
let armedAt = 0;
let loginAsked = false;           // one automatic login link per screen opening
let qrFor = null;                 // the link the QR picture shows
let edit = '';                    // the name being typed on the rename screen

function say(text) { msg = text; msgAt = Date.now(); render(); }

// a DNS label, what Tailscale accepts as a machine name (util/dnsname ValidLabel)
const MAX_NAME = 63;
const validName = (n) => /^[a-z0-9]([a-z0-9-]*[a-z0-9])?$/.test(n) && n.length <= MAX_NAME;
/** the name the tailnet gives the head unit: its MagicDNS name, else the name it asked for */
const tailnetName = () => { const s = (ts && ts.Self) || {}; return (s.DNSName || '').split('.')[0] || s.HostName || ''; };

/** what to show: connected | login (link there) | needslogin | approval | stopped | starting | down */
function kind() {
    if (!ts) return 'down';
    const st = ts.BackendState;
    if (st === 'Running') return 'connected';
    if (st === 'NeedsLogin') return ts.AuthURL ? 'login' : 'needslogin';
    if (st === 'NeedsMachineAuth') return 'approval';
    if (st === 'Stopped') return 'stopped';
    return 'starting';
}
const online = () => !!(uplink && uplink.state === 'online');

function readAll() {
    try { uplink = JSON.parse(fs.readFileSync(UPLINK, 'utf8')); } catch (e) { uplink = null; }
    return tsapi.status().then((s) => { ts = s; tsWhy = ''; }, (e) => {
        ts = null;
        tsWhy = /ENOENT|ECONNREFUSED/.test(e.code || e.message) ? 'the Tailscale tool is not running' : errText(e);
    }).then(() => {
        // a fresh screen that needs a login gets its link at once (the button asks for a new one)
        if (kind() === 'needslogin' && !loginAsked && !busy && screens && screens.st) { loginAsked = true; act('Getting a login link...', tsapi.login); }
        render();
    });
}

function act(label, fn) {
    if (busy) return Promise.resolve();
    busy = true;
    say(label);
    return Promise.resolve().then(fn).then(() => log(label, 'ok'), (e) => { log(label, 'failed:', e); say(`Failed: ${errText(e)}`); })
        .then(() => { busy = false; return readAll(); });
}

const armed = () => Date.now() - armedAt <= CONFIRM_MS;
const EVENTS = {
    action: () => {
        const k = kind();
        if (k === 'connected') {
            if (!armed()) { armedAt = Date.now(); say('Tap Log out again: the head unit leaves your tailnet.'); return null; }
            armedAt = 0;
            loginAsked = true;            // logged out on purpose: a new link only when asked for
            return act('Logging out...', tsapi.logout);
        }
        if (k === 'stopped') return act('Connecting...', tsapi.connect);
        if (k === 'login' || k === 'needslogin') return act('Getting a new login link...', tsapi.login);
        return readAll();
    },
    // the field starts with the name asked for (logged out, status only knows the OS hostname), else the tailnet's
    rename: () => (ts ? tsapi.prefs().then((p) => p && p.Hostname, () => '')
        .then((n) => { edit = n || tailnetName(); return showScreen('rename'); }) : null),
    save: () => saveName(edit),
    default: () => saveName(''),
    cancel: () => closeScreen('rename'),
};

// the word keyboard on the rename screen: letters as lower case, digits, '-'; other keys do nothing
function typeKey(k) {
    if (k === 'Save') return saveName(edit);
    if (k === 'Delete') edit = edit.slice(0, -1);
    else if (/^[a-z0-9-]$/i.test(k) && edit.length < MAX_NAME) edit += k.toLowerCase();
    render();
    return null;
}

function saveName(name) {
    if (busy || (name && !validName(name))) return null;      // Save is greyed out; the hint says why
    closeScreen('rename');
    return act(name ? `Renaming to ${name}...` : 'Back to the default name (mgu)...', () => tsapi.setHostname(name))
        .then(() => { if (!/^Failed/.test(msg)) say(`Name set to ${name || 'mgu'}. The tailnet shows it in a few seconds, unless it was renamed in the admin console.`); });
}
const onEvent = (name) => { if (EVENTS[name]) Promise.resolve().then(EVENTS[name]).catch((e) => log(`${name} failed:`, e)); };

// ---- screens (the renderer) ----------------------------------------------------------------------------
// renderer/ is the builder's export: screens.json + its runtime. Loaded with a computed path: build_bundle.py
// leaves it to the platform require (plain files beside bundle.js, Node 8).
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
let screens = null;
let qrImg = null;

const LOGIN_PARTS = ['qrImage', 'step1', 'step2', 'step3', 'linkHead', 'linkText'];
const CONNECTED_PARTS = ['reach1', 'reach2', 'reach3'];
const STATE = {
    connected: ['Connected', GREEN, 'Reachable from your tailnet while the car is on and online.'],
    login: ['Log in needed', AMBER, 'Scan the code with your phone and approve this head unit in your tailnet.'],
    needslogin: ['Log in needed', AMBER, 'Getting a login link from Tailscale...'],
    approval: ['Waiting for approval', AMBER, 'An admin of your tailnet has to approve this device in the admin console.'],
    stopped: ['Disconnected', AMBER, 'Tailscale is switched off. Tap Connect to join your tailnet again.'],
    starting: ['Connecting...', BLUE, 'Tailscale is starting.'],
    down: ['Not running', RED, ''],
};

function showQr(url) {
    if (url === qrFor) return;
    const { makeImage, dropImage } = runtime('kit/record.js');
    const old = qrImg;
    qrImg = null;
    try { const q = qrRgba(url, QR_PX); qrImg = makeImage(q.w, q.h, q.data); } catch (e) { log('qr failed:', e); }
    screens.setImage('qr', qrImg);
    if (old) dropImage(old);
    qrFor = url;
}

function render() {
    if (!screens) return;
    const k = kind(), [title, color, sub] = STATE[k];
    const self = (ts && ts.Self) || {};
    const name = tailnetName() || '--';
    const ip = (self.TailscaleIPs || [])[0] || '--';
    const user = ts && ts.User && self.UserID !== undefined && ts.User[self.UserID] ? ts.User[self.UserID].LoginName : '--';
    const down = k === 'down' ? `The Tailscale tool is not running (${tsWhy}). Install it from the Store, then restart the head unit.` : '';
    const offline = !online() && (k === 'needslogin' || k === 'starting') ? ' Needs the internet: connect a phone or Wi-Fi in the Store.' : '';
    const up = uplink ? uplink.state : null;
    screens.set('stateText', { text: title, color })
        .set('stateSub', { text: Date.now() - msgAt <= MSG_MS ? msg : (sub || down) + offline })
        .set('infoTable', { rows: [[name, k === 'connected' ? ip : '--', k === 'connected' ? user : '--']] .map((r) => r.join(',')).join('\n') })
        .set('checkChips', { items: [
            up === 'online' ? { text: `Internet: ${(uplink.device && uplink.device.name) || 'online'}`, color: GREEN, dot: true }
                : { text: up ? `Internet: ${up}` : 'No internet uplink', color: up ? AMBER : RED, dot: true },
            { text: ts && ts.Version ? `Tailscale ${String(ts.Version).split('-')[0]}` : 'Tailscale not running', color: GREY, dot: false },
        ] })
        .set('actionBtn', { disabled: busy,
            text: k === 'connected' ? (armed() ? 'Confirm log out' : 'Log out') : k === 'stopped' ? 'Connect'
                : k === 'login' || k === 'needslogin' ? 'New login link' : 'Refresh',
            vicon: k === 'connected' ? 'unlock' : k === 'stopped' ? 'play' : 'refresh',
            style: k === 'connected' && armed() ? 'primary' : 'outline', color: k === 'connected' && armed() ? AMBER : '' })
        .set('panel', { title: k === 'login' ? 'Scan to log in' : k === 'connected' ? 'Reach the head unit' : 'Tailscale' })
        .set('renameBtn', { hidden: k === 'down', disabled: busy });
    const ok = !edit || validName(edit);
    screens.set('nameField', { text: edit })
        .set('nameHint', { text: ok ? (edit ? 'a-z, 0-9 and -, up to 63' : 'Empty: the default name, mgu') : 'Can\'t start or end with -',
            color: ok ? 'dim' : AMBER })
        .set('saveBtn', { disabled: !ok || busy });
    LOGIN_PARTS.forEach((n) => screens.set(n, { hidden: k !== 'login' }));
    CONNECTED_PARTS.forEach((n) => screens.set(n, { hidden: k !== 'connected' }));
    if (k === 'login') {
        showQr(ts.AuthURL);
        screens.set('linkText', { text: String(ts.AuthURL).replace(/^https?:\/\//, '') });
    }
    if (k === 'connected') {
        screens.set('reach1', { text: `ssh root@${name}` }).set('reach2', { text: `or ssh root@${ip}` });
    }
}

// ---- RHMI: the host state -----------------------------------------------------------------------------
const rhmiManager          = new RhmiManager();
const resourceManager      = new ResourceManager(APPLET_ID);
const rhmiResourcesLocator = new RhmiResourcesLocator({ rhmiConfigKey: 'rhmiData' });
const multiLanguageStringBundleFactory = new MultiLanguageStringBundleFactory({ currentVehicleUnits: new CurrentVehicleUnits(), resourceManager, rhmiResourcesLocator });
const rhmiApplicationFactory = new RhmiApplicationFactory({ multiLanguageStringBundleFactory, resourceManager, rhmiManager, rhmiResourcesLocator });

let app = null;
const comp = (n) => app.getByName(n);
function showScreen(name, open) {
    return comp(name).updateResources().then(open || (() => app.openState(name)))
        .then(() => log(`opened ${name}`))
        .catch((e) => log(`open ${name} failed:`, e));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed:`, e));

function startScreens(rhmiApp) {
    app = rhmiApp;
    const design = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: (m) => log(m), warn: (m) => log(m), error: (m) => log(m) };
    const gpu = new RenderClient('iteriodev_tailscale', rlog);
    screens = new ScreenApp(gpu, design, { view: 'id8', log: rlog });
    const hosts = {};
    STATES.forEach((s) => { hosts[s] = comp(s); });
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('event', onEvent);
    screens.on('change', (name, o) => { if (name === 'keyboard' && o.key) typeKey(o.key.text); });
    screens.on('show', (name) => { if (name === 'home') loginAsked = false; render(); readAll(); });
    // the user left for the HMI (touched it): leave the host state too, or the HMI would show its empty page
    screens.on('closed', (why) => { if (why !== 'hmi') STATES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
    render();
}

// Tile tap: MainApp calls AppStatus.changeVisibility(visible, reason, entryPointUuid, ...).
// The SDK's background class ignores it, so open the entry screen ourselves.
function onChangeVisibility(args) {
    const a = args || {};
    log('tile:', a, app ? '' : '(screens not ready)');
    if (a.visible && app) showScreen('home', () => app.openEntryState(a.entryPointUuid || ENTRY_UUID));
    return Promise.resolve({});
}

// ---- lifecycle --------------------------------------------------------------------------------------
const onlineApp = OnlineAppBackground.create();
onlineApp.createAppStatusService = function () {
    const instanceName = `${process.getuid() - this.extendedConfig.get('someip', 'instanceIdOffset')}`;
    return someipBuilders.buildTypedService('de.bmw.infotainment.telematic.oap.AppStatus', instanceName, {
        changeVisibility: onChangeVisibility,
        configureStartWidgetApp: () => Promise.resolve({}),
        appStatus: { getValue: () => Promise.resolve(this.appStatus) },
        hmiStatus: { getValue: () => Promise.resolve(this.hmiStatus) },
        audioStatus: { getValue: () => Promise.resolve(this.audioStatus) },
    }).then((service) => service.init())
        .then((service) => { this.emit('appStatusProxyReady'); return service; });
};
onlineApp.on('terminated', () => onlineApp.shutdown().catch(() => {}).then(() => process.exit(0)));
onlineApp.on('appStatusProxyReady', () => onlineApp.registerActive());

const startRhmi = () => rhmiResourcesLocator.init()
    .then(() => Promise.all([rhmiManager.init(), resourceManager.init(), rhmiApplicationFactory.init()]))
    .then(() => rhmiApplicationFactory.create(process.getuid(), { appletIdOffset: APPLETID_OFFSET }))
    .then((rhmiApp) => rhmiApp.init().then(() => rhmiApp.setActive(true))
        .then(() => rhmiApp.mapEntryState(ENTRY_UUID, rhmiApp.getByName('home')))
        .then(() => startScreens(rhmiApp))
        .then(() => log('screens ready')));

log('start', process.getuid());
onlineApp.start()
    .then(() => Promise.all([onlineApp.initialized(), startRhmi()]))
    .then(() => { setInterval(() => (screens && screens.st && !busy ? readAll() : null), POLL_MS); })
    .catch((e) => log('startup failed:', e));

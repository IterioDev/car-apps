'use strict';
/*
 * oap-tailscale ("Tailscale"): the head unit's Tailscale state and login, without a computer. The tool
 * iteriodev-tailscale runs tailscaled (userspace networking, through mgu-uplink); this app talks to it over its
 * LocalAPI socket (./tsapi.js): status every 2 s while the screen is up, a login link when it needs one (shown as a
 * QR code, ./qr.js, and as text), Log out (two taps), Connect when it was switched off, Rename: the name on the
 * tailnet (Tailscale's Hostname pref, '' = the head unit's own hostname mgu). Nothing here touches the car.
 *
 * Screens: drawn by the GPU renderer (any installed one: mgu-render / mgu-renderd) in the car apps' Telemetry design,
 * laid out by scripts/oap-tools/make_tailscale_project.js (apps/hmi-ui-builder/projects/tailscale.json) and exported
 * into this folder (rhmiData/ = an empty RHMI host state per screen, renderer/ = screens.json + the builder's runtime).
 * home: the state on the left, a panel on the right (the QR + steps while logging in, how to reach the head unit when
 * connected, else what is happening); rename: a sub-page with Back. Start, tile and shutdown on iDrive 8: the shared
 * OnlineApp host (oap-shared/online-host.js).
 */
const fs = require('fs');
const path = require('path');
const util = require('util');
const tsapi                            = require('./tsapi.js');
const { qrRgba }                       = require('./qr.js');
const { createHost }                   = require('./online-host.js');

const LOG = '[iteriodev_tailscale]';
const STATES = ['home', 'rename'];   // screens = their RHMI host states
const POLL_MS = 2000;
const CONFIRM_MS = 5000;          // the second tap on Log out must come within this
const MSG_MS = 8000;              // an action's message replaces the state's small line this long
const QR_PX = 460;                // = the design's qrImage box

// the linked bundle is javascript/app.js: the package root (next to renderer/) is its parent folder, the app's data
// folder beside that (the Store's)
const SOURCE = typeof __dirname === 'string' ? path.join(__dirname, '..') : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const DATA = path.join(__dirname, '..', '..', 'data');
const LOG_FILE = `${DATA}/tailscale.log`;
const UPLINK = '/run/mgu-uplink/status.json';
const OK = '#5bd68a', ACCENT = '#ffb020', DIM = '#8b9099', CRIT = '#ff3b30';     // the Telemetry colours (renderer tele-widgets.js C)

const errText = (e) => String(e && e.message || e).slice(0, 120);
function log() {
    const line = [new Date().toISOString()].concat([].slice.call(arguments)
        .map((x) => (typeof x === 'string' ? x : util.inspect(x, { depth: 4 }).slice(0, 2000)))).join(' ');
    console.error(LOG, line);
    try { if (fs.statSync(LOG_FILE).size > 256 * 1024) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* no file yet */ }
    try { fs.appendFileSync(LOG_FILE, `${line}\n`); } catch (e) { /* no data folder */ }
}

// ---- state ------------------------------------------------------------------------------------------
let ts = null;                    // tailscaled's status, null = no answer
let tsWhy = 'not read yet';       // why ts is null
let uplink = null;                // mgu-uplink's status.json, null = not there
let busy = false;
let msg = '';
let msgAt = 0;
let armedAt = 0;
let loginAsked = false;           // one automatic login link per screen opening
let qrFor = null;                 // the link the QR picture shows
let edit = '';                    // the name being typed on the rename screen

function say(text) { msg = text; msgAt = Date.now(); render(); }

// a DNS label, what Tailscale accepts as a machine name (util/dnsname ValidLabel)
const MAX_NAME = 63;
const validName = (n) => /^[a-z0-9]([a-z0-9-]*[a-z0-9])?$/.test(n) && n.length <= MAX_NAME;
/** the name the tailnet gives the head unit: its MagicDNS name, else the name it asked for */
const tailnetName = () => { const s = (ts && ts.Self) || {}; return (s.DNSName || '').split('.')[0] || s.HostName || ''; };

/** what to show: connected | login (link there) | needslogin | approval | stopped | starting | down */
function kind() {
    if (!ts) return 'down';
    const st = ts.BackendState;
    if (st === 'Running') return 'connected';
    if (st === 'NeedsLogin') return ts.AuthURL ? 'login' : 'needslogin';
    if (st === 'NeedsMachineAuth') return 'approval';
    if (st === 'Stopped') return 'stopped';
    return 'starting';
}
const online = () => !!(uplink && uplink.state === 'online');

function readAll() {
    try { uplink = JSON.parse(fs.readFileSync(UPLINK, 'utf8')); } catch (e) { uplink = null; }
    return tsapi.status().then((s) => { ts = s; tsWhy = ''; }, (e) => {
        ts = null;
        tsWhy = /ENOENT|ECONNREFUSED/.test(e.code || e.message) ? 'the Tailscale tool is not running' : errText(e);
    }).then(() => {
        // a fresh screen that needs a login gets its link at once (the button asks for a new one)
        if (kind() === 'needslogin' && !loginAsked && !busy && screens && screens.st) { loginAsked = true; act('Getting a login link...', tsapi.login); }
        render();
    });
}

function act(label, fn) {
    if (busy) return Promise.resolve();
    busy = true;
    say(label);
    return Promise.resolve().then(fn).then(() => log(label, 'ok'), (e) => { log(label, 'failed:', e); say(`Failed: ${errText(e)}`); })
        .then(() => { busy = false; return readAll(); });
}

const armed = () => Date.now() - armedAt <= CONFIRM_MS;
const EVENTS = {
    action: () => {
        const k = kind();
        if (k === 'connected') {
            if (!armed()) { armedAt = Date.now(); say('Tap Log out again: the head unit leaves your tailnet.'); return null; }
            armedAt = 0;
            loginAsked = true;            // logged out on purpose: a new link only when asked for
            return act('Logging out...', tsapi.logout);
        }
        if (k === 'stopped') return act('Connecting...', tsapi.connect);
        if (k === 'login' || k === 'needslogin') return act('Getting a new login link...', tsapi.login);
        return readAll();
    },
    // the field starts with the name asked for (logged out, status only knows the OS hostname), else the tailnet's
    rename: () => (ts ? tsapi.prefs().then((p) => p && p.Hostname, () => '')
        .then((n) => { edit = n || tailnetName(); return showScreen('rename'); }) : null),
    save: () => saveName(edit),
    default: () => saveName(''),
    cancel: () => closeScreen('rename'),
};

// the word keyboard on the rename screen: letters as lower case, digits, '-'; other keys do nothing
function typeKey(k) {
    if (k === 'Save') return saveName(edit);
    if (k === 'Delete') edit = edit.slice(0, -1);
    else if (/^[a-z0-9-]$/i.test(k) && edit.length < MAX_NAME) edit += k.toLowerCase();
    render();
    return null;
}

function saveName(name) {
    if (busy || (name && !validName(name))) return null;      // Save is greyed out; the hint says why
    closeScreen('rename');
    return act(name ? `Renaming to ${name}...` : 'Back to the default name (mgu)...', () => tsapi.setHostname(name))
        .then(() => { if (!/^Failed/.test(msg)) say(`Name set to ${name || 'mgu'}. The tailnet shows it in a few seconds, unless it was renamed in the admin console.`); });
}
const onEvent = (name) => { if (EVENTS[name]) Promise.resolve().then(EVENTS[name]).catch((e) => log(`${name} failed:`, e)); };

// ---- screens (the renderer) ----------------------------------------------------------------------------
// renderer/ is the builder's export: screens.json + its runtime. Loaded with a computed path: the linked app.js
// leaves it to the platform require (plain files in the package, Node 8).
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
let screens = null;
let qrImg = null;

const LOGIN_PARTS = ['qrImage', 'num1', 'step1', 'num2', 'step2', 'num3', 'step3', 'linkHead', 'linkText'];
const CONNECTED_PARTS = ['reach1', 'reach2', 'reach3'];
const STATE = {
    connected: ['Connected', OK, 'Reachable from your tailnet while the car is on and online.'],
    login: ['Log in needed', ACCENT, 'Scan the code with your phone and approve this head unit in your tailnet.'],
    needslogin: ['Log in needed', ACCENT, 'Getting a login link from Tailscale...'],
    approval: ['Waiting for approval', ACCENT, 'An admin of your tailnet has to approve this device in the admin console.'],
    stopped: ['Disconnected', ACCENT, 'Tailscale is switched off. Tap Connect to join your tailnet again.'],
    starting: ['Starting', DIM, 'Tailscale is starting on the head unit. This takes a few seconds.'],
    down: ['Not running', CRIT, ''],
};
// the panel without a code to scan or a way in: [vector icon, heading, line, colour (tele token)]
const PANEL = {
    needslogin: ['clock', 'No login code yet', 'New login link gets one from Tailscale.'],
    approval: ['lock', 'Waiting for approval', 'Approve this head unit in the Tailscale admin console.'],
    stopped: ['pause', 'Switched off', 'Connect joins your tailnet again.'],
    starting: ['clock', 'Starting', 'The login code shows here.'],
    down: ['warning', 'Tool not running', 'Install Tailscale from the Store, then restart the head unit.', 'crit'],
};

function showQr(url) {
    if (url === qrFor) return;
    const { makeImage, dropImage } = runtime('kit/record.js');
    const old = qrImg;
    qrImg = null;
    try { const q = qrRgba(url, QR_PX); qrImg = makeImage(q.w, q.h, q.data); } catch (e) { log('qr failed:', e); }
    screens.setImage('qr', qrImg);
    if (old) dropImage(old);
    qrFor = url;
}

function render() {
    if (!screens) return;
    const k = kind(), [title, color, sub] = STATE[k], p = PANEL[k];
    const self = (ts && ts.Self) || {};
    const name = tailnetName() || '--';
    const ip = (self.TailscaleIPs || [])[0] || '--';
    const user = ts && ts.User && self.UserID !== undefined && ts.User[self.UserID] ? ts.User[self.UserID].LoginName : '--';
    const down = k === 'down' ? `The Tailscale tool is not running (${tsWhy}). Install it from the Store, then restart the head unit.` : '';
    const offline = !online() && (k === 'needslogin' || k === 'starting') ? ' Needs the internet: connect a phone or Wi-Fi in the Store.' : '';
    const up = uplink ? uplink.state : null;
    const login = k === 'login' || k === 'needslogin', wait = busy || k === 'starting';
    // the frame's chips from its right edge: Tailscale's version, then the internet uplink
    screens.set('homeFrame', { chips: [[ts && ts.Version ? `Tailscale ${String(ts.Version).split('-')[0]}` : 'Tailscale not running', 'dim'],
        up === 'online' ? [`Internet: ${(uplink.device && uplink.device.name) || 'online'}`, 'ok'] : [up ? `Internet: ${up}` : 'No internet uplink', up ? 'warn' : 'crit']] })
        .set('stateText', { text: title.toUpperCase(), color })
        .set('stateSub', { text: Date.now() - msgAt <= MSG_MS ? msg : (sub || down) + offline })
        .set('infoTable', { rows: [['Name', name], ['Address', k === 'connected' ? ip : '--'], ['Account', k === 'connected' ? user : '--']] })
        // starting: nothing to tap, the screen reads the state every 2 s; the second Log out tap is red
        .set('actionBtn', { disabled: wait,
            text: k === 'connected' ? (armed() ? 'Confirm log out' : 'Log out') : k === 'stopped' ? 'Connect' : login ? 'New login link'
                : k === 'starting' ? 'Starting…' : 'Refresh',
            icon: k === 'connected' ? '' : k === 'stopped' ? 'play' : 'refresh',
            kind: k === 'connected' ? (armed() ? 'danger' : 'outline') : login || k === 'stopped' ? 'primary' : 'outline' })
        .set('renameBtn', { hidden: k === 'down', disabled: wait })
        .set('panelTitle', { text: k === 'login' ? 'SCAN TO LOG IN' : 'REACH IT', hidden: k !== 'login' && k !== 'connected' })
        .set('panelEmpty', p ? { icon: p[0], head: p[1], line: p[2], color: p[3] || '', hidden: false } : { hidden: true });
    // rename: an invalid name greys Save out and a chip in the frame says why
    const ok = !edit || validName(edit);
    screens.set('nameField', { text: edit })
        .set('renameFrame', { sub: edit ? 'a-z, 0-9 and -, up to 63' : 'Empty: the default name, mgu',
            chips: ok ? [] : [['Can\'t start or end with -', 'warn']] })
        .set('saveBtn', { disabled: !ok || busy });
    LOGIN_PARTS.forEach((n) => screens.set(n, { hidden: k !== 'login' }));
    CONNECTED_PARTS.forEach((n) => screens.set(n, { hidden: k !== 'connected' }));
    if (k === 'login') {
        showQr(ts.AuthURL);
        screens.set('linkText', { text: String(ts.AuthURL).replace(/^https?:\/\//, '') });
    }
    if (k === 'connected') {
        screens.set('reach1', { text: `ssh root@${name}` }).set('reach2', { text: `or ssh root@${ip}` });
    }
}

// ---- RHMI: the host states (the shared OnlineApp host hands over the RHMI application) -------------------
let app = null;
const comp = (n) => app.getByName(n);
function showScreen(name) {
    return comp(name).updateResources().then(() => app.openState(name))
        .then(() => log(`opened ${name}`))
        .catch((e) => log(`open ${name} failed:`, e));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed:`, e));

function startScreens(rhmiApp) {
    app = rhmiApp;
    const design = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: (m) => log(m), warn: (m) => log(m), error: (m) => log(m) };
    const gpu = new RenderClient('iteriodev_tailscale', rlog);
    screens = new ScreenApp(gpu, design, { view: 'id8', log: rlog });
    const hosts = {};
    STATES.forEach((s) => { hosts[s] = comp(s); });
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('event', onEvent);
    screens.on('change', (name, o) => { if (name === 'keyboard' && o.key) typeKey(o.key.text); });
    screens.on('show', (name) => { if (name === 'home') loginAsked = false; render(); readAll(); });
    // the user left for the HMI (touched it): leave the host state too, or the HMI would show its empty page
    screens.on('closed', (why) => { if (why !== 'hmi') STATES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
    render();
    setInterval(() => (screens.st && !busy ? readAll() : null), POLL_MS);
}

// ---- lifecycle: the shared OnlineApp host (start, tile, shutdown; iDrive 7 + 8) -------------------------
log('start', process.getuid());
createHost({
    states: STATES,
    log,
    onReady: (rhmiApp) => { startScreens(rhmiApp); log('screens ready'); },
});

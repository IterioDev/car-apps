'use strict';
/*
 * A QR code as a renderer picture (Node 8, no npm): the matrix from ./qrcode.js (qrcode-generator 1.4.4, MIT,
 * (c) 2009 Kazuhiko Arase, vendored as is), drawn black on white with the 4-module quiet zone the standard asks for.
 * qrRgba(text, px) -> { w, h, data: RGBA Buffer } at most px wide (whole pixels per module, so edges stay sharp);
 * the app hands it to the renderer with record.js makeImage. qrMatrix for tests.
 */
const qrcode = require('./qrcode.js');

const QUIET = 4;

/** text -> array of rows of booleans (true = dark), error correction M */
function qrMatrix(text) {
    const qr = qrcode(0, 'M');          // 0: the smallest version that holds the text
    qr.addData(String(text));
    qr.make();
    const n = qr.getModuleCount(), rows = [];
    for (let r = 0; r < n; r++) {
        const row = [];
        for (let c = 0; c < n; c++) row.push(qr.isDark(r, c));
        rows.push(row);
    }
    return rows;
}

function qrRgba(text, px) {
    const m = qrMatrix(text), n = m.length + 2 * QUIET;
    const k = Math.max(1, Math.floor((px || 512) / n)), w = n * k;
    const data = Buffer.alloc(w * w * 4, 0xff);                 // white, opaque
    for (let r = 0; r < m.length; r++) {
        for (let c = 0; c < m.length; c++) {
            if (!m[r][c]) continue;
            for (let y = (r + QUIET) * k; y < (r + QUIET + 1) * k; y++) {
                for (let x = (c + QUIET) * k; x < (c + QUIET + 1) * k; x++) data.fill(0, (y * w + x) * 4, (y * w + x) * 4 + 3);
            }
        }
    }
    return { w, h: w, data };
}

module.exports = { qrMatrix, qrRgba, QUIET };

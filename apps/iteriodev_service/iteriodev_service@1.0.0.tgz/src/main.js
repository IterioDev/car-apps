'use strict';
/*
 * oap-service ("Service"): the car's service requirements (BMW Condition Based Service) as the instrument cluster has
 * them, read-only: KombiInterface_2 cbsDataServiceList (the items) and cbsDataSBA (the cluster's next service), parsed
 * by javascript/cbs.js. Nothing is written: a service is reset in the cluster's own menu or at a workshop.
 * Ported from cauliflowermossgrape/idrive7-apps apps/service (MIT) @ c67ea17; iDrive 8 only.
 *
 * Screen: drawn by the GPU renderer, designed in the HMI UI builder: apps/hmi-ui-builder/projects/service.json
 * (scripts/oap-tools/make_service_project.js), exported into this folder (rhmiData/ = one empty RHMI host state
 * 'home', renderer/ = screens.json + the builder's runtime). Start, tile and shutdown: the shared OnlineApp host
 * (oap-shared/online-host.js).
 */
const fs = require('fs');
const path = require('path');
const util = require('util');
const someipBuilders                   = require('oap-sdk/src/someip/someipBuilders');
const { createHost }                   = require('./online-host.js');
const cbs                              = require('./cbs.js');

const LOG = '[iteriodev_service]';
const STATES = ['home'];          // the screen = its RHMI host state (uiDescriptions ID8)
const KOMBI_IF = 'de.bmw.infotainment.KombiInterface_2';
const RETRY_MS = +process.env.SERVICE_RETRY_MS || 30000;       // the cluster link again after a failure (tests: shorter)
const ROWS = 4;                   // list rows on the screen; More pages through the rest
const COL = { ok: '#5bd68a', warn: '#ffb020', crit: '#ff3b30', dim: '#8b9099' };
const STATUS = { ok: ['OK', 'ok'], soon: ['Due soon', 'warn'], due: ['Due now', 'crit'], unknown: ['Unknown', 'dim'] };
const LABEL_NAME = 30;            // a longer name stays out of the "NEXT SERVICE · <NAME>" label (it would run into "DUE SOON")
const ROW_PARTS = ['item', 'itemBar', 'itemName', 'itemKm', 'itemDate', 'itemStBg', 'itemSt'];
const FIXED = ['nextLabel', 'nextValue', 'soonLabel', 'soonValue', 'dueLabel', 'dueValue', 'div', 'detTitle', 'detKv', 'detText', 'detFoot'];

// the linked bundle is javascript/app.js: the package root is one up, the app's data folder beside it (the Store's)
const SOURCE = typeof __dirname === 'string' ? path.join(__dirname, '..') : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const DATA = path.join(__dirname, '..', '..', 'data');
const LOG_FILE = `${DATA}/service.log`;

function log() {
    const line = [new Date().toISOString()].concat([].slice.call(arguments)
        .map((x) => (typeof x === 'string' ? x : util.inspect(x, { depth: 4 }).slice(0, 2000)))).join(' ');
    console.error(LOG, line);
    try { if (fs.statSync(LOG_FILE).size > 256 * 1024) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* no file yet */ }
    try { fs.appendFileSync(LOG_FILE, `${line}\n`); } catch (e) { /* no data folder */ }
}

// ---- the cluster's service data -------------------------------------------------------------------------------
let items = [];                   // cbs.parseList: the car's order
let rawSba = null;                // cbsDataSBA as it came: parsed again with each list (its name comes from the list)
let link = 'connecting';          // 'connecting' | 'ok' | 'failed'
let sel = 0;                      // the item shown in the right column
let page = 0;                     // the list page (ROWS items each)

function onList(v) {
    items = cbs.parseList(v);
    if (sel >= items.length) sel = 0;
    page = Math.floor(sel / ROWS);
    log(`service list: ${items.length} items`);
    render();
}
function onSba(v) { rawSba = v; render(); }

const FIELDS = [['cbsDataServiceList', onList], ['cbsDataSBA', onSba]];
let kombi = null;                 // the KombiInterface_2 proxy once up: both fields read again on each show
/** both fields read once (a field the car has not sent yet rejects the read: no value) */
const read = () => Promise.all(FIELDS.map(([f, fn]) => Promise.resolve().then(() => kombi[f].getValue()).then(fn, () => null)));

/** both fields subscribed, then read; both subscribes refused: failed (tried again) */
function connect() {
    return someipBuilders.buildAndInitTypedProxy(KOMBI_IF, '1', { timeoutMs: 10000 })
        .then((p) => Promise.all(FIELDS.map(([f, fn]) => Promise.resolve().then(() => p[f].subscribe(fn))
            .then(() => true, (e) => { log(`${f} subscribe:`, e); return false; })))
            .then((ok) => { if (ok.indexOf(true) < 0) throw new Error('both subscribes refused'); kombi = p; return read(); }))
        .then(() => { link = 'ok'; log('KombiInterface_2 ready'); })
        .catch((e) => { link = 'failed'; log('KombiInterface_2:', e); setTimeout(connect, RETRY_MS); })
        .then(render);
}

// ---- the screen (the renderer) ------------------------------------------------------------------------------------
// renderer/ is the builder's export: screens.json + its runtime. Loaded with a computed path: the linker
// (oap_link.js) leaves it to the platform require (plain files in the package, Node 8).
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
let screens = null;

// '12 300 km' -> ['12 300', 'km'] (the big number, its unit); a date or a text without a unit stays whole
const splitUnit = (s) => { const m = /^(.*\d)\s*([^\d\s][^\d]*)$/.exec(s || ''); return m ? [m[1], m[2]] : [s || '--', '']; };
const plural = (n) => (n === 1 ? 'item' : 'items');

function render() {
    if (!screens) return;
    const none = !items.length, failed = link === 'failed';
    screens.set('homeMenu', { chips: [failed ? ['Cluster not reachable', 'crit'] : none ? ['Waiting for the cluster', 'dim'] : ['From the cluster', 'dim']] })
        .set('noData', { hidden: !none, head: failed ? 'No service data' : 'No service data yet',
            line: failed ? 'The head unit\'s link to the cluster (KombiInterface_2) did not start.' : 'The cluster has not sent its service list.' })
        .set('noDataHint', { hidden: !none, text: failed ? 'It is tried again every 30 s.' : 'It usually comes a few seconds after the ignition is on.' });
    FIXED.forEach((n) => screens.set(n, { hidden: none }));
    const pages = Math.max(1, Math.ceil(items.length / ROWS));
    screens.set('more', { hidden: none || pages < 2, text: page + 1 < pages ? `More items · ${page + 1} / ${pages}` : 'Back to first items' });
    for (let i = 0; i < ROWS; i++) {
        const k = page * ROWS + i, it = items[k];
        ROW_PARTS.forEach((p) => screens.set(`${p}${i}`, { hidden: !it }));
        if (!it) continue;
        const s = STATUS[it.status], c = COL[s[1]];
        screens.set(`item${i}`, { selected: k === sel })
            .set(`itemBar${i}`, { color: c })
            .set(`itemName${i}`, { text: it.name })
            .set(`itemKm${i}`, { text: it.distance || '--' })
            .set(`itemDate${i}`, { text: it.date || '--' })
            .set(`itemStBg${i}`, { color: `${c}33` })
            .set(`itemSt${i}`, { text: s[0].toUpperCase(), color: c });
    }
    if (none) return;
    // the summary: the cluster's next service (else the most urgent item), how many are due soon / now
    // its value: the distance or the date, the first with a digit (the number font draws no letters), else --
    const sum = cbs.summary(items, cbs.parseSummary(rawSba, items)), n = sum.next;
    const nv = splitUnit([n.distance, n.date].filter((t) => /\d/.test(t || ''))[0]);
    screens.set('nextLabel', { text: (n.name && n.name.length <= LABEL_NAME ? `Next service · ${n.name}` : 'Next service').toUpperCase() })
        .set('nextValue', { value: nv[0], unit: nv[1], color: STATUS[n.status][1] })
        .set('soonValue', { value: String(sum.soon), unit: plural(sum.soon), color: sum.soon ? 'warn' : 'text' })
        .set('dueValue', { value: String(sum.due), unit: plural(sum.due), color: sum.due ? 'crit' : 'text' });
    // the item tapped: what is left (in its status colour when due soon / now), what it is
    const it = items[sel], s = STATUS[it.status], dc = s[1] === 'warn' || s[1] === 'crit' ? s[1] : '', d = cbs.details(it, Date.now());
    screens.set('detTitle', { text: it.name.toUpperCase() })
        .set('detKv', { rows: [['Distance left', it.distance || '--', it.distance ? dc : ''], ['Due by', it.date || '--', it.date ? dc : '']]
            .concat([['Time left', d.left || '--', d.left ? dc : ''], ['Status', s[0], s[1]]]) })
        .set('detText', { text: d.text });
}

const EVENTS = {
    more: () => {
        const pages = Math.ceil(items.length / ROWS);
        if (pages < 2) return;
        page = (page + 1) % pages; sel = page * ROWS; render();
    },
};
function onEvent(name) {
    const m = /^item(\d)$/.exec(name);
    if (m) { const k = page * ROWS + +m[1]; if (items[k]) { sel = k; render(); } return; }
    if (EVENTS[name]) EVENTS[name]();
}

// ---- RHMI: the host state (the OnlineApp host hands it over) ------------------------------------------------------
let app = null;
const comp = (n) => app.getByName(n);
function showScreen(name) {
    return comp(name).updateResources().then(() => app.openState(name))
        .then(() => log(`opened ${name}`))
        .catch((e) => log(`open ${name} failed:`, e));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed:`, e));

function startScreens(rhmiApp, hosts) {
    app = rhmiApp;
    const design = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: (m) => log(m), warn: (m) => log(m), error: (m) => log(m) };
    const gpu = new RenderClient('iteriodev_service', rlog);
    screens = new ScreenApp(gpu, design, { view: 'id8', log: rlog });
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('event', (n) => { try { onEvent(n); } catch (e) { log(`${n} failed:`, e); } });
    screens.on('show', () => { render(); if (kombi) read(); });     // a change the app missed while hidden: shown now
    // the user left for the HMI (touched it): leave the host state too, or the HMI would show its empty page
    screens.on('closed', (why) => { if (why !== 'hmi') STATES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
    render();
}

// ---- lifecycle: the shared OnlineApp host (start, tile, shutdown) -------------------------------------------------
// The cluster link starts with the screen; it only listens (nothing to hand back at shutdown).
log('start', process.getuid());
createHost({
    states: STATES,
    log,
    onReady: (rhmiApp, hosts) => { startScreens(rhmiApp, hosts); log('screen ready'); connect(); },
});

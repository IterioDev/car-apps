// Ported from cauliflowermossgrape/idrive7-apps (MIT License, Copyright (c) 2026 cauliflowermossgrape): apps/service/main.js @ c67ea17.
'use strict';
/*
 * cbs.js - oap-service: the car's service requirements (BMW Condition Based Service) as the instrument cluster
 * has them, read-only. Pure: KombiInterface_2 field values -> items / next service / counts; main.js draws.
 *
 * Input: the value the oap-sdk typed proxy hands over (someipBuilders.buildAndInitTypedProxy(
 * 'de.bmw.infotainment.KombiInterface_2', '1'), then proxy.<field>.subscribe(fn) / getValue()), a decoded object
 * with the member names of de_bmw_infotainment_KombiInterface_2.json:
 *   cbsDataServiceList  ArrayD (max 32) of Union
 *     cBSDataServiceStruct        { cBSIdentifier UInt16, cBSColor Enum, cBSServcieName (sic) Utf16D,
 *                                   cBSServiceWay Utf16D, cBSServiceDate Utf16D, yearCBSDisplay UInt8, monthCBSDisplay UInt8 }
 *     cBSDataServiceWithSymbolID  { cBSDataService { the same }, cBSListSymbolID UInt16, ricResourceID UInt32,
 *                                   cBSAvail UInt8, cBSServCount UInt8, dayCBSDisplay UInt8 }
 *   cbsDataSBA          Struct { cBSDataSBAText, cBSDataSBADistance, cBSDataSBADate Utf16D, cBSDataSBAColor Enum }
 *   cBSColor / cBSDataSBAColor: Enum DEFAULT 0, RED 1, YELLOW 2, GREEN 3, ORANGE 4 - as its name or its number.
 * Unions arrive wrapped in their member's name (the kit, our dtcscan), so each entry is searched for the object
 * holding cBSIdentifier. The list is taken as an array, or wrapped as { cbsDataServiceList: [...] } / { value: [...] }.
 * Distance and date are texts the car formats in its own language and units; they are passed on as they are.
 */

/* English names by CBS id (the kit's CBS_NAMES) */
const CBS_NAMES = {
    0x01: 'Engine oil', 0x02: 'Front brake pads', 0x03: 'Brake fluid',
    0x05: 'Service Inclusive', 0x06: 'Rear brake pads', 0x07: 'Particulate filter (OPF/DPF)',
    0x08: 'State of Health', 0x0A: 'Spark / glow plugs', 0x0D: 'NOx additive',
    0x11: 'Visual inspection / vehicle check', 0x14: 'Delivery inspection', 0x15: 'Running-in check',
    0x17: 'Water filter', 0x20: 'Statutory vehicle inspection (HU)', 0x21: 'Emissions inspection (AU)',
    0x23: 'Transmission oil', 0x31: 'Tyres', 0x32: 'Clutch',
    0x33: 'Pedestrian-protection bonnet struts', 0x34: 'First-aid kit', 0x35: 'Tyre repair kit',
    0x36: 'Catalytic converter', 0x37: 'Shock absorbers', 0x64: 'Vehicle check',
};
const COLOURS = ['default', 'red', 'yellow', 'green', 'orange'];        // cBSColor by number
// DEFAULT, a colour missing or one the schema does not have: no status (the kit draws it neutral), never OK
const STATUS = { default: 'unknown', red: 'due', yellow: 'soon', green: 'ok', orange: 'soon' };
const RANK = { due: 0, soon: 1, ok: 2, unknown: 2 };

const hex = (n) => n.toString(16).toUpperCase().padStart(2, '0');
const colourOf = (c) => (typeof c === 'number' ? COLOURS[c] || 'default'
    : COLOURS.indexOf(String(c).toLowerCase()) >= 0 ? String(c).toLowerCase() : 'default');
const text = (s) => String(s === undefined || s === null ? '' : s).normalize('NFC')
    .replace(/[   ]/g, ' ').replace(/[\x00-\x1f\x7f]/g, '').trim();

/*
 * Texts the fonts cannot draw (the kit): the car words the items in the iDrive's language; a non-Latin one (Korean,
 * Chinese, Cyrillic, ...) or one already broken ("?" / U+FFFD for a lost character) is not shown: a name becomes
 * the English name by id, a distance or date keeps its numbers.
 * ponytail: "drawable" = Latin + Latin-1 + Latin Extended-A/B + general punctuation + euro sign; check the
 * renderer font atlas instead if it ever gets other scripts.
 */
const latin = (s) => /^[ -~ -ɏ‐-⁞€]*$/.test(s);
const usable = (s) => !!s && latin(s) && !/[?�]/.test(s);
const nameOf = (id, s) => (usable(s) ? s : CBS_NAMES[id] || 'CBS 0x' + hex(id));
/** a distance or date the fonts cannot draw: its numbers ("2027년 9월" -> "09/2027") */
function value(s) {
    if (!s || latin(s)) return s;
    const ym = s.match(/(\d{4})\D+(\d{1,2})(?!\d)/), my = s.match(/(?:^|\D)(\d{1,2})\D+(\d{4})/);
    if (ym) return ym[2].padStart(2, '0') + '/' + ym[1];
    if (my) return my[1].padStart(2, '0') + '/' + my[2];
    return Array.from(s).filter(latin).join('').replace(/\s+/g, ' ').trim();
}

/** the object holding `key` somewhere inside v (unions arrive wrapped in their member's name) */
function find(v, key) {
    if (!v || typeof v !== 'object') return null;
    if (key in v) return v;
    const ks = Object.keys(v);
    for (let i = 0; i < ks.length; i++) { const r = find(v[ks[i]], key); if (r) return r; }
    return null;
}

/**
 * cbsDataServiceList -> [{ id, name, carName, distance, date, status: 'ok' | 'soon' | 'due' | 'unknown', colour }], car order.
 * carName = the car's own text (to match the summary); [] for an empty or missing list ("no service data").
 */
function parseList(v) {
    const arr = Array.isArray(v) ? v : (v && (v.cbsDataServiceList || v.value)) || [];
    if (!Array.isArray(arr)) return [];
    return arr.map((e) => {
        const s = find(e, 'cBSIdentifier');
        if (!s || typeof s.cBSIdentifier !== 'number') return null;
        const carName = text(s.cBSServcieName !== undefined ? s.cBSServcieName : s.cBSServiceName);
        const distance = value(text(s.cBSServiceWay)), date = value(text(s.cBSServiceDate));
        if (!carName && !distance && !date) return null;                 // an empty slot
        const colour = colourOf(s.cBSColor);
        return { id: s.cBSIdentifier, name: nameOf(s.cBSIdentifier, carName), carName, distance, date,
            status: STATUS[colour], colour };
    }).filter(Boolean);
}

/**
 * cbsDataSBA -> the next service { name, carName, distance, date, status, colour }, null when missing / empty.
 * Its name: that of the list item the car words the same way (so a Korean text gets the item's English name),
 * else the car's text if drawable, else ''. The summary can come before the list: parse it again on a new list.
 */
function parseSummary(v, items) {
    const s = find(v, 'cBSDataSBAText');
    if (!s) return null;
    const carName = text(s.cBSDataSBAText);
    const distance = value(text(s.cBSDataSBADistance)), date = value(text(s.cBSDataSBADate));
    if (!carName && !distance && !date) return null;
    const names = (items || []).filter((i) => carName && i.carName === carName).map((i) => i.name)
        .filter((n, i, a) => a.indexOf(n) === i);
    const colour = colourOf(s.cBSDataSBAColor);
    return { name: names.length === 1 ? names[0] : usable(carName) ? carName : '', carName, distance, date,
        status: STATUS[colour], colour };
}

/**
 * items (+ the parsed summary) -> { next, soon: n, due: n }. next: the cluster's own summary when there is one,
 * else the most urgent item. ponytail: within one status the car's order wins; distance / date are not compared
 * (texts in the car's own units and format).
 */
function summary(items, sba) {
    items = items || [];
    const count = (st) => items.filter((i) => i.status === st).length;
    const urgent = items.reduce((a, i) => (!a || RANK[i.status] < RANK[a.status] ? i : a), null);
    return { next: sba || urgent, soon: count('soon'), due: count('due') };
}

/* what an item is, in a few words (the details panel's line); other ids: the due rule alone */
const WHAT = {
    0x01: 'Oil change with filter.', 0x02: 'Front brake pads.', 0x03: 'Brake fluid change.', 0x06: 'Rear brake pads.',
    0x07: 'Particulate filter.', 0x0A: 'Spark or glow plugs.', 0x11: 'Vehicle check.', 0x20: 'Statutory vehicle inspection.',
    0x21: 'Emissions inspection.', 0x23: 'Transmission oil change.', 0x64: 'Vehicle check.',
};
/** months from now (ms) to a date the car words MM/YYYY (month 1-12); null for any other form */
function monthsLeft(date, now) {
    const m = /^(\d{1,2})\/(\d{4})$/.exec(date || ''), d = new Date(now);
    return m && +m[1] >= 1 && +m[1] <= 12 ? (+m[2] - d.getFullYear()) * 12 + (+m[1] - 1 - d.getMonth()) : null;
}
/**
 * item -> { left: 'Overdue' | 'This month' | 'Next month' | 'n months' | null (no MM/YYYY date), text: what it is +
 * the due rule }. ponytail: months only (the car gives no day); a car that words its dates otherwise gets no time left.
 */
function details(item, now) {
    const n = monthsLeft(item.date, now);
    const left = n === null ? null : n < 0 ? 'Overdue' : n === 0 ? 'This month' : n === 1 ? 'Next month' : `${n} months`;
    const rule = item.distance && item.date ? `Due after ${item.distance} or by ${item.date}, whichever comes first.`
        : item.date ? 'Due by date only: the distance does not count for it.'
            : item.distance ? `Due after ${item.distance}.` : '';
    return { left, text: [WHAT[item.id] || '', rule].filter(Boolean).join(' ') };
}

function test() {
    const assert = require('assert');
    // a list as the schema has it: both union members, enums by name and by number
    const plain = (id, color, name, way, date) => ({ cBSDataServiceStruct: { cBSIdentifier: id, cBSColor: color,
        cBSServcieName: name, cBSServiceWay: way, cBSServiceDate: date, yearCBSDisplay: 0, monthCBSDisplay: 0 } });
    const sym = (id, color, name, way, date) => ({ cBSDataServiceWithSymbolID: { cBSDataService: plain(id, color, name, way,
        date).cBSDataServiceStruct, cBSListSymbolID: 7, ricResourceID: 0, cBSAvail: 80, cBSServCount: 1, dayCBSDisplay: 0 } });
    const list = [
        sym(0x01, 'GREEN', 'Engine oil', '12 300 km', '09/2027'),
        plain(0x02, 3, 'Front brakes', '21 800 km', ''),
        plain(0x03, 'YELLOW', 'Brake fluid', '', '11/2026'),
        sym(0x20, 'RED', 'Fahrzeuguntersuchung (HU) fällig', '', '10/2026'),
        plain(0x06, 4, 'Rear brakes', '1 200 km', ''),
        plain(0x11, 'DEFAULT', 'Vehicle check', '9 800 km', '11/2027'),
        plain(0, 0, '', '', ''),                                                      // empty slot
        { cBSDataServiceStruct: { cBSColor: 3, cBSServcieName: 'no id' } },            // no id
    ];
    const items = parseList(list);
    assert.strictEqual(items.length, 6);
    assert.deepStrictEqual(items[0], { id: 1, name: 'Engine oil', carName: 'Engine oil', distance: '12 300 km',
        date: '09/2027', status: 'ok', colour: 'green' });
    assert.deepStrictEqual(items.map((i) => i.status), ['ok', 'ok', 'soon', 'due', 'soon', 'unknown']);
    assert.deepStrictEqual(items.map((i) => i.colour), ['green', 'green', 'yellow', 'red', 'orange', 'default']);
    assert.strictEqual(items[3].name, 'Fahrzeuguntersuchung (HU) fällig');    // Latin-1 is drawn as the car words it
    assert.deepStrictEqual(parseList({ cbsDataServiceList: list }), items);
    assert.deepStrictEqual(parseList({ value: list }), items);
    // a colour missing, DEFAULT or one the schema does not have: no status (not OK); it ranks with OK (the car's order)
    const nocol = parseList([{ cBSDataServiceStruct: { cBSIdentifier: 1, cBSServcieName: 'Engine oil', cBSServiceWay: '1 km' } },
        plain(0x02, 9, 'Front brakes', '2 km', ''), plain(0x03, 'PURPLE', 'Brake fluid', '3 km', ''), plain(0x06, 'RED', 'Rear brakes', '', '')]);
    assert.deepStrictEqual(nocol.map((i) => i.status), ['unknown', 'unknown', 'unknown', 'due']);
    assert.strictEqual(summary(nocol).next.id, 0x06);
    assert.strictEqual(summary(nocol.slice(0, 3)).next.id, 1);
    assert.strictEqual(parseSummary({ cBSDataSBAText: 'Engine oil', cBSDataSBADistance: '1 km' }).status, 'unknown');

    // counts and the next service: most urgent without a summary, the cluster's summary when there is one
    const s = summary(items);
    assert.strictEqual(s.soon, 2); assert.strictEqual(s.due, 1); assert.strictEqual(s.next.id, 0x20);
    assert.strictEqual(summary(items.slice(0, 2)).next.id, 1);                     // all ok: the car's first
    const sba = parseSummary({ cBSDataSBAText: 'Engine oil', cBSDataSBADistance: '12 300 km',
        cBSDataSBADate: '09/2027', cBSDataSBAColor: 'GREEN' }, items);
    assert.deepStrictEqual(sba, { name: 'Engine oil', carName: 'Engine oil', distance: '12 300 km', date: '09/2027',
        status: 'ok', colour: 'green' });
    assert.strictEqual(summary(items, sba).next, sba);

    // names: the car's text, else the English name by id, else CBS 0x..; dates keep their numbers
    const ko = parseList([plain(0x01, 1, '엔진 오일', '12,300 km', '2027년 9월'),
        plain(0x2A, 2, '브레이크', '', ''), plain(0x03, 3, 'Bremsfl?ssigkeit', '', '11/2026'),
        plain(0x64, 3, '', '5 000 km', ''), plain(0x123, 3, 'Тормоза', '', '')]);
    assert.deepStrictEqual(ko.map((i) => i.name), ['Engine oil', 'CBS 0x2A', 'Brake fluid', 'Vehicle check', 'CBS 0x123']);
    assert.strictEqual(ko[0].date, '09/2027');
    assert.strictEqual(ko[0].distance, '12,300 km');
    assert.strictEqual(parseSummary({ cBSDataSBAText: '엔진 오일', cBSDataSBADistance: '12,300 km',
        cBSDataSBADate: '2027년 9월', cBSDataSBAColor: 1 }, ko).name, 'Engine oil');   // matched to its item
    assert.strictEqual(parseSummary({ cBSDataSBAText: '엔진', cBSDataSBADistance: '1 km' }).name, '');

    // empty or missing: no service data
    [undefined, null, [], {}, { value: [] }, { cbsDataServiceList: null }, 'x'].forEach((v) => assert.deepStrictEqual(parseList(v), []));
    assert.deepStrictEqual(summary([]), { next: null, soon: 0, due: 0 });
    assert.deepStrictEqual(summary(undefined), { next: null, soon: 0, due: 0 });
    assert.strictEqual(parseSummary(undefined), null);
    assert.strictEqual(parseSummary({ cBSDataSBAText: '', cBSDataSBADistance: '', cBSDataSBADate: '', cBSDataSBAColor: 0 }), null);
    // details: the line saying what the item is and asks for, and the months left (a date MM/YYYY), 4 Nov 2026
    const nov = new Date(2026, 10, 4).getTime();
    assert.deepStrictEqual(details(items[0], nov), { left: '10 months',
        text: 'Oil change with filter. Due after 12 300 km or by 09/2027, whichever comes first.' });
    assert.deepStrictEqual(details(items[1], nov), { left: null, text: 'Front brake pads. Due after 21 800 km.' });
    assert.deepStrictEqual(details(items[2], nov), { left: 'This month',
        text: 'Brake fluid change. Due by date only: the distance does not count for it.' });
    assert.deepStrictEqual(details(items[3], nov), { left: 'Overdue',
        text: 'Statutory vehicle inspection. Due by date only: the distance does not count for it.' });
    assert.deepStrictEqual(details({ id: 0x99, distance: '', date: '12/2026' }, nov),
        { left: 'Next month', text: 'Due by date only: the distance does not count for it.' });
    assert.deepStrictEqual(details({ id: 0x64, distance: '', date: '' }, nov), { left: null, text: 'Vehicle check.' });
    assert.strictEqual(details({ id: 1, distance: '', date: '2027년 9월' }, nov).left, null);   // not MM/YYYY: no time left
    ['00/2027', '13/2026', '99/2026'].forEach((date) => assert.strictEqual(details({ id: 1, distance: '', date }, nov).left, null, date));
    assert.strictEqual(details({ id: 1, distance: '', date: '1/2027' }, nov).left, '2 months');
    console.log('cbs self-check ok');
}

module.exports = { CBS_NAMES, parseList, parseSummary, summary, details, test };
if (require.main === module) test();

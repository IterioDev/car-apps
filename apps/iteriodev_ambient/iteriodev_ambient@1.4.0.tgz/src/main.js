'use strict';
/*
 * oap-ambient ("Ambient Light"): the front end of the iteriodev-comfort tool's ambient light (iDrive 8): any colour on
 * the interior ambient light (a hue bar and a saturation bar; the tool caps and writes it through the body controller),
 * on one screen: the zones the car has as a list (All zones, then each zone with All / Own / Car: the main colour, its
 * own or the car's; a tap on a row picks it); the bars, the car's nine menu colours for what is picked; brightness or
 * following the car's; six presets of the user's (whole scenes: the main colour and every zone's, this app's own
 * data/ambient.json). Everything else is the tool's: this app talks to it over its control socket (JSON lines, CTL)
 * and shows what it pushes.
 *   -> { op: 'get' } | { op: 'ambient', settings: { on?, rgb?, bright?, follow?, zones?: { <zone>: { rgb } | { off } | null } } }
 *   <- { state: { parked, carOn, ambient: { settings, carOn, lit, modules: [{ id, name, zone, fault }] }, seats, settings } }
 * A drag on a bar gives a 'change' per move: what goes to the tool is merged and sent at most every SEND_MS (4 a second).
 * No socket: the screens say to install the Comfort tool instead of showing controls.
 * 1.3.0 (user 2026-11-09): a second tab, Drive modes: a colour per drive mode (the tool's ambient.js MODES; none = the
 * Colour page's settings) and the drive modes on / off; the tool switches the light with the car's mode
 * (settings.modes = { on, rgb: { <mode>: [r, g, b] | null } }, state.ambient.mode = the car's mode now).
 * 1.4.0 (user 2026-11-12): the iDrive controller too, for cars without a touchscreen: FrontCCU's knob state
 * (oap-shared/frontccu.js) into the screens (renderer/controller.js: turn = next control, press = tap, a bar: press,
 * turn, press).
 *
 * Screens: drawn by the GPU renderer, designed in the HMI UI builder: apps/hmi-ui-builder/projects/ambient.json
 * (scripts/oap-tools/make_ambient_project.js), exported into this folder (rhmiData/ = one empty RHMI host state per
 * screen, renderer/ = screens.json + the builder's runtime). Start, tile and shutdown: the shared OnlineApp host
 * (oap-shared/online-host.js). Node 8: no newer syntax here.
 */
const fs = require('fs');
const net = require('net');
const path = require('path');
const util = require('util');
const { createHost }                   = require('./online-host.js');
const { watchController }              = require('./frontccu.js');

const LOG = '[iteriodev_ambient]';
const STATES = ['colour', 'modes'];   // the screens = their RHMI host states, colour the entry
const MENUS = { colour: 'colourMenu', modes: 'modesMenu' };
const CTL = process.env.COMFORT_CTL || '/run/iteriodev-comfort/ctl.sock';
const RETRY_MS = 2000;
const SEND_MS = 250;                  // at most 4 updates a second to the tool
const KEEP_MS = 1500;                 // a control the user touched keeps its place this long (the tool's echo comes later)

// the linked bundle is javascript/app.js: the package root (next to renderer/) is its parent folder, the app's data
// folder beside that (the Store's)
const SOURCE = typeof __dirname === 'string' ? path.join(__dirname, '..') : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const DATA = process.env.AMBIENT_DATA || path.join(__dirname, '..', '..', 'data');
const LOG_FILE = `${DATA}/ambient.log`;
const FAV_FILE = `${DATA}/ambient.json`;

function log() {
    const line = [new Date().toISOString()].concat([].slice.call(arguments)
        .map((x) => (typeof x === 'string' ? x : util.inspect(x, { depth: 4 }).slice(0, 2000)))).join(' ');
    console.error(LOG, line);
    try { if (fs.statSync(LOG_FILE).size > 256 * 1024) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* no file yet */ }
    try { fs.appendFileSync(LOG_FILE, `${line}\n`); } catch (e) { /* no data folder */ }
}

// ---- colours ------------------------------------------------------------------------------------------------
// the car's nine menu colours, approximate RGB (starting points: the bars take it from there)
const CAR = [['Ivory', [255, 236, 200]], ['Citrine', [255, 196, 40]], ['Coral', [255, 110, 70]], ['Flamingo', [255, 70, 120]],
    ['Pearl', [225, 230, 255]], ['Turquoise', [0, 210, 200]], ['Emerald', [20, 210, 90]], ['Rose', [255, 120, 170]], ['Azure', [40, 120, 255]]];
const ZONES = ['dash', 'doors', 'footwell', 'console', 'seats', 'roof'];      // the tool's ambient.js ZONES
const ZNAME = { dash: 'Dash', doors: 'Doors', footwell: 'Footwell', console: 'Console', seats: 'Seats', roof: 'Roof' };
// a zone with more than one kind of light is split by the tool into parts ('dash.line', 'dash.decor': an X6's red line
// above, white decor below), each a zone of its own here
const KINDS = ['line', 'top', 'decor', 'bottom', 'other'];         // the tool's ambient.js KINDS
const KNAME = { line: 'line', top: 'upper decor', decor: 'decor', bottom: 'lower decor', other: 'details' };
const PART = new RegExp(`^(${ZONES.join('|')})(\\.(${KINDS.join('|')}))?$`);
const baseOf = (k) => k.split('.')[0];
const keyName = (k) => { const p = k.split('.'); return p[1] ? `${ZNAME[p[0]]} ${KNAME[p[1]]}` : ZNAME[p[0]]; };
const keyOrder = (a, b) => (ZONES.indexOf(baseOf(a)) - ZONES.indexOf(baseOf(b))) || (KINDS.indexOf(a.split('.')[1]) - KINDS.indexOf(b.split('.')[1]));
/** hue 0-360, saturation 0-1 -> [r, g, b] at full value (the brightness is the tool's own setting) */
function hsv(h, s) {
    const f = (n) => { const k = (n + h / 60) % 6; return Math.round(255 * (1 - s * Math.max(0, Math.min(k, 4 - k, 1)))); };
    return [f(5), f(3), f(1)];
}
function hs(rgb) {                                // [r, g, b] -> { h, s } (the bars' places)
    const r = rgb[0] / 255, g = rgb[1] / 255, b = rgb[2] / 255, mx = Math.max(r, g, b), d = mx - Math.min(r, g, b);
    let h = 0;
    if (d) h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    return { h: (h * 60 + 360) % 360, s: mx ? d / mx : 0 };
}
// the drive modes the tool colours (its ambient.js MODES: FES actualValueModeDrivingExperience)
const MODES = { 1: 'Sport', 2: 'Sport Plus', 3: 'Sport Individual', 4: 'Comfort', 5: 'Comfort Plus', 6: 'Comfort Individual',
    7: 'Eco Pro', 8: 'Eco Pro Plus', 9: 'Eco Pro Individual', 10: 'Adaptive' };
const hex = (c) => '#' + c.map((v) => (v < 16 ? '0' : '') + v.toString(16)).join('');
const same = (a, b) => !!a && !!b && a[0] === b[0] && a[1] === b[1] && a[2] === b[2];
const okRgb = (v) => Array.isArray(v) && v.length === 3 && v.every((x) => x === (x | 0) && x >= 0 && x <= 255);

// presets: up to six scenes { rgb, zones: { <zone>: { rgb } | { off } } } (a zone not in it: the main colour), the
// newest last; 1.0.x favourites (single colours) become presets of one colour
const okZone = (v) => !!v && (v.off === true || okRgb(v.rgb));
function okPreset(p) {
    if (!p || !okRgb(p.rgb)) return null;
    const zones = {};
    Object.keys(p.zones || {}).filter((z) => PART.test(z)).forEach((z) => {
        const v = p.zones[z];
        if (okZone(v)) zones[z] = v.off ? { off: true } : { rgb: v.rgb.slice() };
    });
    return { rgb: p.rgb.slice(), zones };
}
/** every zone key a scene change has to speak for: the zones, the car's parts, and what the settings hold */
const allKeys = (...maps) => ZONES.concat.apply(ZONES.slice(), maps.map((m) => (Array.isArray(m) ? m : Object.keys(m || {}))))
    .filter((k, i, a) => a.indexOf(k) === i);
let presets = [];
try {
    const d = JSON.parse(fs.readFileSync(FAV_FILE, 'utf8'));
    presets = (d.presets || (d.favs || []).map((rgb) => ({ rgb }))).map(okPreset).filter(Boolean).slice(-6);
} catch (e) { /* none yet */ }
function savePresets() {
    try { fs.mkdirSync(DATA); } catch (e) { /* there already (Node 8: no recursive) */ }
    try { fs.writeFileSync(FAV_FILE, JSON.stringify({ presets })); } catch (e) { log('presets not saved:', e.message); }
}
/** what a zone shows in a scene: 'main', 'car' or its own colour's hex */
const zv = (v) => (!v ? 'main' : v.off ? 'car' : hex(v.rgb));
const sameScene = (p, st) => same(p.rgb, st.rgb) && allKeys(p.zones, st.zones).every((z) => zv(p.zones[z]) === zv(st.zones[z]));
/** what a zone (or part) gets: its own setting, else its whole zone's (a part), else null = the main colour */
const eff = (zones, k) => zones[k] || (k.indexOf('.') > 0 ? zones[baseOf(k)] : null) || null;

// ---- the tool ---------------------------------------------------------------------------------------------
let tool = null;                  // its last state, null = no connection
let sock = null;
let busy = false;                 // a connection being made

function connect() {
    if (sock || busy) return;
    busy = true;
    const s = net.connect(CTL);
    let buf = '';
    s.setEncoding('utf8');
    s.on('connect', () => { busy = false; sock = s; log('tool connected'); });
    s.on('data', (d) => {
        buf += d;
        for (let n; (n = buf.indexOf('\n')) >= 0; buf = buf.slice(n + 1)) {
            let m;
            try { m = JSON.parse(buf.slice(0, n)); } catch (e) { continue; }
            if (m.state) { tool = m.state; render(); }
        }
    });
    s.on('error', (e) => { if (!/ENOENT|ECONNREFUSED/.test(e.code)) log('tool:', e.message); });
    s.on('close', () => { busy = false; sock = null; tool = null; pend = null; render(); setTimeout(connect, RETRY_MS); });
}
const send = (q) => { if (sock) sock.write(`${JSON.stringify(q)}\n`); };

// what goes to the tool: merged into one patch, sent at once or SEND_MS after the last one (a drag: 4 a second)
let pend = null, lastSend = 0, sendTimer = null;
function ambient(patch) {
    pend = pend || {};
    Object.keys(patch).forEach((k) => {
        const was = pend[k] || {};
        pend[k] = k === 'zones' ? Object.assign({}, was, patch.zones)
            : k === 'modes' ? Object.assign({}, was, patch.modes, was.rgb || patch.modes.rgb ? { rgb: Object.assign({}, was.rgb, patch.modes.rgb) } : {})
                : patch[k];
    });
    const wait = lastSend + SEND_MS - Date.now();
    if (wait <= 0) flush(); else if (!sendTimer) sendTimer = setTimeout(flush, wait);
}
function flush() {
    sendTimer = null;
    if (!pend) return;
    lastSend = Date.now();
    send({ op: 'ambient', settings: pend });
    pend = null;
}
/** the settings as they will be: the tool's with what is still to be sent over them */
function cur() {
    const t = tool.ambient.settings, p = pend || {}, z = Object.assign({}, t.zones, p.zones);
    Object.keys(z).forEach((k) => { if (!z[k]) delete z[k]; });
    const tm = t.modes || { on: false, rgb: {} }, pm = p.modes || {};
    const modes = { on: typeof pm.on === 'boolean' ? pm.on : !!tm.on, rgb: Object.assign({}, tm.rgb, pm.rgb) };
    return Object.assign({}, t, p, { zones: z, modes });
}

// ---- screens (the renderer) ----------------------------------------------------------------------------
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
let screens = null;
let content = [];                 // every element but the frames and the no-tool notes: hidden without the tool
const SUB = 'Tap a zone to give it its own colour · All zones colours every zone';
const SLOTS = 9;                  // the list's rows zone0-8 (beside 'All zones'): a car's zones and parts, in order
/** the rows this head unit's layout has: iDrive 7's list holds seven (1.2.0); iDrive 8 (or not known yet) all nine */
function slots() { try { return screens._hu() === 'id7' ? 7 : SLOTS; } catch (e) { return SLOTS; } }
const CAR_GREY = '#8b9099';       // a zone that keeps the car's colour (we do not know which that is)
const touched = {};               // element -> when the user last moved it
const fresh = (n) => Date.now() - (touched[n] || 0) < KEEP_MS;
const pick = { h: 0, s: 1 };      // the place on the bars of what is picked
let sel = 'all';                  // what the bars and the car's colours set: 'all' (the main colour) or a zone
const zoneSel = (v) => (!v ? 0 : v.off ? 2 : 1);   // All / Own / Car
/** the colour of what is picked: ALL or a zone of the main colour -> the main colour; its own; the car's -> null */
const selRgb = (st) => { const v = sel === 'all' ? null : eff(st.zones, sel); return !v ? st.rgb : v.rgb || null; };
function repick() { touched.hue = touched.sat = 0; pick.h = -1; }     // a new pick: the bars jump to its colour
// the bars follow the tool's colour unless the user moved them just now (or they already give that colour)
function follow(rgb) {
    if (!rgb || ['hue', 'sat'].some(fresh) || (pick.h >= 0 && same(hsv(pick.h, pick.s), rgb))) return;
    const v = hs(rgb); pick.h = v.h; pick.s = v.s;
}
/** a preset's swatch: its colours, one stripe each (the main one first), and a name */
function look(p, present) {
    const cs = [hex(p.rgb)];
    present.forEach((z) => { const v = zv(eff(p.zones, z)), c = v === 'main' ? null : v === 'car' ? CAR_GREY : v; if (c && cs.indexOf(c) < 0) cs.push(c); });
    return { colors: cs.length > 1 ? cs.join(',') : '', color: cs[0], label: cs.length > 1 ? `${cs.length} colours` : cs[0] };
}

function render() {
    if (!screens) return;
    const t = tool, a = t && t.ambient, mods = (a && a.modules) || [];
    const faulty = mods.filter((m) => m.fault), present = zoneKeys(mods);
    const st = t ? cur() : null;
    if (sel !== 'all' && present.indexOf(sel) < 0) { sel = 'all'; repick(); }
    // what is hidden: everything without the tool, else what this pick does not have
    const hide = { zonesNone: present.length > 0, zoneAll: !present.length, allRow: sel !== 'all', zoneRow: sel === 'all' };
    const rows = slots();
    for (let i = 0; i < SLOTS; i++) hide[`zone${i}`] = i >= Math.min(present.length, rows);
    content.forEach((n) => screens.set(n, { hidden: !t || !!hide[n] }));
    ['colourNoTool', 'modesNoTool'].forEach((n) => screens.set(n, { hidden: !!t }));
    Object.keys(MENUS).forEach((pg) => screens.set(MENUS[pg], { sel: STATES.indexOf(pg) }));
    if (!t) {
        Object.keys(MENUS).forEach((pg) => screens.set(MENUS[pg], { chips: [['Comfort tool not running', 'crit']], sub: 'Install the Comfort tool from the Store' }));
        return null;
    }
    // the frame: the car's light off, faulty lights, a drive mode's colour showing
    const chips = [], ms = st.modes, mrgb = ms.on && a.mode != null ? ms.rgb[a.mode] : null;
    if (a.carOn === false) chips.push(['Ambient light off in the car', 'warn']);
    if (faulty.length) chips.push([`${faulty.length} faulty light${faulty.length > 1 ? 's' : ''}`, 'crit']);
    if (mrgb) chips.push([`${MODES[a.mode]} colour`, 'ok']);
    screens.set('colourMenu', { chips, sub: a.carOn === false ? 'Switch the ambient light on in the car\'s menu'
        : mrgb ? `${MODES[a.mode]}'s colour shows now · set it under Drive modes` : SUB });
    screens.set('modesMenu', { chips: chips.slice(0, 1), sub: a.carOn === false ? 'Switch the ambient light on in the car\'s menu' : MSUB });
    renderModes(st);
    // the zone list: All zones, then each zone (or part) the car has: All / Own / Car, the one picked marked
    const lights = (z) => { const n = mods.filter((m) => !z || m.zone === z).length; return `${n} light${n === 1 ? '' : 's'}`; };
    screens.set('zoneAll', { selected: sel === 'all', sub: st.on ? `${lights()} · our colour` : 'Off: the car\'s colour' });
    present.slice(0, rows).forEach((k, i) => {
        const f = faulty.filter((m) => m.zone === k).length, part = k.split('.')[1], z = zoneSel(eff(st.zones, k));
        // iDrive 8: its All / Own / Car buttons (sel); iDrive 7: the same as text (its buttons: the picked one's, in the middle)
        screens.set(`zone${i}`, { label: ZNAME[baseOf(k)], sel: z, text: ['All', 'Own', 'Car'][z], textColor: z === 1 ? 'accent' : '',
            selected: sel === k, subColor: f ? 'crit' : '', sub: [part && KNAME[part], lights(k), f && `${f} faulty`].filter(Boolean).join(' · ') });
    });
    // what is picked
    if (sel === 'all') {
        screens.set('pickTitle', { text: 'ALL ZONES' })
            .set('allRow', { on: !!st.on, sub: st.on ? `${lights()} · our colour` : 'Off: the car\'s colour' });
    } else {
        const v = eff(st.zones, sel), f = faulty.filter((m) => m.zone === sel).length;
        screens.set('pickTitle', { text: sel.indexOf('.') > 0 ? `${ZNAME[baseOf(sel)]} · part`.toUpperCase() : 'ZONE' })
            .set('zoneRow', { label: keyName(sel), sel: zoneSel(v), subColor: f ? 'crit' : '',
                sub: `${lights(sel)} · ${f ? `${f} faulty` : !v ? 'main colour' : v.off ? 'car\'s colour' : 'own colour'}` });
    }
    const rgb = selRgb(st);
    follow(rgb || st.rgb);
    if (pick.h < 0) { const v = hs(st.rgb); pick.h = v.h; pick.s = v.s; }
    screens.set('preview', { color: rgb ? hex(hsv(pick.h, pick.s)) : CAR_GREY })
        .set('hue', { value: Math.round(pick.h / 360 * 1000) / 1000 })
        .set('sat', { hue: pick.h, value: Math.round(pick.s * 1000) / 1000 })
        .set('followRow', { on: st.follow !== false })
        .set('brightRow', { sub: st.follow === false ? 'Fixed' : 'Of the car\'s own' });
    if (!fresh('brightRow')) screens.set('brightRow', { value: st.bright });
    CAR.forEach((c, i) => screens.set(`car${i}`, { color: hex(c[1]), label: '', selected: same(rgb, c[1]) }));
    for (let i = 0; i < 6; i++) {
        const p = presets[i];
        screens.set(`preset${i}`, p ? Object.assign(look(p, present), { empty: false, disabled: false, selected: !!st.on && sameScene(p, st) })
            : { color: '', colors: '', label: '', empty: true, disabled: true, selected: false });
    }
    screens.set('savePreset', { disabled: !st.on || presets.some((p) => sameScene(p, st)) });
    const state = !st.on && !mrgb ? ['The car\'s colour', ''] : a.carOn === false ? ['Ambient light off', 'warn'] : a.carOn === null ? ['Waiting for the car', '']
        : !a.lit ? ['Starting', ''] : mrgb ? [`${MODES[a.mode]} colour on`, 'ok'] : ['Our colour on', 'ok'];
    screens.set('statusRow', { text: state[0], textColor: state[1], subColor: a.carOn === false ? 'warn' : faulty.length ? 'crit' : '',
        sub: a.carOn === false ? 'Switch the ambient light on in the car\'s menu'
            : faulty.length ? `Faulty: ${faulty.map((m) => m.name).join(' · ')}` : mods.length ? `${lights()} · no faults` : 'No lights found yet' });
}

// ---- Drive modes: the modes with their colours (ringed: the car's now), what is picked, on / off, the mode now ----
const MSUB = 'A colour for each drive mode, switched with it';
let msel = 0;                     // the mode picked on the page (0: none yet - the car's mode, else Sport)
const mpick = { h: -1, s: 1 };    // the bars' place for it
const mode = () => msel || (MODES[tool.ambient.mode] ? tool.ambient.mode : 1);
function mrepick() { touched.modeHue = touched.modeSat = 0; mpick.h = -1; }
function renderModes(st) {
    const a = tool.ambient, m = st.modes, now = a.mode, k = mode(), rgb = m.rgb[k] || null;
    for (let c = 1; c <= 10; c++) {
        const v = m.rgb[c];
        screens.set(`mode${c - 1}`, { selected: c === k })
            .set(`modeSw${c - 1}`, { color: v ? hex(v) : '', empty: !v, selected: c === now });
    }
    if (rgb && !['modeHue', 'modeSat'].some(fresh) && !(mpick.h >= 0 && same(hsv(mpick.h, mpick.s), rgb))) { const v = hs(rgb); mpick.h = v.h; mpick.s = v.s; }
    if (mpick.h < 0) { mpick.h = 0; mpick.s = 1; }
    screens.set('mPickTitle', { text: MODES[k].toUpperCase() })
        .set('modeRow', { sel: rgb ? 0 : 1 })
        .set('modePreview', { color: rgb ? hex(hsv(mpick.h, mpick.s)) : CAR_GREY })
        .set('modeHue', { value: Math.round(mpick.h / 360 * 1000) / 1000 })
        .set('modeSat', { hue: mpick.h, value: Math.round(mpick.s * 1000) / 1000 })
        .set('modesOn', { on: !!m.on });
    CAR.forEach((c, i) => screens.set(`mcar${i}`, { color: hex(c[1]), label: '', selected: same(rgb, c[1]) }));
    const has = now != null && m.rgb[now], s = now == null ? ['Not said yet', ''] : !m.on ? ['Drive modes off', ''] : !MODES[now] ? ['Not in the list', '']
        : !has ? ['No colour: as set', ''] : a.carOn === false ? ['Car\'s light off', 'warn'] : ['Its colour on', ''];
    screens.set('modeStatus', { text: now == null ? '' : MODES[now] || `Mode ${now}`, textColor: m.on && has ? 'ok' : '', sub: s[0], subColor: s[1] });
}
const setModeColour = (rgb) => ambient({ modes: { rgb: { [mode()]: rgb } } });
function goTo(page) {
    const now = screens.st && screens.st.name;
    if (!page || page === now) return;
    if (now && now !== 'colour') closeScreen(now);
    if (page !== 'colour') showScreen(page);
}

// ---- what the user does ---------------------------------------------------------------------------------
/** a colour for what is picked: ALL -> the main colour, a zone -> its own (and our colour on) */
function setColour(rgb) {
    ambient(sel === 'all' ? { on: true, rgb } : { on: true, zones: zonePatch(sel, { rgb }) });
}
/** a zone's (or part's) new setting; a part set on its own drops its whole zone's (left from a preset) for the others
 *  to show what this app shows them */
function zonePatch(k, v) {
    const p = { [k]: v }, z = cur().zones, base = baseOf(k);
    if (base !== k && z[base]) {
        p[base] = null;
        zoneKeys(tool.ambient.modules || []).filter((x) => baseOf(x) === base && x !== k && !z[x]).forEach((x) => { p[x] = z[base]; });
    }
    return p;
}
/** the zones and parts the car has, in their order */
const zoneKeys = (mods) => mods.map((m) => m.zone).filter((k, i, a) => PART.test(k) && a.indexOf(k) === i).sort(keyOrder);
/** a zone (or part) to the main colour (0), its own (1: the one it had, else the main colour) or the car's (2) */
function setMode(k, i) {
    const was = eff(cur().zones, k);
    ambient({ zones: zonePatch(k, i === 1 ? { rgb: (was && was.rgb) || cur().rgb } : i === 2 ? { off: true } : null) });
    repick();
    return render();
}
/** the zone list's row tapped: 'zoneAll' -> 'all', 'zone<i>' -> the car's i-th zone (null: none there) */
function rowKey(name) {
    if (name === 'zoneAll') return 'all';
    const m = /^zone(\d)$/.exec(name);
    return m ? zoneKeys(tool.ambient.modules || [])[+m[1]] || null : null;
}
function onEvent(name) {
    let m;
    if (!tool) return;
    if ((m = /^mode(\d)$/.exec(name))) { msel = +m[1] + 1; mrepick(); return render(); }
    if ((m = /^mcar(\d)$/.exec(name)) && CAR[+m[1]]) { setModeColour(CAR[+m[1]][1].slice()); mrepick(); return render(); }
    const k = rowKey(name);
    if (k) { if (k !== sel) { sel = k; repick(); } return render(); }
    if ((m = /^car(\d)$/.exec(name)) && CAR[+m[1]]) { setColour(CAR[+m[1]][1].slice()); repick(); return render(); }
    if ((m = /^preset(\d)$/.exec(name)) && presets[+m[1]]) {      // the whole scene back
        const p = presets[+m[1]], zones = {};
        allKeys(zoneKeys(tool.ambient.modules || []), cur().zones, p.zones).forEach((z) => { zones[z] = p.zones[z] || null; });
        ambient({ on: true, rgb: p.rgb.slice(), zones });
        repick();
        return render();
    }
    if (name === 'savePreset') {
        const st = cur(), p = okPreset(st);
        if (!p || presets.some((q) => sameScene(q, st))) return;
        presets = presets.concat([p]).slice(-6);
        savePresets();
        render();
    }
}
function onChange(name, o) {
    const page = Object.keys(MENUS).find((pg) => MENUS[pg] === name);
    if (page) {                                       // a tab (o is the shell's opts: read before the set)
        const to = STATES[o.sel];
        screens.set(name, { sel: STATES.indexOf(page) });
        return goTo(to);
    }
    if (!tool) return null;
    if (name === 'modesOn') return ambient({ modes: { on: !!o.on } });
    if (name === 'modeRow') {                         // Colour (the bars' colour) / None
        if (o.sel === 1) ambient({ modes: { rgb: { [mode()]: null } } }); else setModeColour(hsv(mpick.h, mpick.s));
        return render();
    }
    if (name === 'modeHue' || name === 'modeSat') {
        touched[name] = Date.now();
        if (name === 'modeHue') mpick.h = o.value * 360; else mpick.s = o.value;
        setModeColour(hsv(mpick.h, mpick.s));
        return render();
    }
    const k = rowKey(name);
    if (k && k !== 'all') { sel = k; return setMode(k, o.sel); }     // a row's All / Own / Car: that zone, picked
    if (name === 'allRow') return ambient({ on: !!o.on });
    if (name === 'followRow') return ambient({ follow: !!o.on });
    if (name === 'brightRow') { touched.brightRow = Date.now(); return ambient({ bright: Math.max(5, Math.min(100, Math.round(o.value))) }); }
    if (name === 'hue' || name === 'sat') {
        touched[name] = Date.now();
        if (name === 'hue') pick.h = o.value * 360; else pick.s = o.value;
        setColour(hsv(pick.h, pick.s));
        return render();
    }
    if (name === 'zoneRow' && sel !== 'all') return setMode(sel, o.sel);   // All / Own / Car
    return null;
}

// ---- RHMI: the host states (the shared OnlineApp host hands over the RHMI application) -------------------
let app = null;
const comp = (n) => app.getByName(n);
function showScreen(name) {
    return comp(name).updateResources().then(() => app.openState(name))
        .then(() => log(`opened ${name}`))
        .catch((e) => log(`open ${name} failed:`, e));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed:`, e));

function startScreens(rhmiApp) {
    app = rhmiApp;
    const design = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
    content = [].concat.apply([], design.screens.map((s) => s.components.map((c) => c.name))).filter((n) => !/Menu$|NoTool$/.test(n));
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: (m) => log(m), warn: (m) => log(m), error: (m) => log(m) };
    const gpu = new RenderClient('iteriodev_ambient', rlog);
    screens = new ScreenApp(gpu, design, { view: 'id8', log: rlog });
    const hosts = {};
    STATES.forEach((s) => { hosts[s] = comp(s); });
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('event', (n) => { try { onEvent(n); } catch (e) { log(`${n} failed:`, e); } });
    screens.on('change', (n, o) => { try { onChange(n, o); } catch (e) { log(`${n} failed:`, e); } });
    screens.on('show', () => { send({ op: 'get' }); render(); });
    // the user left for the HMI (touched it): leave the host states too, or the HMI would show its empty page
    screens.on('closed', (why) => { if (why !== 'hmi') STATES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
    connect();
    watchController((v) => screens.controller(v), log);
    render();
}

// ---- lifecycle: the shared OnlineApp host (start, tile, shutdown) -----------------------------------------
log('start', process.getuid());
createHost({
    states: STATES,
    log,
    onReady: (rhmiApp) => { startScreens(rhmiApp); log('screens ready'); },
});

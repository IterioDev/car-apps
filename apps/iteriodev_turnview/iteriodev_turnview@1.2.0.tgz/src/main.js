'use strict';
/*
 * oap-turnview ("Turn View"): the control panel of the iteriodev-turnview tool, the front camera in the iDrive 8
 * cluster widget with the next turn drawn on the road (spec docs/superpowers/specs/2026-11-06-turn-view-design.md 3.2,
 * 3.4, 4.3). Everything shown is the tool's: this app talks to it over its control socket (JSON lines, CTL) and shows
 * what it pushes; it sets on / off and the camera calibration (sliders = live previews, Save stores them, leaving the
 * page without Save puts the saved values back: the tool does that on calib off or on a closed socket).
 *   -> { op: 'get' | 'reset' } | { op: 'set', settings: { enabled?, popup?, cal? } } | { op: 'preview', cal } | { op: 'calib', on }
 *      | { op: 'camreq', state }
 *   <- { state: { settings: { enabled, popup, cal: { h, pitch, fov, yaw, x } }, status: { camera, rect, route, provider,
 *        maneuver: { kind, angle, side, exit, text } | null, cr, nav, state, camreq, popup } } }
 * 1.2.0: the pop-up (popupRow: Off = the widget menu, or 500 / 250 / 100 / 50 m: the cluster shows Turn View by itself
 * that far before each turn, user 2026-11-13); the camera request held for the whole route then (camreq.js hold).
 * The app's own job: the camera request (camreq.js, Drive Recorder's functions): the front view asked of the camera
 * ECU while the widget shows it and no other app asks. It runs from the start, with or without a screen: the tool
 * starts this app in the background (hmictl start, no RHMI application: the host never calls onReady then); its
 * state goes to the tool on every change and on each connect; at shutdown the camera is given back.
 *
 * Screens: drawn by the GPU renderer, designed in the HMI UI builder: apps/hmi-ui-builder/projects/turnview.json
 * (scripts/oap-tools/make_turnview_project.js), exported into this folder (rhmiData/ = one empty RHMI host state per
 * screen, renderer/ = screens.json + the builder's runtime). Start, tile and shutdown: the shared OnlineApp host
 * (oap-shared/online-host.js).
 */
const fs = require('fs');
const net = require('net');
const path = require('path');
const util = require('util');
const someipBuilders                   = require('oap-sdk/src/someip/someipBuilders');
const { createHost }                   = require('./online-host.js');
const camreq                           = require('./camreq.js');

const LOG = '[iteriodev_turnview]';
const STATES = ['home', 'calib'];   // screens = their RHMI host states, home the entry
const CTL = process.env.TURNVIEW_CTL || '/run/iteriodev-turnview/ctl.sock';
const RETRY_MS = 2000;

// the linked bundle is javascript/app.js: the package root (next to renderer/) is its parent folder, the app's data
// folder beside that (the Store's)
const SOURCE = typeof __dirname === 'string' ? path.join(__dirname, '..') : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const DATA = path.join(__dirname, '..', '..', 'data');
const LOG_FILE = `${DATA}/turnview.log`;

function log() {
    const line = [new Date().toISOString()].concat([].slice.call(arguments)
        .map((x) => (typeof x === 'string' ? x : util.inspect(x, { depth: 4 }).slice(0, 2000)))).join(' ');
    console.error(LOG, line);
    try { if (fs.statSync(LOG_FILE).size > 256 * 1024) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* no file yet */ }
    try { fs.appendFileSync(LOG_FILE, `${line}\n`); } catch (e) { /* no data folder */ }
}

// ---- the camera request (spec 4.3) ------------------------------------------------------------------------
const cam = camreq.create({ someipBuilders, log });
const sendCamreq = () => send({ op: 'camreq', state: cam.status().state });
cam.on('change', () => { sendCamreq(); render(); });

// ---- the tool ---------------------------------------------------------------------------------------------
let tool = null;                  // its last state, null = no connection
let sock = null;
let busy = false;                 // a connection being made
let calibrating = false;          // the Calibrate page is open: the tool draws the marks, sliders preview
let draft = null;                 // the sliders' values while calibrating (null: the saved ones, from the tool)
let saved = false;                // Save tapped, no slider moved since

function connect() {
    if (sock || busy) return;
    busy = true;
    const s = net.connect(CTL);
    let buf = '';
    s.setEncoding('utf8');
    s.on('connect', () => {
        busy = false; sock = s; log('tool connected');
        sendCamreq();
        // the tool restored the saved values when the old connection closed: the page's again
        if (calibrating) { send({ op: 'calib', on: true }); if (draft) send({ op: 'preview', cal: draft }); }
    });
    s.on('data', (d) => {
        buf += d;
        for (let n; (n = buf.indexOf('\n')) >= 0; buf = buf.slice(n + 1)) {
            let m;
            try { m = JSON.parse(buf.slice(0, n)); } catch (e) { continue; }
            if (m.state) { tool = m.state; holdCam(); }
            render();
        }
    });
    s.on('error', (e) => { if (!/ENOENT|ECONNREFUSED/.test(e.code)) log('tool:', e.message); });
    s.on('close', () => { busy = false; sock = null; tool = null; holdCam(); render(); setTimeout(connect, RETRY_MS); });
}
// the pop-up: the front view asked for the whole route, there before Turn View comes up near a turn (with or without
// screens: the tool starts this app in the background for a route)
function holdCam() {
    const set = tool && tool.settings, st = tool && tool.status;
    cam.hold(!!(set && set.enabled && set.popup && st && st.route !== 'none'));
}
const send = (q) => { if (sock) sock.write(`${JSON.stringify(q)}\n`); };

// ---- screens (the renderer) ----------------------------------------------------------------------------
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
let screens = null;

const NO_TOOL = [['Turn View tool not running', 'crit']];
// the camera line: camcluster's video state as the tool reports it -> [text, colour]
function cameraLine(s, set) {
    switch (s.camera) {
        case 'decoding': return s.rect === 'half' ? ['Pair view (no chevrons)', 'warn'] : ['Front camera', 'ok'];
        case 'waiting': return ['Waiting for the camera', ''];
        case 'idle': return [set.popup ? 'Pop-up not shown yet' : 'Widget not shown in the cluster', ''];
        case 'stalled': return ['Camera busy', 'warn'];
        case 'off': return [!set.enabled ? 'Off' : set.popup && s.route === 'active' ? `Pops up ${set.popup} m before the turn` : 'Off (no route)', ''];
        case 'restarting': return ['Camera tool restarting', 'warn'];
        case 'missing': return ['Camera tool missing', 'crit'];
        default: return [s.camera || '--', ''];
    }
}
const ROUTE = { none: ['No route', ''], active: ['Active', 'ok'], recalculating: ['Recalculating', 'warn'] };
const CR_STATE = { connected: 'Connected', connecting: 'Starting', 'not running': 'Not running', missing: 'Not installed', 'iDrive 8 only': 'iDrive 8 only' };
const SLIDERS = { hRow: 'h', pitchRow: 'pitch', fovRow: 'fov', yawRow: 'yaw', xRow: 'x' };
const POPUP = [0, 500, 250, 100, 50];       // popupRow's items, in order (the tool takes these only)
const cap = (t) => t.charAt(0).toUpperCase() + t.slice(1);

function render() {
    if (!screens) return;
    const t = tool, st = t && t.status, set = t && t.settings;
    // home
    screens.set('homeMenu', !t ? { chips: NO_TOOL, sub: 'Install it from the Store, then restart the head unit' }
        : { chips: [], sub: 'Camera navigation view in the cluster widget' });
    screens.set('enableRow', { on: !t || set.enabled, sub: t && set.popup ? `Shows by itself ${set.popup} m before each turn`
        : 'Pick Turn View in the cluster\'s widget menu' });
    screens.set('popupRow', { sel: Math.max(0, POPUP.indexOf(set ? set.popup : 0)) });
    const camLine = st ? cameraLine(st, set) : ['--', ''];
    screens.set('cameraRow', { text: camLine[0], textColor: camLine[1] });
    const route = st ? (st.nav === 'no navigation data' ? ['No navigation data', 'warn'] : ROUTE[st.route] || [st.route, '']) : ['--', ''];
    screens.set('routeRow', { text: route[0], textColor: route[1],
        sub: st && st.nav === 'no navigation data' ? 'The car sends no guidance: is the navigation running?' : 'Guidance from the car' });
    screens.set('providerRow', { text: (st && st.provider) || '--' });
    const m = st && st.maneuver;
    screens.set('maneuverRow', { text: m ? `${m.text} · ${m.kind}${m.exit ? ` · exit ${m.exit}` : ''}` : st && st.route === 'active' ? 'None ahead' : '--' });
    screens.set('crRow', { text: st ? CR_STATE[st.cr] || st.cr : '--',
        textColor: !st || st.cr === 'connecting' ? '' : st.cr === 'connected' ? 'ok' : 'crit',
        sub: st && st.cr === 'missing' ? 'Install robertnisipeanu/idrive-apps 0.4.1 or newer' : 'robertnisipeanu/idrive-apps, 0.4.1 or newer',
        subColor: st && st.cr === 'missing' ? 'warn' : '' });
    const cs = cam.status();
    screens.set('camreqRow', { text: cap(cs.text), textColor: cs.state === 'on' ? 'ok' : cs.state === 'refused' || cs.state === 'rearonly' ? 'crit' : cs.state === 'asked' ? 'warn' : '' });
    // calib: the sliders show the draft (the saved values until one moves)
    if (calibrating && !draft && set) draft = Object.assign({}, set.cal);
    screens.set('calibMenu', { chips: !t ? NO_TOOL : saved ? [['Saved', 'ok']] : [] });
    if (draft) Object.keys(SLIDERS).forEach((row) => { if (typeof draft[SLIDERS[row]] === 'number') screens.set(row, { value: draft[SLIDERS[row]] }); });
}

// ---- what the user does ---------------------------------------------------------------------------------
function startCalib() {
    if (calibrating) return;
    calibrating = true; draft = null; saved = false;
    send({ op: 'calib', on: true });
    render();
}
// leaving the page (Back, the HMI's BACK, another screen, the app closed): the tool puts the saved values back
function leaveCalib() {
    if (!calibrating) return;
    calibrating = false; draft = null; saved = false;
    send({ op: 'calib', on: false });
}
const EVENTS = {
    calibrate: () => { startCalib(); showScreen('calib'); },
    save: () => { const cal = draft || (tool && tool.settings.cal); if (cal) { send({ op: 'set', settings: { cal } }); saved = true; render(); } },
    reset: () => { send({ op: 'reset' }); draft = null; saved = false; },    // the tool pushes the defaults: the sliders follow
};
function onEvent(name) { if (EVENTS[name]) EVENTS[name](); }
function onChange(name, o) {
    if (name === 'enableRow') return send({ op: 'set', settings: { enabled: !!o.on } });
    if (name === 'popupRow' && POPUP[o.sel] !== undefined) return send({ op: 'set', settings: { popup: POPUP[o.sel] } });
    if (SLIDERS[name] && typeof o.value === 'number') {
        draft = Object.assign({}, draft || (tool && tool.settings.cal));
        draft[SLIDERS[name]] = o.value;
        saved = false;
        send({ op: 'preview', cal: draft });
        return render();
    }
    // the one tab (Status): from the Calibrate page it goes back home
    if (name === 'calibMenu') { screens.set(name, { sel: 0 }); closeScreen('calib'); }
    return null;
}

// ---- RHMI: the host states (the shared OnlineApp host hands over the RHMI application) -------------------
let app = null;
const comp = (n) => app.getByName(n);
function showScreen(name) {
    return comp(name).updateResources().then(() => app.openState(name))
        .then(() => log(`opened ${name}`))
        .catch((e) => log(`open ${name} failed:`, e));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed:`, e));

function startScreens(rhmiApp) {
    app = rhmiApp;
    const design = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: (m) => log(m), warn: (m) => log(m), error: (m) => log(m) };
    const gpu = new RenderClient('iteriodev_turnview', rlog);
    screens = new ScreenApp(gpu, design, { view: 'id8', log: rlog });
    const hosts = {};
    STATES.forEach((s) => { hosts[s] = comp(s); });
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('event', (n) => { try { onEvent(n); } catch (e) { log(`${n} failed:`, e); } });
    screens.on('change', (n, o) => { try { onChange(n, o); } catch (e) { log(`${n} failed:`, e); } });
    screens.on('show', (name) => { if (name === 'calib') startCalib(); else leaveCalib(); render(); });
    // the user left for the HMI (touched it): leave the host states too, or the HMI would show its empty page
    screens.on('closed', (why) => { leaveCalib(); if (why !== 'hmi') STATES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
    render();
}

// ---- lifecycle: the camera request and the tool from the start; the screens when the host hands them over --
log('start', process.getuid());
cam.start();
connect();
createHost({
    states: STATES,
    log,
    onReady: (rhmiApp) => { startScreens(rhmiApp); log('screens ready'); },
    // give the camera back first (an attached indirect client stays in icam2proxy otherwise), at most 2 s
    onShutdown: () => Promise.race([cam.release(), new Promise((r) => setTimeout(r, 2000))]),
});

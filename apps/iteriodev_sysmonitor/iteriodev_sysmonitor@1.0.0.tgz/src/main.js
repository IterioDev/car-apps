'use strict';
/*
 * oap-sysmonitor ("System Monitor", iteriodev_sysmonitor): a read-only activity monitor for the head unit - what uses its
 * memory and processor, from /proc and /sys only (javascript/sysdata.js; the pages: javascript/views.js). It writes
 * nothing but its own settings, reads no car signals but the iDrive controller (FrontCCU), needs no internet.
 * Original app by hexlay (iDrive 7 System Monitor, GPL-3.0) - this iDrive 8 variant by IterioDev, written fresh.
 *
 * Screens: drawn by the GPU renderer, designed in the HMI UI builder: apps/hmi-ui-builder/projects/sysmonitor.json
 * (scripts/oap-tools/make_sysmonitor_project.js), exported into this folder (rhmiData/ = an empty RHMI host state per
 * screen, renderer/ = screens.json + the builder's runtime). The tabs Overview | Processor | Processes | Settings are
 * host states (Overview the entry, the others opened over it); Details is opened over Processes by a row tapped (Back).
 * Read only while a screen shows, every 1 / 2 / 5 / 10 s (Settings); closed or hidden: stopped, the 3 minutes dropped.
 * Start, tile and shutdown: the shared OnlineApp host (oap-shared/online-host.js).
 */
const fs = require('fs');
const path = require('path');
const util = require('util');
const { createHost }                   = require('./online-host.js');
const { watchController }              = require('./frontccu.js');
const sysdata                          = require('./sysdata.js');
const views                            = require('./views.js');

const LOG = '[iteriodev_sysmonitor]';
const PAGES = ['overview', 'processor', 'processes', 'settings'];   // the tabs in order, each frame <page>Menu
const STATES = PAGES.concat(['details']);                           // the RHMI host states, the entry first
const EVERY = [1, 2, 5, 10];                                        // Settings: read every ... s
const SPEED = +process.env.SYSMON_SPEED || 1;                       // tests: the clock runs this much faster
const P = sysdata.paths(process.env.SYSMON_ROOT);                   // tests: a fake /proc + /sys tree

// the linked bundle is javascript/app.js: the package root is one up, the app's data folder beside it (the Store's)
const SOURCE = typeof __dirname === 'string' ? path.join(__dirname, '..') : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const DATA = process.env.SYSMON_DATA || path.join(__dirname, '..', '..', 'data');   // (tests: a folder of their own)
const LOG_FILE = `${DATA}/sysmonitor.log`;
const SETTINGS_FILE = `${DATA}/settings.json`;

function log() {
    const line = [new Date().toISOString()].concat([].slice.call(arguments)
        .map((x) => (typeof x === 'string' ? x : util.inspect(x, { depth: 4 }).slice(0, 2000)))).join(' ');
    console.error(LOG, line);
    try { if (fs.statSync(LOG_FILE).size > 256 * 1024) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* no file yet */ }
    try { fs.appendFileSync(LOG_FILE, `${line}\n`); } catch (e) { /* no data folder */ }
}

// ---- settings: data/settings.json { group: one row per app, every: s } -------------------------------------------
let settings = { group: true, every: 2 };
try {
    const f = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'));
    settings = { group: f.group !== false, every: EVERY.indexOf(f.every) >= 0 ? f.every : 2 };
} catch (e) { /* defaults */ }
function saveSettings() {
    try { fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings)); } catch (e) { log('settings not saved:', e); }
}

// ---- the screens (the renderer) -----------------------------------------------------------------------------------
// renderer/ is the builder's export: screens.json + its runtime, loaded with a computed path (plain files in the package)
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
const DESIGN = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
/** the rows a table of the design shows (under its 50 px heading) */
function rowsOf(name) {
    const c = [].concat.apply([], DESIGN.screens.map((s) => s.components)).filter((x) => x.name === name)[0];
    return Math.floor((c.h - 50) / c.opts.rowH);
}
const TOP_ROWS = { ovTop: rowsOf('ovTop'), cpuTop: rowsOf('cpuTop') };
let screens = null;

// ---- readings: only while a screen shows --------------------------------------------------------------------------
const names = new sysdata.Names(P);
const mon = new sysdata.Monitor();
const t0 = Date.now();
let snap = null, timer = null, told = {};
let sort = { col: 2, rev: false }, keys = [], detail = null;    // Processes: sorted by, its rows' keys as drawn; Details: its key
const once = (k, text) => { if (!told[k]) { told[k] = true; log(text); } };

function sample() {
    const r = sysdata.read(P);
    r.t = t0 + (r.t - t0) * SPEED;
    snap = mon.add(r, names);
    if (snap.temp == null) once('temp', 'no temperature sensor readable (/sys/class/thermal, /sys/class/hwmon)');
    if (snap.hidepid) once('hidepid', `/proc is mounted with hidepid: ${snap.count} processes visible`);
    render();
}
const shown = () => screens && screens.st && !screens.paused;
function start() {
    if (timer) return;
    try { sample(); } catch (e) { log('read failed:', e); }
    timer = setInterval(() => { if (shown()) { try { sample(); } catch (e) { log('read failed:', e); } } }, settings.every * 1000 / SPEED);
}
function stop() {                     // the screens gone: nothing read, the history dropped
    clearInterval(timer);
    timer = null; snap = null; keys = [];
    mon.clear();
}

const setAll = (v) => Object.keys(v).forEach((n) => screens.set(n, v[n]));
function render() {
    if (!screens || !screens.st) return;
    const pg = screens.st.name;
    if (pg === 'settings') { screens.set('group', { on: settings.group }).set('everySeg', { sel: EVERY.indexOf(settings.every) }); return; }
    if (!snap) return;
    if (pg === 'overview') setAll(views.overview(snap, { group: settings.group, rows: TOP_ROWS.ovTop }));
    if (pg === 'processor') setAll(views.processor(snap, { group: settings.group, rows: TOP_ROWS.cpuTop }));
    if (pg === 'processes') { const p = views.processes(snap, { group: settings.group, sort }); keys = p.keys; setAll(p.view); }
    if (pg === 'details') setAll(views.details(snap, detail));
}

// the tabs: Overview is the app's first screen, the others open over it; Details over Processes
function goTo(to) {
    const cur = screens.st && screens.st.name;
    if (!to || !cur || to === cur) return;
    const over = cur === 'details' ? ['details', 'processes'] : cur === 'overview' ? [] : [cur];   // the screens over Overview
    over.filter((s) => s !== to).forEach(closeScreen);
    if (to !== 'overview' && over.indexOf(to) < 0) showScreen(to);
}
function onChange(name, o) {
    if (name === 'group') { settings.group = !!o.on; saveSettings(); screens.set('list', { top: 0 }); return; }
    if (name === 'everySeg') {
        settings.every = EVERY[o.sel] || 2; saveSettings();
        if (timer) { clearInterval(timer); timer = null; start(); }
        return;
    }
    const from = name.replace(/Menu$/, '');
    if (from === name || STATES.indexOf(from) < 0) return;
    const to = PAGES[o.sel];                                          // (o is the element's opts: read before the set)
    screens.set(name, { sel: from === 'details' ? 2 : PAGES.indexOf(from) });   // this page's frame keeps its own tab
    goTo(to);
}
// Processes: a heading tapped sorts by it (again: the other way), a row tapped opens its details
function onEvent(e) {
    const m = /^list:(head|row)(\d+)$/.exec(e);
    if (!m) return;
    if (m[1] === 'head') {
        const col = +m[2];
        sort = { col, rev: sort.col === col ? !sort.rev : false };
        screens.set('list', { top: 0 });
        render();
        return;
    }
    if (!keys[+m[2]]) return;
    detail = keys[+m[2]];
    showScreen('details');
}

// ---- RHMI: the host states (the OnlineApp host hands them over) ---------------------------------------------------
let app = null;
function showScreen(name) {
    return app.getByName(name).updateResources().then(() => app.openState(name))
        .then(() => log(`opened ${name}`))
        .catch((e) => log(`open ${name} failed:`, e));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed:`, e));

function startScreens(rhmiApp, hosts) {
    app = rhmiApp;
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: (m) => log(m), warn: (m) => log(m), error: (m) => log(m) };
    const gpu = new RenderClient('iteriodev_sysmonitor', rlog);
    screens = new ScreenApp(gpu, DESIGN, { view: 'id8', log: rlog });
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('show', () => { start(); render(); });                // its values in its first frame
    // the app back from the background with its screen still up (no new 'show'): reading again
    STATES.forEach((s) => hosts[s].on('visible', (ev) => { const v = ev && ev.visible; if ((v === true || v === 'true' || v === 1) && screens.st) start(); }));
    screens.on('change', (n, o) => { try { onChange(n, o); } catch (e) { log(`${n} failed:`, e); } });
    screens.on('event', (n) => { try { onEvent(n); } catch (e) { log(`${n} failed:`, e); } });
    // the user left for the HMI (touched it): leave the host states too, or the HMI would show their empty pages
    screens.on('closed', (why) => { stop(); if (why !== 'hmi') STATES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
    watchController((v) => screens.controller(v), log);            // the iDrive controller (cars without a touchscreen)
}

// ---- lifecycle: the shared OnlineApp host (start, tile -> Overview, shutdown) ---------------------------------------
log('start', process.getuid());
createHost({
    states: STATES,
    log,
    onReady: (rhmiApp, hosts) => { startScreens(rhmiApp, hosts); log('screens ready'); },
    onHidden: stop,
});

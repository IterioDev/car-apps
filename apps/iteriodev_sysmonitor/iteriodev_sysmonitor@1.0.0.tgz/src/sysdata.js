'use strict';
/*
 * sysdata.js - what uses the head unit's memory and processor, read from the kernel's own files (read-only; Node 8, no
 * dependencies). IterioDev's System Monitor; a remake of hexlay's iDrive 7 System Monitor (GPL-3.0), written fresh:
 * only the facts of which files hold the data were learned from it.
 *
 *   const P = paths(process.env.SYSMON_ROOT)    // '/proc', '/sys', ... (under a fake tree in the tests)
 *   const names = new Names(P)                  // uid -> the app it is (null: a program, named by its process)
 *   const mon = new Monitor()
 *   const s = mon.add(read(P), names)           // the numbers the pages show; mon.clear() drops the history
 *
 * Memory: a process's own memory is its private memory (RssAnon: heap, stacks, its buffers) - what it adds to the RAM
 * in use. The program and library files it maps (RssFile, RssShmem) are shared with every process mapping them: added up
 * they would count the same file many times, so they show in its details only ("shared files").
 * Which app a process is: every iDrive app (OAP app) runs as its own uid, installed in /var/opt/public/oap/oap_<uid>;
 * MainApp is 12201. Its title, from what an app may read: the app's package.json (only where readable: the folders are
 * 750), apps the MGU Store installed by their id in /var/opt/mgu-deploy/state.json (0644, apps { id: { uid } }), the
 * Store's tools by /var/opt/mgu-uplink/uids.d/<tool> (their uids); else "iDrive app <uid>" (BMW's own apps).
 * /proc mounted with hidepid shows an app only its own processes: then that is all there is (s.hidepid).
 */
const fs = require('fs');
const path = require('path');

const KB = 1024;
const HZ = 100;               // ponytail: USER_HZ of x86 Linux for /proc/<pid>/stat start times (Node has no sysconf)
const KEEP_MS = 180000;       // the history: 3 minutes
const NEW_MS = 30000;         // a row's growth is shown once it was seen this long
const MAINAPP_UID = 12201;

/** the files read, under root ('' on the car) */
function paths(root) {
    const r = root || '';
    return { proc: `${r}/proc`, sys: `${r}/sys`, oap: `${r}/var/opt/public/oap`, deploy: `${r}/var/opt/mgu-deploy/state.json`,
        uplink: `${r}/var/opt/mgu-uplink/uids.d` };
}
const readText = (f) => { try { return fs.readFileSync(f, 'utf8'); } catch (e) { return null; } };
const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return null; } };
const dir = (d) => { try { return fs.readdirSync(d); } catch (e) { return []; } };

// ---- the parsers (pure: text in) -----------------------------------------------------------------------------------
/** "Key:  value" lines -> { Key: 'value' } */
function fields(text) {
    const o = {};
    String(text || '').split('\n').forEach((l) => { const i = l.indexOf(':'); if (i > 0) o[l.slice(0, i).trim()] = l.slice(i + 1).trim(); });
    return o;
}
const kb = (v) => (v == null ? null : parseInt(v, 10) * KB);

/** /proc/meminfo -> { total, avail, swapTotal, swapFree } in bytes, or null */
function meminfo(text) {
    const f = fields(text), total = kb(f.MemTotal);
    if (!(total > 0)) return null;
    const avail = f.MemAvailable != null ? kb(f.MemAvailable) : kb(f.MemFree) + (kb(f.Buffers) || 0) + (kb(f.Cached) || 0);
    return { total, avail, swapTotal: kb(f.SwapTotal) || 0, swapFree: kb(f.SwapFree) || 0 };
}

/** /proc/stat -> { all, cores }: each [user, nice, system, idle, iowait, irq, softirq, steal] in ticks since boot; or null */
function cpuStat(text) {
    let all = null;
    const cores = [];
    String(text || '').split('\n').forEach((l) => {
        const m = /^cpu(\d*)\s+(.*)$/.exec(l);
        if (!m) return;
        const v = m[2].trim().split(/\s+/).slice(0, 8).map(Number);
        while (v.length < 8) v.push(0);
        if (m[1] === '') all = v; else cores.push(v);
    });
    return all ? { all, cores } : null;
}

/** two cpuStat lines -> shares of the time between them (0-100): busy, programs (user), system, waiting on storage */
function usage(a, b) {
    const d = b.map((x, i) => Math.max(0, x - (a[i] || 0))), ticks = d.reduce((s, x) => s + x, 0);
    if (!ticks) return null;
    const pct = (x) => 100 * x / ticks;
    return { busy: pct(ticks - d[3] - d[4]), user: pct(d[0] + d[1]), system: pct(d[2] + d[5] + d[6] + d[7]), iowait: pct(d[4]), ticks };
}

/** /proc/loadavg "0.52 0.58 0.59 3/612 12345" -> { l1, l5, l15, running, threads }, or null */
function loadavg(text) {
    const f = String(text || '').trim().split(/\s+/), rt = (f[3] || '').split('/');
    return f.length >= 4 ? { l1: +f[0], l5: +f[1], l15: +f[2], running: +rt[0], threads: +rt[1] } : null;
}

/** /proc/<pid>/stat -> { ticks: user + system time, start: since boot } (clock ticks); the name in () may hold anything */
function procStat(text) {
    const s = String(text || ''), i = s.lastIndexOf(')');
    if (i < 0) return null;
    const f = s.slice(i + 2).split(' ');               // f[0] is field 3 (state): field n at n - 3
    return { ticks: (+f[11] || 0) + (+f[12] || 0), start: +f[19] || 0 };
}

/** /proc/<pid>/status -> { name, uid, rss, anon, file, shm, swap, threads } (bytes; rss null: a kernel thread), or null */
function procStatus(text) {
    const f = fields(text);
    if (f.Name == null) return null;
    return { name: f.Name, uid: parseInt(f.Uid, 10), rss: kb(f.VmRSS), anon: kb(f.RssAnon), file: kb(f.RssFile) || 0,
        shm: kb(f.RssShmem) || 0, swap: kb(f.VmSwap) || 0, threads: parseInt(f.Threads, 10) || 0 };
}

/** /proc/mounts: /proc mounted with hidepid (an app sees only its own processes) */
const hidepid = (text) => String(text || '').split('\n').some((l) => {
    const f = l.split(' ');
    return f[2] === 'proc' && f[1] === '/proc' && /(^|,)hidepid=(1|2|invisible|noaccess)(,|$)/.test(f[3] || '');
});

// ---- the sensors (/sys) --------------------------------------------------------------------------------------------
/** the processor's temperature in °C: its package / core sensors, else the warmest readable one; null = none readable */
function temperature(sys) {
    const got = [];
    const add = (milli, cpu) => { const c = parseInt(milli, 10) / 1000; if (c > 0 && c < 150) got.push({ c, cpu }); };
    const tz = `${sys}/class/thermal`;
    dir(tz).filter((n) => /^thermal_zone\d+$/.test(n)).forEach((n) => {
        const t = readText(`${tz}/${n}/temp`);
        if (t != null) add(t, /x86_pkg|cpu|core|soc/i.test(readText(`${tz}/${n}/type`) || ''));
    });
    const hw = `${sys}/class/hwmon`;
    dir(hw).forEach((n) => {
        const cpu = /coretemp|k10temp|cpu/i.test(readText(`${hw}/${n}/name`) || '');
        dir(`${hw}/${n}`).filter((f) => /^temp\d+_input$/.test(f)).forEach((f) => {
            const t = readText(`${hw}/${n}/${f}`);
            if (t != null) add(t, cpu);
        });
    });
    const pick = got.some((g) => g.cpu) ? got.filter((g) => g.cpu) : got;
    return pick.length ? Math.max.apply(null, pick.map((g) => g.c)) : null;
}

/** the cores' clock: { ghz (their average now), max (GHz) }, or null */
function clock(sys) {
    const d = `${sys}/devices/system/cpu`, cur = [], max = [];
    dir(d).filter((n) => /^cpu\d+$/.test(n)).forEach((n) => {
        const c = parseInt(readText(`${d}/${n}/cpufreq/scaling_cur_freq`), 10), m = parseInt(readText(`${d}/${n}/cpufreq/cpuinfo_max_freq`), 10);
        if (c > 0) cur.push(c);
        if (m > 0) max.push(m);
    });
    if (!cur.length) return null;
    return { ghz: cur.reduce((a, b) => a + b, 0) / cur.length / 1e6, max: max.length ? Math.max.apply(null, max) / 1e6 : null };
}

// ---- one reading ---------------------------------------------------------------------------------------------------
/** every process with memory of its own (kernel threads have none: left out) */
function processes(proc) {
    const out = [];
    dir(proc).forEach((n) => {
        if (!/^\d+$/.test(n)) return;
        const st = procStatus(readText(`${proc}/${n}/status`));
        if (!st || st.rss == null) return;                // gone meanwhile, or a kernel thread
        const s = procStat(readText(`${proc}/${n}/stat`)) || { ticks: 0, start: 0 };
        const argv0 = (readText(`${proc}/${n}/cmdline`) || '').split('\0')[0];
        out.push(Object.assign(st, { pid: +n, ticks: s.ticks, start: s.start, program: argv0 ? path.posix.basename(argv0) : st.name,
            own: st.anon != null ? st.anon : st.rss }));    // (no RssAnon before kernel 4.5: the resident size)
    });
    return out;
}

function read(P) {
    return { t: Date.now(), mem: meminfo(readText(`${P.proc}/meminfo`)), cpu: cpuStat(readText(`${P.proc}/stat`)),
        load: loadavg(readText(`${P.proc}/loadavg`)), up: parseFloat(readText(`${P.proc}/uptime`)) || null,
        hidepid: hidepid(readText(`${P.proc}/mounts`)), temp: temperature(P.sys), clock: clock(P.sys), procs: processes(P.proc) };
}

// ---- which app a uid is --------------------------------------------------------------------------------------------
/** 'iteriodev_car_data' -> 'Car Data' (an id's words; MGU in capitals) */
const title = (id) => String(id).replace(/^(iteriodev|robertn)[_-]/, '').split(/[_-]+/).filter(Boolean)
    .map((w) => (/^mgu$/i.test(w) ? 'MGU' : w[0].toUpperCase() + w.slice(1))).join(' ');

class Names {
    constructor(P) { this.P = P; this.stamp = null; this.cache = {}; this.store = {}; this.tools = {}; }
    /** the Store's records read again when they changed (an app installed meanwhile) */
    refresh() {
        let stamp = dir(this.P.uplink).join(',');
        try { stamp += fs.statSync(this.P.deploy).mtime.getTime(); } catch (e) { /* no Store */ }
        if (stamp === this.stamp) return;
        this.stamp = stamp; this.cache = {}; this.store = {}; this.tools = {};
        const apps = (readJson(this.P.deploy) || {}).apps || {};
        Object.keys(apps).forEach((id) => { const u = Number(apps[id] && apps[id].uid); if (u > 0) this.store[u] = id; });
        dir(this.P.uplink).forEach((id) => (readText(`${this.P.uplink}/${id}`) || '').split(/\s+/).map(Number)
            .filter((u) => u > 0).forEach((u) => { this.tools[u] = id; }));
    }
    /** uid -> { name, kind: 'app' | 'tool', store (installed by the MGU Store) }, or null: not an app (a program) */
    of(uid) {
        if (!(uid in this.cache)) this.cache[uid] = this.look(uid);
        return this.cache[uid];
    }
    look(uid) {
        const app = (name, store) => ({ name, kind: 'app', store });
        if (uid === MAINAPP_UID) return app('MainApp', false);
        const home = `${this.P.oap}/oap_${uid}`, pkg = readJson(`${home}/source/package.json`);
        const own = pkg && (pkg.productName || pkg.name);     // readable: this app's own, or with MainApp's rights
        if (this.store[uid]) return app(own || title(this.store[uid]), true);
        if (this.tools[uid]) return { name: title(this.tools[uid]), kind: 'tool', store: true };
        if (own) return app(own, false);
        try { if (fs.statSync(home).isDirectory()) return app(`iDrive app ${uid}`, false); } catch (e) { /* not an app */ }
        return null;
    }
}

// ---- the history and what the pages show ---------------------------------------------------------------------------
/** processes added up: one row (an app, a program by name, or one process) */
function row(key, name, app, procs) {
    const s = (k) => procs.reduce((a, x) => a + (x[k] || 0), 0), cpus = procs.filter((x) => x.cpu != null);
    const first = procs.reduce((a, x) => (x.start < a.start ? x : a), procs[0]);
    return { key, name, app, uid: procs[0].uid, pids: procs.map((x) => x.pid).sort((a, b) => a - b), n: procs.length, mem: s('own'),
        shared: s('file') + s('shm'), swap: s('swap'), threads: s('threads'), cpu: cpus.length ? cpus.reduce((a, x) => a + x.cpu, 0) : null,
        start: first.start, program: first.program };
}

class Monitor {
    constructor() { this.clear(); }
    /** forget everything (the screens closed: the next show starts afresh) */
    clear() { this.last = null; this.hist = {}; this.since = {}; this.series = []; }

    /**
     * A reading in -> { t, mem, used (%), cpu (usage or null: the first reading), cores, load, up, temp, clock, hidepid,
     * count, apps / other (own memory of iDrive apps / everything else, bytes), groups (a row per app or program name),
     * singles (a row per process), series [{ t, mem %, cpu % }] }; each row with its growth over the last 3 min.
     */
    add(r, names) {
        const prev = this.last, t = r.t;
        this.last = r;
        const pc = prev && prev.cpu, cpu = pc && r.cpu ? usage(pc.all, r.cpu.all) : null;
        const cores = r.cpu ? r.cpu.cores.map((c, i) => (pc && pc.cores[i] ? usage(pc.cores[i], c) : null)) : [];
        const before = {};
        if (prev) prev.procs.forEach((x) => { before[x.pid] = x; });
        names.refresh();
        const groups = {}, singles = [];
        let apps = 0, other = 0;
        r.procs.forEach((x) => {
            const b = before[x.pid];   // its share of all cores' time since the reading before (one started since: from then)
            x.cpu = cpu && b && b.start === x.start ? Math.min(100, 100 * Math.max(0, x.ticks - b.ticks) / cpu.ticks) : null;
            x.app = names.of(x.uid);
            if (x.app && x.app.kind === 'app') apps += x.own; else other += x.own;
            const key = x.app ? `u${x.uid}` : `n${x.name}`;
            (groups[key] = groups[key] || { name: x.app ? x.app.name : x.name, app: x.app, procs: [] }).procs.push(x);
            singles.push(row(`p${x.pid}`, x.app ? x.app.name : x.name, x.app, [x]));
        });
        const rows = Object.keys(groups).map((k) => row(k, groups[k].name, groups[k].app, groups[k].procs));
        // each row's memory over the last 3 min (the rows gone: dropped); its growth once seen 30 s
        const live = {};
        rows.concat(singles).forEach((w) => {
            live[w.key] = true;
            const h = this.hist[w.key] = (this.hist[w.key] || []).filter((p) => t - p[0] <= KEEP_MS);
            h.push([t, w.mem]);
            if (this.since[w.key] == null) this.since[w.key] = t;
            w.growth = t - this.since[w.key] >= NEW_MS ? w.mem - h[0][1] : null;
            w.hist = h.map((p) => p[1]);
        });
        Object.keys(this.hist).forEach((k) => { if (!live[k]) { delete this.hist[k]; delete this.since[k]; } });
        const used = r.mem ? 100 * (r.mem.total - r.mem.avail) / r.mem.total : null;
        this.series = this.series.filter((p) => t - p.t <= KEEP_MS).concat([{ t, mem: used, cpu: cpu ? cpu.busy : null }]);
        return { t, mem: r.mem, used, cpu, cores, load: r.load, up: r.up, temp: r.temp, clock: r.clock, hidepid: r.hidepid,
            count: r.procs.length, apps, other, groups: rows, singles, series: this.series.slice() };
    }
}

module.exports = { paths, read, Names, Monitor, meminfo, cpuStat, usage, loadavg, procStat, procStatus, hidepid, temperature, clock,
    title, HZ, KEEP_MS, NEW_MS };

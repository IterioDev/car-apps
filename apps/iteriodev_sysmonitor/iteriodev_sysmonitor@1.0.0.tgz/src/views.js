'use strict';
/*
 * views.js - System Monitor's pages from a sysdata.Monitor snapshot: { element name: the opts ScreenApp.set gives it }
 * (pure, Node 8). The names are the design's: scripts/oap-tools/make_sysmonitor_project.js checks each exists.
 */
const { HZ } = require('./sysdata.js');

const MB = 1024 * 1024;
const GB = 1024 * MB;
const SORTS = ['name', 'processes', 'memory', 'memory', 'last 3 min', 'processor'];   // Processes: by its columns

/** 974 MB, 72.5 MB, 1.21 GB */
const mb = (b) => { const v = b / MB; return v >= 1000 ? `${(v / 1024).toFixed(2)} GB` : v >= 100 ? `${Math.round(v)} MB` : `${v.toFixed(1)} MB`; };
const mbNum = (b) => { const v = b / MB; return v >= 100 ? String(Math.round(v)) : v.toFixed(1); };
/** 16 %, 2.2 %; no value: -- */
const pct = (x) => (x == null || !isFinite(x) ? '--' : x >= 10 ? `${Math.round(x)} %` : `${x.toFixed(1)} %`);
/** growth over 3 min as a table cell [text, colour]: -- (not seen 30 s yet), 0 (under 1 MB), +3.0 MB; 10 MB amber, 50 MB red */
function growth(b) {
    if (b == null) return ['--', ''];
    if (Math.abs(b) < MB) return ['0', ''];
    return [`${b > 0 ? '+' : '-'}${mb(Math.abs(b))}`, b >= 50 * MB ? 'crit' : b >= 10 * MB ? 'warn' : ''];
}
const name = (w) => (w.app && w.app.store ? `${w.name} · Store` : w.name);
/** 3 h 20 min, 12 min, 40 s */
function span(sec) {
    const m = Math.floor(sec / 60), h = Math.floor(m / 60);
    return h ? `${h} h ${m % 60} min` : m ? `${m} min` : `${Math.max(0, Math.floor(sec))} s`;
}
const note = (s) => (s.hidepid ? [['Some processes hidden', 'dim']] : []);   // the head unit shows an app only its own
const rowsOf = (s, group) => (group ? s.groups : s.singles);

function overview(s, o) {
    const m = s.mem, list = rowsOf(s, o.group).slice().sort((a, b) => b.mem - a.mem);
    const gb = m ? m.total / GB : 6, val = (v) => +v.toFixed(1);
    const mem = s.series.filter((p) => p.mem != null).map((p) => val(p.mem)), cpu = s.series.filter((p) => p.cpu != null).map((p) => val(p.cpu));
    const swap = m && m.swapTotal > 0 ? ` · swap ${mb(m.swapTotal - m.swapFree)}` : '';
    return {
        overviewMenu: { chips: note(s) },
        ovMem: { value: s.used },
        ovApps: { value: s.apps / MB, max: gb * 1024 },
        ovOther: { value: s.other / GB, max: gb },
        ovAvail: { value: m ? m.avail / GB : null, max: gb },
        ovCpu: { value: s.cpu ? s.cpu.busy : null },
        ovTop: { rows: list.slice(0, o.rows).map((w) => [name(w), growth(w.growth), mb(w.mem)]) },
        ovTrend: { value: s.used == null ? '--' : String(Math.round(s.used)), points: mem, points2: cpu,
            foot: `${s.count} processes · ${s.cores.length} cores${s.up ? ` · up ${span(s.up)}` : ''}${swap}` },
    };
}

function processor(s, o) {
    const c = s.cpu, l = s.load, k = s.clock, n = s.cores.length;
    const list = rowsOf(s, o.group).filter((w) => w.cpu != null).sort((a, b) => b.cpu - a.cpu || b.mem - a.mem);
    const v = {
        processorMenu: { sub: `${n} cores · Intel Apollo Lake`, chips: note(s) },
        cpuTotal: { value: c ? c.busy : null },
        cpuLoad: { value: l ? l.l1 : null, max: Math.max(1, n), label: l ? `Load · 15 min ${l.l15.toFixed(2)}` : 'Load' },
        cpuTemp: { value: s.temp },
        cpuClock: { value: k ? k.ghz : null, max: k && k.max ? k.max : 2.4, label: k && k.max ? `Clock · max ${k.max.toFixed(1)}` : 'Clock' },
        cpuThreads: { value: l ? l.threads : null, max: l ? Math.max(500, Math.ceil((l.threads + 1) / 500) * 500) : 1000,
            label: l ? `Threads · ${l.running} running` : 'Threads' },
        cpuSplit: { rows: [['Programs', pct(c && c.user)], ['System', pct(c && c.system)],
            ['Waiting on storage', pct(c && c.iowait), c && c.iowait >= 1 ? 'warn' : '']] },
        cpuTop: { rows: list.slice(0, o.rows).map((w) => [name(w), pct(w.cpu)]) },
    };
    for (let i = 0; i < 4; i++) {
        const u = s.cores[i];
        v[`core${i}`] = { hidden: i >= n, label: `Core ${i + 1}`, right: pct(u && u.busy), value: u ? u.busy / 100 : 0 };
    }
    return v;
}

/** sort: { col (the column), rev (the other way) } - the name A to Z first, the numbers largest first */
function sorted(list, sort, group) {
    const by = [(w) => w.name.toLowerCase(), (w) => (group ? w.n : w.pids[0]), (w) => w.mem, (w) => w.mem,
        (w) => (w.growth == null ? -Infinity : w.growth), (w) => (w.cpu == null ? -1 : w.cpu)][sort.col] || ((w) => w.mem);
    const d = (sort.col === 0 ? 1 : -1) * (sort.rev ? -1 : 1);
    return list.slice().sort((a, b) => { const x = by(a), y = by(b); return x < y ? -d : x > y ? d : b.mem - a.mem; });
}
/** -> { view, keys: each row's key, in the rows' order (a row tapped: its details) } */
function processes(s, o) {
    const list = sorted(rowsOf(s, o.group), o.sort, o.group), tot = s.mem ? s.mem.total : 0, col = o.sort.col;
    const by = col === 1 && !o.group ? 'PID' : SORTS[col] || 'memory', rev = o.sort.rev ? (col === 0 ? ' · Z to A' : ' · smallest first') : '';
    return { keys: list.map((w) => w.key), view: {
        processesMenu: { chips: [[`Sorted by ${by}${rev}`, 'accent']].concat(note(s)) },
        list: { columns: `Apps and programs · ${list.length}:2.6, ${o.group ? 'Processes' : 'PID'}:0.8:right, Memory:1:right, % of RAM:0.9:right, ` +
            'Last 3 min:1:right, Processor:0.9:right',
        rows: list.map((w) => [name(w), String(o.group ? w.n : w.pids[0]), mb(w.mem), pct(tot ? 100 * w.mem / tot : null), growth(w.growth), pct(w.cpu)]) },
    } };
}

const KIND = (w) => (!w.app ? 'Program' : w.app.kind === 'tool' ? 'MGU Store tool' : w.app.store ? 'MGU Store app' : 'iDrive app');
/** one row's details (key: a row of either kind); gone meanwhile: says so, its numbers -- */
function details(s, key) {
    const w = s.groups.concat(s.singles).filter((x) => x.key === key)[0];
    if (!w) {
        return { detailsMenu: { chips: [['Ended', 'dim']].concat(note(s)) }, detMem: { value: null }, detPct: { value: null },
            detGrow: { value: null }, detCpu: { value: null }, detTrend: { value: '--', foot: 'It is no longer running.' } };
    }
    const tot = s.mem ? s.mem.total : 0, g = w.growth, h = w.hist.map((b) => +(b / MB).toFixed(1));
    const lo = Math.min.apply(null, h), hi = Math.max.apply(null, h), pad = Math.max(1, (hi - lo) * 0.15);
    const range = `min ${mbNum(lo * MB)} · max ${mbNum(hi * MB)}`;
    const foot = g == null ? `measuring · ${range}` : Math.abs(g) < MB ? `no change in 3 min · ${range}`
        : `${g > 0 ? 'grew' : 'shrank'} ${mb(Math.abs(g))} in 3 min · ${range}`;
    const pids = w.pids.slice(0, 4).join(', ') + (w.n > 4 ? ` +${w.n - 4}` : '');
    return {
        detailsMenu: { title: w.name, sub: `${KIND(w)} · uid ${w.uid} · ${w.n} process${w.n === 1 ? '' : 'es'}`, chips: note(s) },
        detMem: { value: w.mem / MB, dec: w.mem >= 100 * MB ? 0 : 1, max: tot ? tot / MB : 6144 },
        detPct: { value: tot ? 100 * w.mem / tot : null },
        detGrow: { value: g == null ? null : g / MB, color: g >= 50 * MB ? 'crit' : g >= 10 * MB ? 'warn' : '' },
        detCpu: { value: w.cpu },
        detTrend: { value: mbNum(w.mem), points: h, lo: Math.max(0, lo - pad), hi: hi + pad, foot },
        detKv: { rows: [['Program', w.program], [w.n > 1 ? 'Processes' : 'Process', pids], ['Threads', String(w.threads)],
            ['Started', s.up ? `${span(s.up - w.start / HZ)} ago` : '--'], ['Shared files', mb(w.shared)]]
            .concat(w.swap > 0 ? [['Swapped out', mb(w.swap)]] : []) },
    };
}

module.exports = { overview, processor, processes, details, mb, pct, growth, span, sorted, MB };

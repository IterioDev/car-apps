'use strict';
/*
 * tele-table.js - tapTable: the Telemetry table (tele-widgets.js teleTable, the same look) whose headings and rows take
 * taps (System Monitor 1.0.0, 2026-11-21: tap a heading to sort, a row for its details). Not tele* named and not a
 * change to teleTable: the 24 Telemetry types stay as they are, every other app's tables stay display-only.
 *   a tap on a heading   -> the app event '<name>:head<i>' (i: the column)
 *   a tap on a row       -> '<name>:row<k>' (k: the row's index in o.rows, scrolled or not)
 *   more rows than fit   -> a drag scrolls by whole rows (o.top: the app hears it as a 'change'; the controller's ring
 *                           scrolls it too, controller.js), a thin bar on the right shows where the shown rows are
 * Same contract as tele-widgets.js (DRAW / TRY, gpu.js touchElement). Shipped to the car in renderer/ (Node 8).
 */
const TW = require('./tele-widgets');

const HEAD = 50;              // the heading row (tele-widgets table(): its caps at +30, the hairline at +48)
const BAR = 20;               // kept free on the right for the scroll bar while the rows scroll

/** what is shown: { rh, rows, n (rows that fit), top (first shown), w (the table's width) } */
function view(b, o) {
    const rh = o.rowH || 64, rows = TW.lines(o.rows), n = Math.max(1, Math.floor((b.h - HEAD) / rh));
    const top = Math.max(0, Math.min(Math.max(0, rows.length - n), o.top | 0));
    return { rh, rows, n, top, w: rows.length > n ? b.w - BAR : b.w };
}
/** each column's heading box (drawing, touch and the controller's ring use the same) */
function heads(b, o) {
    const cols = TW.colList(o.columns), w = view(b, o).w, tot = cols.reduce((a, c) => a + c[1], 0);
    let x = b.x;
    return cols.map((c) => { const r = { x, y: b.y, w: w * c[1] / tot, h: HEAD }; x += r.w; return r; });
}

const DRAW = {};
DRAW.tapTable = (cv, t, b, o) => {
    const v = view(b, o);
    TW.table(cv, b.x, b.y, v.w, TW.colList(o.columns), v.rows.slice(v.top, v.top + v.n), v.rh);
    if (v.rows.length <= v.n) return;
    const room = b.h - HEAD, h = room * v.n / v.rows.length;
    cv.fillRect(b.x + b.w - 4, b.y + HEAD + (room - h) * v.top / (v.rows.length - v.n), 4, h, TW.C.faint);
};

// a drag scrolls by whole rows; a release without one is a tap. ponytail: one gesture at a time (as store-widgets' lists)
let drag = null;
const TRY = {};
TRY.tapTable = Object.assign((cv, b, o, p) => {
    const v = view(b, o);
    if (!p.move) { drag = { y0: p.y, top: v.top, moved: false }; return false; }
    const dy = drag ? p.y - drag.y0 : 0;
    if (!drag || (!drag.moved && Math.abs(dy) < v.rh * 0.25)) return false;
    drag.moved = true;
    const top = Math.max(0, Math.min(v.rows.length - v.n, drag.top - Math.round(dy / v.rh)));
    if (top === v.top) return false;
    o.top = top;
}, { drag: true, up: (cv, b, o, p) => {
    const d = drag, v = view(b, o);
    drag = null;
    if (!d || d.moved) return false;
    if (p.y < b.y + HEAD) {
        const i = heads(b, o).findIndex((r) => p.x >= r.x && p.x < r.x + r.w);
        return i < 0 ? false : { part: `head${i}` };
    }
    const j = Math.floor((p.y - b.y - HEAD) / v.rh), k = v.top + j;
    return j < v.n && k < v.rows.length ? { part: `row${k}` } : false;
} });

module.exports = { DRAW, TRY, view, heads, HEAD };

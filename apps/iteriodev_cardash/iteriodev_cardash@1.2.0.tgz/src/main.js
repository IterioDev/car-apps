'use strict';
/*
 * iteriodev_cardash: live vehicle values (tile "Car Data").
 * Screens (1.1.0): drawn by the GPU renderer (mgu-renderd, scripts/renderd), designed in the HMI UI builder:
 * apps/hmi-ui-builder/projects/car-data.json, exported into this folder (rhmiData/ = one empty RHMI host state
 * per screen, renderer/ = screens.json + the builder's runtime). Tabs across the top of each screen (1.2.0):
 *   engine (entry): engine speed + boost (bars, peak hold), speed + gear, power + torque, oil /
 *                   coolant / intake air temperature
 *   details:        raw values per source, update rates, link status (for calibration)
 *   settings:       a slider per bar: where it ends (red zone = its last 10 %), saved in data/settings.json
 * The renderer gives the app the touches on its screens; the HMI's BACK / HOME / popups work through the host
 * states (screenapp.js bindHosts). Tyre pressure / temperature (1.0.13) dropped in 1.1.0, and the units /
 * bar scale menu of the RHMI screens: metric only.
 *
 * 1.0.6 (analysis/cardash-realtime.md): BMW's own data collector (oap-cdc-2018, config
 * someip.getIntervalsMs) reads rpm, speed, torque, sport-display data, accelerations and display
 * data by POLLING the getters, not by subscribing: those notifiers don't run (FES never fired here).
 * So bus values are polled (rpm every 50 ms) while the screen is in use; OBD (one TASU round trip per
 * request, too slow for rpm) is only the fallback and the source of boost / IAT / throttle. OBD asks
 * up to 6 PIDs per request and learns which PIDs the DME supports. Gear: estimated from rpm/speed.
 * 1.0.7 (car test of 1.0.6): power in hp, throttle = OBD relative throttle (0 = closed, '-' with the
 * engine off; absolute 0x11 read 38 % at rest), pedal = OBD relative pedal position (the bus pedal
 * signal read 100 % at a light touch: raw only, on the details screen). Drive mode row (never worked)
 * and the tiles view removed.
 * 1.0.13 (from idrive7-apps, analysis/idrive7-apps-merge.md): tyre pressure / temperature rows (TPMS,
 * getters polled like BMW's x_call), MDrive + FES boost (x0.01 bar, a guess) + timing / fuel pressures on
 * the details screen, boost from OBD PID 0x87 when the DME has it (PID 0x0B stops at 255 kPa = 1.5 bar
 * boost), and only TASU replies of the unit asked are taken (oap-dtcscan uses the same transport).
 * 1.0.14: misfire counts per cylinder this driving cycle (OBD service 06, MID A2.. TID 0C, cylinder count
 * from MID A0), one cylinder every 500 ms in the OBD rotation.
 * 1.1.3 (car: boost stuck at -0.03 .. -0.12 bar under load): boost = the highest fresh pressure of OBD PID 0x70
 * (boost pressure sensor), 0x87 and 0x0B, minus 0x33; all four on the details page. 1.1.4: "fresh" = 5 s (with one
 * PID per request 1.5 s dropped MAP and boost fell back to the sport display).
 * 1.1.5 (user): the driving page is gone (misfire counts were wrong, the cluster has its own G-meter), and with
 * it the misfire monitors (service 06), the acceleration getters and the throttle / pedal PIDs.
 * 1.1.8 (user): battery voltage, a fourth small bar beside the temperatures: Harman's LevelMonitor systemVoltage (the
 * head unit's supply, instance "Inst1"); the car's DME has no OBD PID 0x42. Not car-tested: unit picked by size.
 *
 * Sources (etc/oap/someip/someip-interfaces.json, instance "1" unless said):
 *   vehicle.CDS / Vehicle2          rpm, temps / speed
 *   drivingexcitement.FES           crankshaft torque, sport display (boost, g, power/torque %)
 *   displaydata.DisplayDataServer2  gear, rpm needle, power meter (cluster / HUD data)
 *   displaydataserver.DisplayDataServer  rpm, current gear (older variant)
 *   powertrain.AcceleratorPedal / Powertrain, infrastructure.VehicleInformation   pedal (raw) / gear display
 *   Harman environment.levelmonitor.LevelMonitor ("Inst1")   system voltage (battery)
 *   OBD service 0x01 to the DME (0x12), gear PID A4 also to the EGS (0x18), through TASU.
 * CAL: rpm x0.25, temps -48, outside x0.5-40 checked on the car; the rest are BMW signal-catalogue
 * style guesses, shown raw on the details screen to check them.
 *
 * 1.1.9: iDrive 7 + 8. Start, tile and shutdown are the shared OnlineApp host (oap-shared/online-host.js, the Store's
 * lifecycle); rhmiData/ has a host state per screen for both HMIs (builder bundle "both"). Polling and OBD run while a
 * screen shows (30 min after the last screen change at most) and stop when the app is hidden or closed.
 * 1.1.10: iDrive 7 draws its own layout of each page (screens.json screen.id7, 1:1 in iDrive 7 px, down to the
 * screen's bottom) instead of the iDrive 8 design scaled to the screen's width (which left the lower quarter empty).
 * 1.2.0: the Telemetry design (scripts/oap-tools/make_cardash_project.js): tabs across the top, Details as three key /
 * value columns, "DME not answering" in the frame without an engine speed. iDrive 8 only again (spec O1: the iDrive 7
 * layouts and uiDescription are gone; iDrive 7 cars keep 1.1.10).
 */
const someipBuilders                  = require('oap-sdk/src/someip/someipBuilders');
const fs = require('fs');
const path = require('path');
const obd = require('./obd.js');
const { createGuard } = require('./tasu-guard.js');
const { createHost } = require('./online-host.js');

const LOG = '[iteriodev_cardash]';

// ---- calibration knobs: raw bus value -> unit
const CAL = {
    rpm: (r) => r * 0.25,           // AVL_RPM_ENG_CRSH: raw 3624 at ~900 rpm cold idle
    kmh: (r) => r / 64,             // V_VEH_COG
    engineC: (r) => r - 48,         // coolant, engine oil
    outsideC: (r) => r * 0.5 - 40,  // TEMP_EX
    fesBoostBar: (r) => r * 0.01,   // sport display boost, idrive7-apps guess: compare with OBD on the details screen
    torqueNm: (r) => r * 0.5 - 1023.5,        // net crankshaft torque; 0 Nm at raw 2047, idle +37.5 (car-confirmed 2026-10-22)
    gearK: 23,                      // rpm per km/h in the 1:1 gear, start value for the gear estimate
};
const RENDER_MS      = 100;
const PEAK_MS        = 3000;        // the bars' peak hold (red line along the top): the highest of the last 3 s
const RPM_MS         = 50;          // getter polling: rpm sources (20 Hz, cluster-like)
const FAST_MS        = 100;         // getter polling: other fast values
const SLOW_MS        = 1000;
const RETRY_MS       = 30e3;        // services offered late (or never) get retried
const OBD_GAP_MS     = 10;          // pause between OBD requests (one in flight at a time)
const OBD_TIMEOUT_MS = 2000;
const FRESH_MS       = 1500;        // older values lose to another source
const OBD_FRESH_MS   = 5000;        // older OBD pressures don't count for boost (a source that stopped answering)
const OBD_KEEP_MS    = 30e3;        // older OBD values aren't shown at all (polling paused: no frozen numbers)
// ponytail: polling + OBD stop 30 min after the last tile tap (or at visible=false), reopen to resume
const ACTIVE_WINDOW_MS = 30 * 60e3;

const raw = {};         // latest bus values, unscaled
const seen = {};        // "Source.field" -> time of its last answer (changed or not)
const hits = {};        // "Source.field" -> changes in the current 5 s
const rates = {};
const errs = {};        // "Source.field" -> last error
const link = {};        // source -> 'connecting' | 'ok' | 'ERR ...'

const errText = (e) => String(e && e.message || e).slice(0, 60);
// link state after a failed connect: a service the car doesn't offer (its proxy never shows up, the SDK's
// "Proxy[..]::waitUntilAvailable(10000) timed out") is no error; read from the whole message (errText cuts it)
const linkErr = (e) => (/waitUntilAvailable\(\d*\) timed out/.test(String(e && e.message || e)) ? 'not offered' : `ERR ${errText(e)}`);
const hex = (b) => (b === undefined ? '--' : (b < 16 ? '0' : '') + b.toString(16).toUpperCase());
const valid = (r, invalid) => typeof r === 'number' && r !== invalid;
const busFresh = (f) => seen[f] && Date.now() - seen[f] < FRESH_MS;
function set(k, v) { raw[k] = v; }

const SOURCES = {   // name: [interface, { field: handler }, { field: poll ms }]
    CDS: ['de.bmw.infotainment.vehicle.CDS', {
        statusEngineSpeed2: (x) => set('rpm', x.actualValueRPMEngineCrankshaft),
        statusEngineTemperature: (x) => { set('coolant', x.temperatureEngineDrive); set('oil', x.temperatureEngineOilDrive); },
    }, { statusEngineSpeed2: RPM_MS, statusEngineTemperature: SLOW_MS }],
    Vehicle2: ['de.bmw.infotainment.vehicle.Vehicle2', {
        statusCarSpeed2: (x) => set('speed', x.speedVehicleCentreOfGravity),
    }, { statusCarSpeed2: FAST_MS }],
    FES: ['de.bmw.infotainment.drivingexcitement.FES', {
        statusActualValueTorque2: (x) => set('torque', x.actualValueTorqueCrankshaft),
        statusVehicleDynamicEngine: (x) => { set('torquePct', x.displaySportEngineTorque); set('powerPct', x.displaySportEnginePower); },
        statusVehicleDynamicEngineMaxValue: (x) => { set('maxPower', x.displayMaximumValuePower); set('maxTorque', x.displayMaximumValueTorque); },
        statusSwitchDriveDynamicSport2: (x) => {
            set('sportBoost', x.displayBoostPressure); set('sportBoostMax', x.displayMaximumValueBoostPressure);
            set('sportLat', x.displayLateralAcceleration); set('sportLon', x.displayLongitudinalAcceleration);
        },
        dataGearBox2: (x) => set('gearMode', x.driveModusGearbox),
    }, { statusActualValueTorque2: FAST_MS, statusVehicleDynamicEngine: FAST_MS,
        statusVehicleDynamicEngineMaxValue: 10e3, statusSwitchDriveDynamicSport2: FAST_MS }],
    Display: ['de.bmw.infotainment.displaydata.DisplayDataServer2', {
        functionalLibraryData: (x) => { set('ddsGear', x.gear); set('ddsRev', x.pointerPositionRevolution); set('ddsPower', x.powermeter && x.powermeter.pointerPosition); },
    }, { functionalLibraryData: RPM_MS }],
    DisplayOld: ['de.bmw.infotainment.displaydataserver.DisplayDataServer', {
        functionalLibraryData: (x) => { set('ddsRpm', x.rpm); set('ddsGearOld', x.currentGear); },
    }, { functionalLibraryData: FAST_MS }],
    Pedal: ['de.bmw.powertrain.AcceleratorPedal', {
        AngleAcceleratorPedal: (x) => set('pedal', x.actualValueAngleAcceleratorPedal),
    }],
    PT: ['de.bmw.powertrain.Powertrain', {
        dataDisplayGearboxSecure: (x) => { set('ptGear', x.dummy1); set('ptPos', x.dummy4); },
    }],
    Gearbox: ['de.bmw.infrastructure.VehicleInformation', {
        statusGearboxDrive: (x) => { set('viGear', x.statusActualGearDrive); set('viStage', x.statusActualStageDrive); },
    }],
    Env: ['de.bmw.infrastructure.EnvironmentalInformation', {
        ExteriorTemperature: (x) => set('outside', x.temperatureExterior),
    }],
    MDrive: ['de.bmw.infotainment.misc.MDrive', {
        statusMSystem: (x) => { set('awd', x.statusAllWheelSetup); set('awdQual', x.qualifierFunctionAllWheel); },
        dataDisplayGearbox: (x) => { set('program', x.displayProgramGearbox); set('driveLogic', x.displayDriveLogicGearbox); },
    }, { statusMSystem: SLOW_MS }],
    // 1.1.8: the head unit's own supply voltage (its KL30 input, ≈ the 12 V battery); instance 'Inst1' (someip-interfaces.json)
    Level: ['com.harman.infotainment.systeminfrastructure.environment.levelmonitor.LevelMonitor', {
        systemVoltage: (x) => set('volt', x.value),
    }, { systemVoltage: SLOW_MS }, 'Inst1'],
};

// ---- values in metric units (undefined = no data) -------------------------------------------
const o = {};           // OBD key -> { value, at } | { err }
const obdVal = (k) => (o[k] && 'value' in o[k] && Date.now() - o[k].at < OBD_KEEP_MS ? o[k].value : undefined);
// one PID per request (multi off): each fast PID comes round only every ~12 requests
const obdFresh = (k) => o[k] && 'value' in o[k] && Date.now() - o[k].at < OBD_FRESH_MS;
const busC = (r, cal) => (valid(r, 255) ? cal(r) : undefined);
let gearK = CAL.gearK;
const V = {
    // the bus while it answers (polled every 50-100 ms), OBD (a round trip per value) only as fallback
    rpm: () => (busFresh('CDS.statusEngineSpeed2') && valid(raw.rpm, 65535) ? CAL.rpm(raw.rpm) : obdVal('rpm')),
    speed: () => (busFresh('Vehicle2.statusCarSpeed2') && valid(raw.speed, 65535) ? CAL.kmh(raw.speed) : obdVal('speed')),
    // OBD: the highest fresh boost / manifold pressure (PID 0x70 boost sensor, 0x87, 0x0B - one of them may never
    // pass the outside pressure, car 1.1.2) - outside pressure; else the sport display
    boost: () => {
        const ps = ['boostP', 'mapX', 'map'].filter(obdFresh).map(obdVal).filter((v) => v !== undefined);
        if (ps.length && obdVal('baro') !== undefined) return (Math.max.apply(null, ps) - obdVal('baro')) / 100;
        return V.fesBoost();
    },
    fesBoost: () => (valid(raw.sportBoost, 255) ? CAL.fesBoostBar(raw.sportBoost) : undefined),
    torque: () => (busFresh('FES.statusActualValueTorque2') && valid(raw.torque, 65535) ? CAL.torqueNm(raw.torque)
        : obdVal('torquePct') !== undefined && obdVal('refTorque') ? obdVal('torquePct') * obdVal('refTorque') / 100 : undefined),
    power: () => (V.torque() !== undefined && V.rpm() !== undefined ? V.torque() * V.rpm() / 9549.3 : undefined),   // kW
    iat: () => obdVal('iat'),
    coolant: () => busC(raw.coolant, CAL.engineC),
    oil: () => busC(raw.oil, CAL.engineC),
    outside: () => busC(raw.outside, CAL.outsideC),
    // ponytail: the unit isn't documented - mV, 10 mV, 100 mV and V each put 6-16 V in their own range, so the size
    // of the number picks it; the details page shows the raw value to check it against
    volt: () => {
        const r = raw.volt;
        if (!(typeof r === 'number' && r > 0) || !(Date.now() - (seen['Level.systemVoltage'] || 0) < 5000)) return undefined;
        return r >= 5000 ? r / 1000 : r >= 500 ? r / 100 : r >= 50 ? r / 10 : r;
    },
};

// gear sources, best first:
// 1. VehicleInformation.statusGearboxDrive.statusActualGearDrive - authoritative, the cluster's own gear.
//    ID8 catalogue enum (= idrive7-apps): R=1, N_OR_P=2, G1=3 … G10=12 (forward gear = value - 2). The SDK
//    hands enums back as the NAME ("G5", "R") or the number, so decode both. Event-only (no getter): it
//    fires on a change, so raw.viGear is the last gear seen; undefined until the first shift -> fall through.
//    statusActualStageDrive gives the selector (P=1,R=2,N=3,D=4) for standstill / neutral.
// 2. DisplayDataServer2 `gear` (ddsGear), encoded +19 (car-confirmed 2026-10-22: 20 = 1st … 27 = 8th).
// 3. rpm/speed estimate (8HP ratios).
const GEARNAME = { R: 'R', N_OR_P: 'N/P', G1: '1', G2: '2', G3: '3', G4: '4', G5: '5', G6: '6', G7: '7', G8: '8', G9: '9', G10: '10' };
const STAGENAME = { P: 'P', R: 'R', N: 'N', D: 'D', 1: 'P', 2: 'R', 3: 'N', 4: 'D' };
// -> 'R' / '1'..'10' / null (N/P, unknown, error); number 1=R,2=N/P,3..12=gears or the enum name string
function gearOf(v) {
    if (typeof v === 'number') return v === 1 ? 'R' : (v >= 3 && v <= 12 ? String(v - 2) : null);
    const g = GEARNAME[v];
    return g && g !== 'N/P' ? g : null;
}
function gearText() {
    const g = gearOf(raw.viGear);
    if (g) return g;                                                 // authoritative engaged gear
    const stage = STAGENAME[raw.viStage];
    if (stage && stage !== 'D') return stage;                        // P / R / N at standstill (D with no gear falls through)
    const moving = V.speed() > 0;
    if (moving && typeof raw.ddsGear === 'number' && raw.ddsGear >= 20 && raw.ddsGear <= 27) return String(raw.ddsGear - 19);
    if (!moving) return stage || '-';
    const est = obd.estimateGear(V.rpm(), V.speed(), gearK);
    gearK = est.k;
    return est.gear ? String(est.gear) : '-';
}

// ---- the details page: raw values and data links, three columns of key | value rows (for checking a reading) ---------
const num = (v, d = 0) => (v === undefined || isNaN(v) ? '-' : v.toFixed(d));
const T = {
    rpm: () => `${num(V.rpm())} rpm`,
    boost: () => `${num(V.boost(), 2)} bar`,
};
// the bus's no-reading enum names (signal not filled, invalid, starting up, not available, faulty)
const NOREADING = { SIGNAL_UNBEFUELLT: '-', SIGNAL_UNGUELTIG: '-', INITIALISIERUNG: '-', FUNKTIONSSCHNITTSTELLE_IST_NICHT_VERFUEGBAR: '-',
    FUNKTION_MELDET_FEHLER: 'fault' };

function detailsRows() {
    const paused = tasu && Date.now() > activeUntil ? ' (paused)' : '';
    const ob = (k, u) => { const x = o[k]; return !x ? '-' : x.err ? x.err : `${num(x.value, 1)} ${u}`; };
    const r = (k) => (raw[k] === undefined ? '-' : NOREADING[raw[k]] || String(raw[k]));
    const cut = (s, n) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);
    const pids = (t) => (supported[t] ? supported[t].slice(0, 11).map(hex).join(' ') + (supported[t].length > 11 ? ' …' : '') : '?');
    // one row per three sources: ok when all three are, else the first failing one ('error', red), else the first one
    // that is not ok (dim: connecting / not offered)
    const links = (title, names) => {
        const err = (n) => /^ERR/.test(link[n] || '');
        const bad = names.find(err) || names.find((n) => link[n] !== 'ok');
        return bad ? [title, `${bad} ${err(bad) ? 'error' : link[bad] || 'not asked'}`, err(bad) ? 'crit' : 'dim'] : [title, 'ok', 'ok'];
    };
    const rate = (k) => `${num(rates[k] || 0, 1)}/s`;
    const errKeys = Object.keys(errs);
    // the builder's kv() has no width limit: a value (enum names from the bus) cut to ~40 characters fits beside its key
    const fit = (rows) => rows.map(([k, v, ...c]) => [k, cut(v, 40), ...c]);
    return {
        engine: fit([['Engine speed', T.rpm()], ['Boost', T.boost()], ['Timing', ob('timing', '°')], ['High pressure pump', ob('hpfp', 'bar')],
            ['Low pressure pump', ob('lpfp', 'bar')], ['Boost sensor (0x70)', ob('boostP', 'kPa')], ['MAP (0x87)', ob('mapX', 'kPa')],
            ['MAP (0x0B)', ob('map', 'kPa')], ['Baro (0x33)', ob('baro', 'kPa')]]),
        gear: fit([['Gear', gearShown()], ['Gear source', `ddsGear ${r('ddsGear')} · k ${num(gearK, 1)}`], ['Selector', `${r('viGear')} · ${r('viStage')}`],
            ['Torque (FES)', r('torque')], ['Torque · power', `${r('torquePct')} · ${r('powerPct')} %`],
            ['Sport boost', `${r('sportBoost')} / ${r('sportBoostMax')} · ${num(V.fesBoost(), 2)} bar`], ['Pedal (raw)', r('pedal')],
            ['All-wheel drive', `${r('awd')} · ${r('awdQual')}`], ['Battery (raw)', `${r('volt')} · ${num(V.volt(), 2)} V`]]),
        links: fit([links('CDS · Vehicle2 · FES', ['CDS', 'Vehicle2', 'FES']), links('DDS2 · DDS · Pedal', ['Display', 'DisplayOld', 'Pedal']),
            links('Powertrain · Gear · Outside', ['PT', 'Gearbox', 'Env']), links('MDrive · Battery · TASU', ['MDrive', 'Level', 'UDS']),
            ['Updates', `rpm ${rate('CDS.statusEngineSpeed2')} · speed ${rate('Vehicle2.statusCarSpeed2')}`],
            ['OBD', `${multi ? 'several PIDs' : 'one PID'} a request${paused}`], ['OBD PIDs (DME)', pids(DME)], ['OBD PIDs (EGS)', pids(EGS)],
            ['Getter errors', errKeys.length ? cut(`${errKeys.length}: ${errKeys[0]} ${errs[errKeys[0]]}`, 30) : 'none']]),
    };
}

// ---- SOME/IP sources: subscribe everything, poll the getters of the fast fields --------------
function connect(name) {
    const [ifName, fields, polled = {}, instance = '1'] = SOURCES[name];
    link[name] = link[name] || 'connecting';
    let proxy = null;
    const last = {};
    const update = (field) => (x) => {
        if (x === undefined || x === null) return;
        seen[`${name}.${field}`] = Date.now();
        const s = JSON.stringify(x);
        if (s === last[field]) return;
        last[field] = s;
        fields[field](x);
        hits[`${name}.${field}`] = (hits[`${name}.${field}`] || 0) + 1;
    };
    const read = (field) => Promise.resolve().then(() => proxy[field].getValue())
        .then(update(field), (e) => { errs[`${name}.${field}`] = errText(e); });
    const poll = (field, ms) => {
        const go = () => (Date.now() < activeUntil ? read(field) : Promise.resolve()).then(() => setTimeout(go, ms));
        go();
    };
    return someipBuilders.buildAndInitTypedProxy(ifName, instance, { timeoutMs: 10000 })
        .then((p) => { proxy = p; })
        .then(() => Promise.all(Object.keys(fields).map((field) => Promise.resolve()
            .then(() => proxy[field].subscribe(update(field)))
            .catch((e) => { errs[`${name}.${field}`] = `subscribe ${errText(e)}`; })
            .then(() => (typeof proxy[field].getValue === 'function' ? read(field) : null)))))
        .then(() => {
            link[name] = 'ok';
            Object.keys(polled).forEach((field) => { if (typeof proxy[field].getValue === 'function') poll(field, polled[field]); });
        })
        .catch((e) => {
            link[name] = linkErr(e);
            setTimeout(() => connect(name), RETRY_MS);
        });
}

// ---- OBD through TASU -----------------------------------------------------------------------
const TASU_IF = 'com.harman.infotainment.systemfunctions.tasu.tasu.InternalTasu';
const TESTER  = 0xF2;   // stock source address
const DME     = 0x12;
const EGS     = 0x18;
// rpm, boost, map, speed
function fastPids() {
    const has = (p) => supported[DME] && usablePid(DME, p);
    const noMapX = o.mapX && 'value' in o.mapX && o.mapX.value === undefined;   // 0x87 listed, sensor A missing
    return [0x0C, has(0x70) ? 0x70 : null, has(0x87) && !noMapX ? 0x87 : 0x0B, 0x0D]
        .filter((p) => p !== null && usablePid(DME, p));
}
// 0x0B here too: with 0x87 in the fast set, both MAP PIDs show on the details page (and count for boost)
const SLOW_PIDS = [0x0F, 0x33, 0x0B, 0x05, 0x5C, 0x04, 0x0E, 0x10, 0x61, 0x62, 0x63, 0x46, 0xA4, 0x23, 0x0A];
const supported = {};   // target -> [pid] once asked
const refused = new Set();          // "target:pid" the ECU refused: not asked again
let tasu = null;
let activeUntil = 0;
let multi = true;       // several PIDs per request; off after the DME refuses it
let slowNext = 0;
let fastTurn = true;
let pending = null;     // { target, pids, timer }
const queue = [];       // one-off requests: supported-PID scans
let obdCount = 0;

const usablePid = (t, pid) => !refused.has(`${t}:${pid}`) && (!supported[t] || supported[t].indexOf(pid) >= 0);
function nextRequest() {
    if (queue.length) return queue.shift();
    fastTurn = !fastTurn;
    if (!fastTurn) {    // every other request: the next slow PIDs (gear A4 also from the EGS)
        const list = SLOW_PIDS.filter((p) => usablePid(DME, p));
        const egsGear = supported[EGS] && usablePid(EGS, 0xA4) && slowNext % 4 === 0;
        slowNext++;
        if (egsGear) return { target: EGS, pids: [0xA4] };
        if (list.length) {
            const n = multi ? Math.min(6, list.length) : 1, start = (slowNext * n) % list.length;
            return { target: DME, pids: list.concat(list).slice(start, start + n) };
        }
    }
    const fast = fastPids();
    return { target: DME, pids: multi ? fast : [fast[obdCount % fast.length]] };
}

function connectTasu() {
    link.UDS = link.UDS || 'connecting';
    return someipBuilders.buildAndInitTypedProxy(TASU_IF, 'SystemFunctionsInternalTasuInst1', { timeoutMs: 10000 })
        .then((proxy) => proxy.sendTasuResponse.subscribe(onTasuResponse).then(() => {
            tasu = proxy; link.UDS = 'ok';
            queue.push({ target: DME, pids: obd.SUPPORT }, { target: EGS, pids: [0x00, 0xA0] });
        }))
        .catch((e) => { link.UDS = linkErr(e); setTimeout(connectTasu, RETRY_MS); });
}

function finishObd(answer) {
    if (!pending) return;
    clearTimeout(pending.timer);
    const { target, pids } = pending;
    pending = null;
    obdCount++;
    hits.OBD = (hits.OBD || 0) + 1;
    if (answer.err) {
        if (pids.length > 1 && pids[0] !== 0x00 && /NRC|timeout/.test(answer.err)) multi = false;
        else if (/NRC 7F 01 (12|31)/.test(answer.err)) pids.forEach((p) => refused.add(`${target}:${p}`));
        if (target === DME && pids.length === 1) o[obd.key(pids[0])] = { err: answer.err };
        if (pids[0] === 0x00) supported[target] = supported[target] || [];   // ECU has no OBD: ask nothing more
    } else {
        if (answer.supported.length || pids[0] === 0x00) supported[target] = answer.supported;
        Object.keys(answer.values).forEach((k) => { o[k] = { value: answer.values[k], at: Date.now() }; });
    }
    setTimeout(obdTick, OBD_GAP_MS);
}

// every TASU request passes the shared guard; Car Data only reads (OBD 01), which it always lets
// through, so it needs no speed / rpm feed - anything else would be refused here
const guard = createGuard();

function obdTick() {
    if (!tasu || pending || Date.now() > activeUntil) return;
    const req = nextRequest();
    pending = Object.assign({ timer: setTimeout(() => finishObd({ err: 'timeout' }), OBD_TIMEOUT_MS) }, req);
    const g = guard.check(0x01, req.pids);
    if (!g.ok) { finishObd({ err: `blocked: ${g.why}` }); return; }
    tasu.sendTasuRequest({
        sourceAddress: TESTER, targetAddress: req.target, serviceID: 0x01, subroutineID: 0,
        udsDataLength: req.pids.length, udsData: Buffer.from(req.pids), deadlockTime: 0,
    }).then((res) => {
        const code = res && res.TasuErrorEnum;
        if (code !== 'NO_ERROR' && code !== 'REQUEST_PENDING') finishObd({ err: String(code) });
    }, (e) => finishObd({ err: errText(e) }));
}

// Layout as parsed by the stock app: [2] == 0x7F -> TAS error code at [4]; [6] = the unit that
// answered; its answer starts at [9]: 41 PID data [PID data]... or 7F 01 NRC. Every TASU user gets
// every reply (oap-dtcscan scans all units): only the asked unit's service 01 answers are ours.
function onTasuResponse(ev) {
    if (!pending) return null;
    if (!ev || ev.errorCode !== 'NO_ERROR') return finishObd({ err: String(ev && ev.errorCode) });
    const r = Array.from(ev.udsResponse || []);
    if (r[2] === 0x7F) return finishObd({ err: `TAS ${hex(r[4])}` });
    if (r[6] !== pending.target) return null;
    if (r[9] === 0x41) return finishObd(obd.parse(r.slice(10)));
    if (r[9] === 0x7F && r[10] === 0x01) return r[11] === 0x78 ? null : finishObd({ err: `NRC ${r.slice(9, 12).map(hex).join(' ')}` });
    return null;
}

// ---- screens (the renderer) -------------------------------------------------------------------
// renderer/ is the builder's export: screens.json + its runtime. Loaded with a computed path (plain files in the
// package). The linked bundle is javascript/app.js: the package root is one up.
const SOURCE = typeof __dirname === 'string' ? path.join(__dirname, '..') : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
const PAGES = ['engine', 'details', 'settings'];   // screens = their RHMI host states; each has its frame (tabs) <page>Menu
let screens = null;

// ---- settings: where each bar ends (the settings page's sliders), saved in the app's data folder ----------
// The red zone is the last 10 % of a bar (user decision); the torque bar ends where the slider says, whatever
// rated torque the car reports. key: [default, slider lowest, highest, step]; settings row = <key>Max.
const SETTINGS_FILE = path.join(__dirname, '..', '..', 'data', 'settings.json');   // the app's data folder (the Store's)
const RANGES = { rpm: [8000, 5000, 10000, 500], boost: [2.5, 0.5, 4, 0.25], power: [500, 200, 1000, 50], torque: [700, 300, 1200, 50],
    oil: [150, 100, 180, 5], coolant: [130, 100, 160, 5], intake: [80, 40, 120, 5] };
const UNITS = { rpm: 'rpm', boost: 'bar', power: 'hp', torque: 'Nm' };     // the bars with a red zone
const snap = (k, v) => { const [def, lo, hi, st] = RANGES[k]; return isFinite(v) ? +Math.min(hi, Math.max(lo, Math.round(v / st) * st)).toFixed(2) : def; };
const defaultEnds = () => Object.keys(RANGES).reduce((o, k) => { o[k] = RANGES[k][0]; return o; }, {});
let ends = defaultEnds();
try { const f = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')); Object.keys(RANGES).forEach((k) => { if (k in f) ends[k] = snap(k, +f[k]); }); } catch (e) { /* defaults */ }
const redFrom = (k) => +(ends[k] * 0.9).toFixed(2);
let saveTimer = null;
function saveEnds() {       // a slider drag changes it many times: written once it rests
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => { try { fs.writeFileSync(SETTINGS_FILE, JSON.stringify(ends)); } catch (e) { log(`settings not saved: ${errText(e)}`); } }, 500);
}

const rnd = (v, d) => (v === undefined || isNaN(v) ? undefined : +v.toFixed(d || 0));   // as shown: fewer redraws
const peaks = {};
/** the highest value of the last PEAK_MS (a bar's peak hold) */
function peak(k, v) {
    if (v === undefined) return undefined;
    const p = peaks[k], now = Date.now();
    if (!p || v >= p.v || now - p.at > PEAK_MS) peaks[k] = { v, at: now };
    return peaks[k].v;
}
// "D3" in D with a known gear (the reference design), else the gear / selector as gearText gives it
function gearShown() {
    const g = gearText();
    return /^\d+$/.test(g) && STAGENAME[raw.viStage] === 'D' ? `D${g}` : g;
}

// the app's values on the screens (ScreenApp.set: drawn only when the shown screen changed)
function render() {
    if (!screens || !screens.st) return;
    const rpm = rnd(V.rpm()), boost = rnd(V.boost(), 2), nm = rnd(V.torque()), kmh = rnd(V.speed());
    const hp = rnd(V.power() === undefined ? undefined : V.power() * 1.341);
    // a tick (and its number) every 1000 rpm, 0.5 bar, 100 hp / Nm; a bar end between two of them ends the scale there
    screens.set('rpmBar', { value: rpm, peak: peak('rpm', rpm), max: ends.rpm, limit: redFrom('rpm'), ticks: ends.rpm / 1000 })
        .set('boostBar', { value: boost, peak: peak('boost', boost), max: ends.boost, limit: redFrom('boost'), ticks: ends.boost / 0.5 })
        .set('powerBar', { value: hp, peak: peak('hp', hp), max: ends.power, limit: redFrom('power'), ticks: ends.power / 100 })
        .set('torqueBar', { value: nm, peak: peak('nm', nm), max: ends.torque, limit: redFrom('torque'), ticks: ends.torque / 100 })
        .set('speed', { value: kmh === undefined ? '--' : String(kmh), color: kmh === undefined ? 'dim' : '' })     // teleValue: text
        .set('gear', { text: gearShown(), color: rpm === undefined ? '#4a4f57' : '#ffb020' })
        // polling paused (30 min after the last screen change, or hidden): the frame says so, not "Live"; else no engine
        // speed from the bus or OBD: the DME is not answering (yet) - the frame says so (p4 engine-nodata)
        .set('engineMenu', Date.now() > activeUntil ? { chips: [['Paused', 'warn']], sub: 'Paused · open a tab to resume' }
            : rpm === undefined ? { chips: [['DME not answering', 'crit']], sub: 'Waiting for the DME' } : { chips: [], sub: 'Live from the DME' })
        .set('oilBar', { value: rnd(V.oil()), max: ends.oil })
        .set('coolantBar', { value: rnd(V.coolant()), max: ends.coolant })
        .set('intakeBar', { value: rnd(V.iat()), max: ends.intake })
        .set('batteryBar', { value: rnd(V.volt(), 1) });
    if (screens.st.name === 'details') {
        const d = detailsRows();
        screens.set('detailsEngine', { rows: d.engine }).set('detailsGear', { rows: d.gear }).set('detailsLinks', { rows: d.links });
    }
    Object.keys(RANGES).forEach((k) => screens.set(`${k}Max`, UNITS[k] ? { value: ends[k], sub: `Red zone from ${redFrom(k)} ${UNITS[k]}` } : { value: ends[k] }));
}

// the tabs: engine is the app's first screen, the other pages open over it (BACK returns to engine)
function goTo(page) {
    const cur = screens.st && screens.st.name;
    if (!page || page === cur) return;
    if (cur && cur !== 'engine') closeScreen(cur);
    if (page !== 'engine') showScreen(page);
}
function onChange(name, o) {
    const k = name.replace(/Max$/, '');
    if (k !== name && RANGES[k]) { ends[k] = snap(k, o.value); saveEnds(); render(); return; }   // a settings slider
    const from = name.replace(/Menu$/, '');
    if (from === name || PAGES.indexOf(from) < 0) return;
    const to = PAGES[o.sel];                             // (o is the element's opts: read before the set below)
    screens.set(name, { sel: PAGES.indexOf(from) });     // this page's menu keeps showing this page
    goTo(to);
}

// ---- RHMI: the host states --------------------------------------------------------------------
let app = null;
const comp = (n) => app.getByName(n);
const log = (m) => console.error(LOG, m);
function showScreen(name) {
    return comp(name).updateResources().then(() => app.openState(name))
        .catch((e) => log(`open ${name} failed: ${errText(e)}`));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed: ${errText(e)}`));

// polling + OBD run while a screen shows: every screen change renews the window, hidden / closed ends it
function activate() {
    const wasIdle = Date.now() > activeUntil;
    activeUntil = Date.now() + ACTIVE_WINDOW_MS;
    if (wasIdle && !pending) setTimeout(obdTick, 0);
}

function startScreens(rhmiApp, hosts) {
    app = rhmiApp;
    const design = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: log, warn: log, error: log };
    const gpu = new RenderClient('iteriodev_cardash', rlog);
    screens = new ScreenApp(gpu, design, { view: 'id8', log: rlog });
    // a host state per screen: the HMI shows it -> the screen shows; BACK / HOME / popups through them
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('show', activate);
    // the app came back from the background with its screen still up: the HMI shows the host state again
    PAGES.forEach((s) => hosts[s].on('visible', (ev) => { if (ev && (ev.visible === true || ev.visible === 'true' || ev.visible === 1)) activate(); }));
    screens.on('change', onChange);
    screens.on('event', (e) => { if (e === 'reset') { ends = defaultEnds(); saveEnds(); render(); } });   // Restore defaults
    // the user left for the HMI (touched it): leave the host states too, or the HMI would show their empty pages
    screens.on('closed', (why) => { activeUntil = 0; if (why !== 'hmi') PAGES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
}

// ---- lifecycle: the shared OnlineApp host (start, tile -> engine, shutdown; iDrive 8 since 1.2.0) ---------------------
// The sources, the TASU link and the render loop start with the screens; the host opens the entry state on a tile tap.
// Hidden (the app went to the background): polling and OBD stop; the next screen shown resumes them.
createHost({
    states: PAGES,                           // the entry state (engine) first
    log,
    onReady: (rhmiApp, hosts) => {
        startScreens(rhmiApp, hosts);
        Object.keys(SOURCES).forEach(connect);
        connectTasu();
        setInterval(render, RENDER_MS);      // while a screen is shown (ScreenApp.set draws only what changed)
        setInterval(() => {   // changes per second over the last 5 s
            for (const k of Object.keys(hits)) { rates[k] = hits[k] / 5; hits[k] = 0; }
        }, 5000);
    },
    onHidden: () => { activeUntil = 0; },
});

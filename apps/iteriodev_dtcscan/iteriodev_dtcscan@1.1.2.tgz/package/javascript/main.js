'use strict';
/*
 * iteriodev_dtcscan: fault codes of every control unit (tile "Fault Codes").
 *   Scan : UDS 19 02 0C (pending + confirmed) to all units (0xDF) over TASU, like BMW's teleservice
 *          READ_PRIMARY_DTCS; one reply per unit, collected until 4 s without a new one.
 *   Clear: UDS 14 FF FF FF to each unit that had codes (or one unit), after a confirm popup; then
 *          scans again.
 *   Check Control: active messages from CheckControlMaster.basicList, names from the cluster's
 *          KombiInterface_2 ccList / newCCMessage (read-only, as idrive7-apps does).
 * Every request passes apps/oap-shared/tasu-guard.js (in diag.js send): reads always, clearing only with
 * the car parked (speed 0 + engine speed 0, fresh), flash programming never.
 * Transport + parsing: ./diag.js (ported from idrive7-apps, MIT). The head unit has no fault texts:
 * after a scan every new unit is asked its SGBD index (22 F1 50), which picks its ISTA SGBD and that
 * SGBD's fault texts (sgbd_index.json + texts/, built by scripts/oap-tools/dtc_build.py). Any car.
 *
 * Screens (1.1.0): drawn by the GPU renderer (mgu-renderd, scripts/renderd), designed in the HMI UI builder:
 * apps/hmi-ui-builder/projects/fault-codes.json, exported into this folder (rhmiData/ = one empty RHMI host state
 * per screen, renderer/ = screens.json + the builder's runtime). home: scan / clear all / Check Control rows, notes,
 * units with codes (a list: tap one -> moduleFaults: its codes, clear this unit); confirmClear; ccMessages.
 * The renderer gives the app the touches on its screens; the HMI's BACK / HOME / popups work through the host
 * states (screenapp.js bindHosts). Bootstrap and tile tap are the oap-draggy ones.
 */
const fs = require('fs');
const path = require('path');
const util = require('util');
const RhmiManager                      = require('oap-sdk/src/rhmi/RhmiManager');
const RhmiResourcesLocator             = require('oap-sdk/src/rhmi/RhmiResourcesLocator');
const MultiLanguageStringBundleFactory = require('oap-sdk/src/rhmi/MultiLanguageStringBundleFactory');
const RhmiApplicationFactory           = require('oap-sdk/src/rhmi/RhmiApplicationFactory');
const ResourceManager                  = require('oap-sdk/src/rhmi/ResourceManager');
const CurrentVehicleUnits              = require('oap-sdk/src/core/CurrentVehicleUnits');
const someipBuilders                   = require('oap-sdk/src/someip/someipBuilders');
const OnlineAppBackground              = require('oap-sdk/src/core/OnlineAppBackground');
const { Diag, parseDtcReply, parseSgbdIndex, isSgbdIndexReply, statusInfo, ecuName, hex, NRC } = require('./diag');
const { createGuard }                  = require('../../oap-shared/tasu-guard');

const APPLET_ID       = 20103;  // = rhmiData/application.json "appletId"
const ENTRY_UUID      = 'e81f4c2a-6d93-4b7e-8f15-2a9c0d3e7b58';   // = entryPoints[0].uuid (project entryUuid)
const APPLETID_OFFSET = 3000;
const LOG = '[iteriodev_dtcscan]';

const TASU_IF = 'com.harman.infotainment.systemfunctions.tasu.tasu.InternalTasu';
const TASU_INST = 'SystemFunctionsInternalTasuInst1';
// ponytail: current faults only (pending 0x04 + confirmed 0x08); 0xFF would add history entries
const MASK = 0x0C;
const RETRY_MS = 30e3;
// runner.js gives the bundle its own folder as __dirname (the package root, next to renderer/)
const SOURCE = typeof __dirname === 'string' ? __dirname : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const DATA = `/var/opt/public/oap/oap_${process.getuid()}/data`;
const SCAN_FILE = `${DATA}/last_scan.json`;
const LOG_FILE = `${DATA}/dtcscan.log`;
const CCM_IF = 'de.bmw.infotainment.checkcontrol.CheckControlMaster';
const KOMBI_IF = 'de.bmw.infotainment.KombiInterface_2';
const CC_POLL_MS = 10e3;    // getters re-read while a screen is open, in case the notifiers stay silent
const CAR_POLL_MS = 500;    // speed + rpm for the parked check (apps/oap-shared/tasu-guard.js), while a screen is open
const STATES = ['home', 'moduleFaults', 'confirmClear', 'ccMessages'];   // screens = their RHMI host states

const errText = (e) => String(e && e.message || e).slice(0, 80);
// own log file: console output goes to DLT, which has no reader on this car
function log() {
    const line = [new Date().toISOString()].concat([].slice.call(arguments)
        .map((x) => (typeof x === 'string' ? x : util.inspect(x, { depth: 4 }).slice(0, 2000)))).join(' ');
    console.error(LOG, line);
    try { if (fs.statSync(LOG_FILE).size > 256 * 1024) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* no file yet */ }
    try { fs.appendFileSync(LOG_FILE, `${line}\n`); } catch (e) { /* no data folder */ }
}

// ---- scan / clear -------------------------------------------------------------------------------------
let scan = null;            // { at, ecus: [{ addr, dtcs: [{ code, status }], nrc }] }
try { scan = JSON.parse(fs.readFileSync(SCAN_FILE, 'utf8')); } catch (e) { /* none yet */ }
let phase = 'idle';         // idle | scanning | clearing
let replies = 0;
let msg = '';
let link = 'connecting';
let selected = null;        // unit address shown on moduleFaults
let clearTarget = null;     // 'all' | unit address
// every TASU request passes the guard: reads always, clearing and other state changes only when parked
const guard = createGuard();
const diag = new Diag((m) => log(m), guard);

// Fault texts (scripts/oap-tools/dtc_build.py, nothing car-specific). Each unit says which SGBD it is via
// 22 F1 50 (its SGBD index, what ISTA's IDENT reads); sgbd_index.json maps "<addr> <index>" -> SGBD
// (ecu.db), texts/<SGBD>.json holds that SGBD's fault texts. dtc_texts.json: hand-made "addr:code" (wins).
const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return {}; } };
const TEXTS = readJson(path.join(SOURCE, 'dtc_texts.json'));
const SGBD = readJson(path.join(SOURCE, 'sgbd_index.json'));
const IDS_FILE = `${DATA}/ecu_ids.json`;
const ids = readJson(IDS_FILE);   // "12" -> "0F26E8"; '' = asked, no index (not asked again)
const variantOf = (addr) => SGBD[`${hex(addr)} ${ids[hex(addr)]}`] || null;
const variantTexts = {};          // SGBD -> { code: text }, loaded on first use
function describe(addr, code) {
    const own = TEXTS[`${hex(addr)}:${code}`];
    if (own) return own;
    const v = variantOf(addr);
    if (!v) return null;
    if (!variantTexts[v]) variantTexts[v] = readJson(path.join(SOURCE, 'texts', `${v}.json`));
    return variantTexts[v][code] || null;
}
// identified units are named by what they are (unit_names.json: SGBD -> its ISTA group's name), the same on
// every model; the G20 address table only for units that gave no index
const NAMES = readJson(path.join(SOURCE, 'unit_names.json'));
const unitName = (a) => {
    const v = variantOf(a), n = ecuName(a);
    return (v && NAMES[v]) || (v && /^ECU 0x/.test(n) ? v : n);
};

const withFaults = () => (scan ? scan.ecus.filter((e) => e.dtcs.length) : []);
const ecuOf = (addr) => (scan ? scan.ecus.find((e) => e.addr === addr) : null);
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
const two = (n) => (n < 10 ? '0' : '') + n;
const when = (ms) => { const d = new Date(ms); return `${two(d.getDate())}.${two(d.getMonth() + 1)}. ${two(d.getHours())}:${two(d.getMinutes())}`; };

function connectTasu() {
    return someipBuilders.buildAndInitTypedProxy(TASU_IF, TASU_INST, { timeoutMs: 10000 })
        .then((p) => diag.attach(p))
        .then(() => { link = 'ok'; log('TASU ready'); })
        .catch((e) => { link = `ERR ${errText(e)}`; log('TASU:', e); setTimeout(connectTasu, RETRY_MS); })
        .then(render);
}

// ---- parked check: speed + engine speed (scalings car-confirmed in oap-cardash) ------------------------
const CAR_SOURCES = {
    Speed: ['de.bmw.infotainment.vehicle.Vehicle2', 'statusCarSpeed2',
        (x) => { const r = x && x.speedVehicleCentreOfGravity; if (typeof r === 'number' && r !== 65535) guard.speed(r / 64); }],
    Rpm: ['de.bmw.infotainment.vehicle.CDS', 'statusEngineSpeed2',
        (x) => { const r = x && x.actualValueRPMEngineCrankshaft; if (typeof r === 'number' && r !== 65535) guard.rpm(r * 0.25); }],
};
const carProxies = {};
/** read speed + rpm now (resolves either way; a value that doesn't come stays stale = not parked) */
function readCar() {
    return Promise.all(Object.keys(carProxies).map((n) => {
        const [, field, fn] = CAR_SOURCES[n];
        return Promise.resolve().then(() => carProxies[n][field].getValue()).then(fn, () => null);
    }));
}
function connectCar(name) {
    const [ifName, field, fn] = CAR_SOURCES[name];
    return someipBuilders.buildAndInitTypedProxy(ifName, '1', { timeoutMs: 10000 })
        .then((p) => Promise.resolve().then(() => p[field].subscribe(fn)).catch((e) => log(`${name} subscribe:`, e))
            .then(() => { carProxies[name] = p; }))
        .catch((e) => { log(`${name}:`, e); setTimeout(() => connectCar(name), RETRY_MS); });
}

// ---- Check Control ------------------------------------------------------------------------------------
const cc = new Map();       // ccmId -> { ecu, reason }
const ccNames = new Map();  // ccmId -> { name, color }
const ccLink = { CCM: 'connecting', Kombi: 'connecting' };
const ccProxies = {};
// the values come as nested structs / unions: visit every object in them
function walk(o, fn) {
    if (!o || typeof o !== 'object') return;
    if (Array.isArray(o)) { o.forEach((x) => walk(x, fn)); return; }
    fn(o);
    Object.keys(o).forEach((k) => walk(o[k], fn));
}
function onBasicList(v) {
    const seen = new Set();
    walk(v, (o) => {
        if (o.ccmId === undefined) return;
        seen.add(o.ccmId);
        if (o.activeState === 'AKTIV' || o.activeState === 0) cc.set(o.ccmId, { ecu: o.requestorDiagAddr, reason: String(o.reason) });
        else cc.delete(o.ccmId);
    });
    if (Array.isArray(v)) [...cc.keys()].forEach((id) => { if (!seen.has(id)) cc.delete(id); });   // the whole list: gone = inactive
    render();
}
function onNames(v) {
    walk(v, (o) => {
        const id = o.cCIdentifer !== undefined ? o.cCIdentifer : o.cCIdentifier;
        const name = o.cCShortName || o.cCName;
        if (id !== undefined && name) ccNames.set(id, { name: String(name).replace(/[^\x20-\x7e]/g, '').trim(), color: o.cCColor });
    });
    render();
}
const CC_SOURCES = {
    CCM: [CCM_IF, { basicList: onBasicList }],
    Kombi: [KOMBI_IF, { ccList: onNames, newCCMessage: onNames }],
};
function readCc() {
    Object.keys(ccProxies).forEach((name) => {
        const [, fields] = CC_SOURCES[name], p = ccProxies[name];
        Object.keys(fields).forEach((f) => { if (p[f] && typeof p[f].getValue === 'function') Promise.resolve().then(() => p[f].getValue()).then(fields[f], () => null); });
    });
}
function connectCc(name) {
    const [ifName, fields] = CC_SOURCES[name];
    return someipBuilders.buildAndInitTypedProxy(ifName, '1', { timeoutMs: 10000 })
        .then((p) => Promise.all(Object.keys(fields).map((f) => Promise.resolve().then(() => p[f].subscribe(fields[f]))
            .catch((e) => log(`${name}.${f} subscribe:`, e)))).then(() => { ccProxies[name] = p; ccLink[name] = 'ok'; readCc(); }))
        .catch((e) => { ccLink[name] = `ERR ${errText(e)}`; log(`${name}:`, e); setTimeout(() => connectCc(name), RETRY_MS); })
        .then(render);
}
const ccColor = (c) => ({ RED: 'RED', 1: 'RED', YELLOW: 'YEL', 2: 'YEL', ORANGE: 'ORA', 4: 'ORA', GREEN: 'GRN', 3: 'GRN', WHITE: 'WHT', 5: 'WHT' }[c] || '');
const CC_THEME = { RED: 'crit', YEL: 'warn', ORA: 'warn', GRN: 'ok' };    // badge colour on the screen
function ccItems() {
    return [...cc.keys()].sort((a, b) => a - b).map((id) => {
        const m = cc.get(id), n = ccNames.get(id) || {}, short = ccColor(n.color);
        const from = m.ecu !== undefined && m.ecu !== 0 ? unitName(m.ecu) : '';
        return { badge: short, title: n.name || `Message ${id}`, color: CC_THEME[short],
            sub: [from, /DTC/.test(m.reason) ? 'from a fault code' : '', `id ${id}`].filter(Boolean).join(' · ') };
    });
}
const ccState = () => (ccLink.CCM === 'ok' ? '' : ccLink.CCM === 'connecting' ? 'connecting...' : 'not available');

/** units not asked before say which SGBD they are: one functional 22 F1 50 (read-only, like the scan) */
function identify(addrs) {
    const todo = addrs.filter((a) => !(hex(a) in ids));
    if (!todo.length) return Promise.resolve();
    return diag.functional(0x22, [0xF1, 0x50], { accept: isSgbdIndexReply })
        .then((res) => {
            res.forEach((uds, a) => { ids[hex(a)] = parseSgbdIndex(uds) || ''; });
            todo.forEach((a) => { if (!(hex(a) in ids)) ids[hex(a)] = ''; });
            try { fs.writeFileSync(IDS_FILE, JSON.stringify(ids)); } catch (e) { log('save ids:', e); }
            // raw bytes of units whose index ecu.db doesn't know: to check the reply layout on a new car
            log('identify:', [...res.keys()].map((a) => `${hex(a)}=${ids[hex(a)] || '-'}${variantOf(a) ? ` ${variantOf(a)}`
                : ` ?${res.get(a).map((x) => hex(x)).join('')}`}`).join(' '));
        })
        .catch((e) => log('identify failed:', e));   // texts stay off; asked again next scan
}

function doScan(keep) {
    if (phase !== 'idle') return Promise.resolve();
    phase = 'scanning'; replies = 0; msg = '';
    render();
    const params = [0x02, MASK];
    return diag.functional(0x19, params, { onReply: (e, n) => { replies = n; render(); } })
        .then((res) => {
            const ecus = [];
            res.forEach((uds, addr) => {
                const p = parseDtcReply(uds, params);
                ecus.push({ addr, dtcs: p.dtcs, nrc: p.ok ? null : p.nrc });
            });
            ecus.sort((a, b) => b.dtcs.length - a.dtcs.length || a.addr - b.addr);
            scan = { at: Date.now(), ecus };
            try { fs.writeFileSync(SCAN_FILE, JSON.stringify(scan)); } catch (e) { log('save scan:', e); }
            const n = ecus.reduce((s, e) => s + e.dtcs.length, 0);
            log(`scan: ${ecus.length} units, ${n} codes`, ecus.filter((e) => e.dtcs.length || e.nrc)
                .map((e) => `${hex(e.addr)}:${e.nrc ? `NRC ${hex(e.nrc)}` : e.dtcs.map((d) => `${d.code}/${hex(d.status)}`).join(',')}`).join(' '));
            msg = ecus.length ? keep || '' : 'No control unit answered. Ignition on?';
            return identify(ecus.map((e) => e.addr));
        })
        .catch((e) => { msg = `Scan failed: ${errText(e)}`; log('scan failed:', e); })
        .then(() => { phase = 'idle'; render(); });
}

function doClear() {
    const targets = clearTarget === 'all' ? withFaults().map((e) => e.addr) : [clearTarget];
    if (phase !== 'idle' || !targets.length || targets[0] === null) return Promise.resolve();
    phase = 'clearing';
    let ok = 0;
    let stopped = '';           // the guard refused (car moved / engine started): no further units
    let chain = Promise.resolve();
    targets.forEach((a) => {
        chain = chain.then(() => {
            if (stopped) return null;
            msg = `Clearing ${unitName(a)}...`; render();
            // fresh speed + rpm right before each request: the guard decides on them
            return readCar().then(() => diag.physical(a, 0x14, [0xFF, 0xFF, 0xFF], 6000))
                .then((r) => {
                    if (r && r[0] === 0x54) ok++;
                    else log(`clear ${hex(a)}:`, r ? (r[0] === 0x7F ? NRC[r[2]] || hex(r[2]) : r.map((x) => hex(x)).join(' ')) : 'no answer');
                }, (e) => { if (!guard.check(0x14, [0xFF, 0xFF, 0xFF]).ok) stopped = errText(e); log(`clear ${hex(a)}:`, errText(e)); });
        });
    });
    return chain.then(() => {
        log(`cleared ${ok}/${targets.length}${stopped ? `, stopped: ${stopped}` : ''}`);
        const done = `${stopped ? `Stopped, ${stopped}. ` : ''}Cleared ${ok} of ${plural(targets.length, 'control unit')}.`;
        phase = 'idle'; msg = `${done} Scanning again...`;
        render();
        return new Promise((res) => setTimeout(res, 1500)).then(() => doScan(done));
    });
}

// ---- what the screens show ----------------------------------------------------------------------------
// list rows (the renderer's list element): { badge, title, sub, color } - color = the badge's theme colour
const statusColor = (b) => (b & 0x81 ? 'crit' : b & 0x0C ? 'warn' : 'dim');   // active / lamp, pending / stored, history
let moduleAddrs = [];       // moduleList row -> unit address (the rows last drawn)
function moduleItems() {
    const l = withFaults();
    moduleAddrs = l.map((e) => e.addr);
    return l.map((e) => {
        const act = e.dtcs.filter((d) => d.status & 1).length;
        return { badge: String(e.dtcs.length), title: unitName(e.addr), sub: `0x${hex(e.addr)} · ${act ? `${act} active` : 'stored'}`, color: act ? 'crit' : 'warn' };
    });
}
function moduleEmpty() {
    if (!scan) return phase === 'scanning' ? 'Scanning...' : 'Not scanned yet. Tap Scan all control units.';
    return scan.ecus.length ? 'No fault codes stored.' : 'No control unit answered. Ignition on?';
}

function faultItems() {
    const e = ecuOf(selected);
    return e ? e.dtcs.map((d) => {
        const s = statusInfo(d.status);
        return { badge: s.short, title: d.code, sub: `${s.label} · ${describe(e.addr, d.code) || `status ${hex(d.status)}`}`, color: statusColor(d.status) };
    }) : [];
}

function scanSub() {
    if (phase === 'scanning') return `Scanning · ${plural(replies, 'control unit')} answered`;
    if (phase === 'clearing') return 'Clearing fault codes...';
    if (!scan) return 'Not scanned yet';
    return `Last scan ${when(scan.at)} · ${plural(scan.ecus.length, 'unit')}, ${plural(scan.ecus.reduce((s, e) => s + e.dtcs.length, 0), 'code')}`;
}

// notes under the rows: the latest message first (the box cuts the end)
function hintText() {
    const out = [];
    if (msg) out.push(msg);
    if (link !== 'ok') out.push(`Diagnostic link: ${link}`);
    if (!scan) out.push('Ignition on, engine off. Tap Scan to read the fault memory of every control unit.');
    else {
        const refused = scan.ecus.filter((e) => e.nrc).map((e) => `${unitName(e.addr)} (${NRC[e.nrc] || `NRC ${hex(e.nrc)}`})`);
        if (refused.length) out.push(`Refused the request: ${refused.join(', ')}.`);
    }
    const known = scan ? scan.ecus.filter((e) => variantOf(e.addr)).length : 0;
    out.push(known ? `ISTA fault texts for ${plural(known, 'identified control unit')}; other codes show their status byte.`
        : 'Codes are BMW fault codes as ISTA shows them; look them up per control unit.');
    const clean = scan ? scan.ecus.filter((e) => !e.dtcs.length && !e.nrc).map((e) => unitName(e.addr)) : [];
    if (clean.length) out.push(`No codes: ${clean.join(', ')}.`);
    return out.join('\n');
}

// ---- screens (the renderer) ----------------------------------------------------------------------------
// renderer/ is the builder's export: screens.json + its runtime. Loaded with a computed path: build_bundle.py
// leaves it to the platform require (plain files beside bundle.js, Node 8).
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
let screens = null;

// the app's values on every screen (ScreenApp.set: drawn only when the shown screen changed)
function render() {
    if (!screens) return;
    const total = scan ? scan.ecus.reduce((s, e) => s + e.dtcs.length, 0) : null, units = withFaults().length;
    const e = ecuOf(selected), v = e && variantOf(e.addr), ccs = ccState();
    screens.set('scanRow', { sub: scanSub(), text: total === null ? '-' : String(total) })
        .set('clearAllRow', { sub: !scan ? 'Scan first' : units ? `${plural(units, 'control unit')} with codes` : 'Nothing to clear', text: scan ? String(units) : '-' })
        .set('ccRow', { sub: ccs ? `Check Control ${ccs}` : cc.size ? `${cc.size} active` : 'None active', text: ccs ? '-' : String(cc.size) })
        .set('hintText', { text: hintText() })
        .set('moduleList', { items: moduleItems(), empty: moduleEmpty(), sel: -1 })
        .set('unitTitle', { text: e ? unitName(e.addr) : 'No control unit selected' })
        .set('unitSub', { text: e ? [`Address 0x${hex(e.addr)}`, v, plural(e.dtcs.length, 'fault code')].filter(Boolean).join(' · ') : '' })
        .set('faultList', { items: faultItems() })
        .set('unitHint', { text: msg })
        .set('clearHead', { text: clearTarget === null ? '' : clearTarget === 'all' ? `Clear the fault codes of ${plural(units, 'control unit')}?`
            : `Clear the fault codes of ${unitName(clearTarget)} (0x${hex(clearTarget)})?` })
        .set('ccSub', { text: ccs ? `Check Control ${ccs}` : `${plural(cc.size, 'active Check Control message')}${ccLink.Kombi === 'ok' ? '' : ' · names: cluster list not available'}` })
        .set('ccList', { items: ccItems(), empty: ccs ? `Check Control ${ccs} (${ccLink.CCM})` : 'No active Check Control messages' });
}

// no confirm screen unless parked (the guard checks again before every request)
function parkedOrSay() {
    const p = guard.parked();
    if (!p.ok) { msg = `Clearing needs the car parked: ${p.why}. Stop, engine off, ignition on.`; render(); }
    return p.ok;
}
function confirmClear(target) {
    if (!parkedOrSay()) return;
    clearTarget = target;
    render();
    showScreen('confirmClear');
}

// taps with "app event" (the design's onTap event:<name>); screen changes without a condition are the design's own
const EVENTS = {
    scan: () => doScan(),
    clearAll: () => {
        if (phase !== 'idle') return;
        if (!withFaults().length) { msg = scan ? 'Nothing to clear.' : 'Scan first, then clear.'; render(); return; }
        confirmClear('all');
    },
    clearUnit: () => {
        const e = ecuOf(selected);
        if (phase === 'idle' && e && e.dtcs.length) confirmClear(selected);
    },
    clearYes: () => { closeScreen('confirmClear'); doClear(); },
    cc: () => { readCc(); showScreen('ccMessages'); },
    ccRefresh: () => readCc(),
};
const onEvent = (name) => { if (EVENTS[name]) EVENTS[name](); };
// a unit tapped in the list: its codes (the list's onTap then opens moduleFaults)
function onChange(name, o) {
    if (name !== 'moduleList' || moduleAddrs[o.sel] === undefined) return;
    selected = moduleAddrs[o.sel];
    screens.set('faultList', { top: 0 });
    render();
}

// ---- RHMI: the host states -----------------------------------------------------------------------------
const rhmiManager          = new RhmiManager();
const resourceManager      = new ResourceManager(APPLET_ID);
const rhmiResourcesLocator = new RhmiResourcesLocator({ rhmiConfigKey: 'rhmiData' });
const multiLanguageStringBundleFactory = new MultiLanguageStringBundleFactory({ currentVehicleUnits: new CurrentVehicleUnits(), resourceManager, rhmiResourcesLocator });
const rhmiApplicationFactory = new RhmiApplicationFactory({ multiLanguageStringBundleFactory, resourceManager, rhmiManager, rhmiResourcesLocator });

let app = null;
const comp = (n) => app.getByName(n);
function showScreen(name, open) {
    return comp(name).updateResources().then(open || (() => app.openState(name)))
        .then(() => log(`opened ${name}`))
        .catch((e) => log(`open ${name} failed:`, e));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed:`, e));

function startScreens(rhmiApp) {
    app = rhmiApp;
    const design = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: (m) => log(m), warn: (m) => log(m), error: (m) => log(m) };
    const gpu = new RenderClient('iteriodev_dtcscan', rlog);
    screens = new ScreenApp(gpu, design, { view: 'id8', log: rlog });
    // a host state per screen: the HMI shows it -> the screen shows; BACK / HOME / popups through them
    const hosts = {};
    STATES.forEach((s) => { hosts[s] = comp(s); });
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('change', onChange);
    screens.on('event', onEvent);
    // the user left for the HMI (touched it): leave the host states too, or the HMI would show their empty pages
    screens.on('closed', (why) => { if (why !== 'hmi') STATES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
    render();
}

// Tile tap: MainApp calls AppStatus.changeVisibility(visible, reason, entryPointUuid, ...).
// The SDK's background class ignores it, so open the entry screen ourselves.
function onChangeVisibility(args) {
    const a = args || {};
    log('tile:', a, app ? '' : '(screens not ready)');
    if (a.visible && app) showScreen('home', () => app.openEntryState(a.entryPointUuid || ENTRY_UUID));
    return Promise.resolve({});
}

// lifecycle towards MainApp (trigger_service pattern): without it MainApp drops the app
const onlineApp = OnlineAppBackground.create();
onlineApp.createAppStatusService = function () {
    const instanceName = `${process.getuid() - this.extendedConfig.get('someip', 'instanceIdOffset')}`;
    return someipBuilders.buildTypedService('de.bmw.infotainment.telematic.oap.AppStatus', instanceName, {
        changeVisibility: onChangeVisibility,
        configureStartWidgetApp: () => Promise.resolve({}),
        appStatus: { getValue: () => Promise.resolve(this.appStatus) },
        hmiStatus: { getValue: () => Promise.resolve(this.hmiStatus) },
        audioStatus: { getValue: () => Promise.resolve(this.audioStatus) },
    }).then((service) => service.init())
        .then((service) => { this.emit('appStatusProxyReady'); return service; });
};
onlineApp.on('terminated', () => onlineApp.shutdown().catch(() => {}).then(() => process.exit(0)));
onlineApp.on('appStatusProxyReady', () => onlineApp.registerActive());

const startRhmi = () => rhmiResourcesLocator.init()
    .then(() => Promise.all([rhmiManager.init(), resourceManager.init(), rhmiApplicationFactory.init()]))
    .then(() => rhmiApplicationFactory.create(process.getuid(), { appletIdOffset: APPLETID_OFFSET }))
    .then((rhmiApp) => rhmiApp.init().then(() => rhmiApp.setActive(true))
        .then(() => rhmiApp.mapEntryState(ENTRY_UUID, rhmiApp.getByName('home')))
        .then(() => startScreens(rhmiApp))
        .then(() => log('screens ready')));

log('start', process.getuid());
onlineApp.start()
    .then(() => Promise.all([onlineApp.initialized(), startRhmi()]))
    .then(() => {
        connectTasu();
        Object.keys(CC_SOURCES).forEach(connectCc);
        Object.keys(CAR_SOURCES).forEach(connectCar);
        setInterval(() => { if (screens && screens.st) readCc(); }, CC_POLL_MS);
        setInterval(() => { if (screens && screens.st) readCar(); }, CAR_POLL_MS);
    })
    .catch((e) => log('init failed:', e));

/**
 * @file
 *
 * @copyright (C) 2021 BMW AG, BMW Car IT GmbH
 *
 * @version 1.4.1
 * @description Entry point for OAP Apps:
 * Generates byte code from app.js and runs it.
 * Also performs cleanup task(s)
 */
'use strict';

const fs = require('fs');
const vm = require('vm');
const path = require('path');
const util = require('util');
// require for child_process is only done in main process when needed

/* DEFAULT VALUES */
let DATA_RELATIVE_PATH = '../../data';
let JS_RELATIVE_PATH = './app.js';

// allow config overwrite:
const CONFIG_PATH = path.join(__dirname, 'runnerConfig.json');
if (fs.existsSync(CONFIG_PATH)) {
    const read = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));
    DATA_RELATIVE_PATH = read.DATA_RELATIVE_PATH;
    JS_RELATIVE_PATH = read.JS_RELATIVE_PATH;
}

const readFileAsync = util.promisify(fs.readFile);
const statAsync = util.promisify(fs.stat);
const unlinkAsync = util.promisify(fs.unlink);
const readdirAsync = util.promisify(fs.readdir);

const APP_UID = process.getuid();
const TMPDIR = '/tmp/';
const RUNDIR = '/var/run/someip/';

const JS_ABSOLUTE_PATH = path.join(__dirname, JS_RELATIVE_PATH);
const DATA_ABSOLUTE_PATH = path.join(__dirname, DATA_RELATIVE_PATH);
const BYTECODE_ABSOLUTE_PATH_DATA = path.join(DATA_ABSOLUTE_PATH, `${JS_RELATIVE_PATH}.bytecode`);
const BYTECODE_ABSOLUTE_PATH_SOURCE = path.join(DATA_ABSOLUTE_PATH, '../source', `pregenerated.bytecode`);
const CHILD_PROCESS_FLAG = 'outOfProcessCompile';
const DEBUG_FLAG = '--inspect';

/**
 * Generates bytecode with the given paths
 * @param {string} jsPath path of js file
 * @param {string} bytecodePath path of bytecode file
 */
function generateByteCodeAsChild(jsPath, bytecodePath) {
    // new Buffer(1024*1024*1500).fill('abc');
    console.log(`C: outOfProcessCompile`);
    const jsData = fs.readFileSync(jsPath, 'utf-8');

    // create vm
    const script = new vm.Script(jsData, { produceCachedData: true });
    const bytecodeBuffer = script.cachedData;
    console.log('C: generated: ' + bytecodeBuffer.slice(16, 24).toString('hex'));

    // write to output
    try {
        console.log('writing');
        fs.writeFileSync(bytecodePath, bytecodeBuffer);
    } catch (err) {
        console.error('failed to write, trying to clear file', ('' + err).slice(0, 40));
        // clearing is necessary because truncated bytecode files can be loaded in some circumstances
        fs.writeFileSync(bytecodePath, Buffer.alloc(0));
        process.exit(1);
    }
    console.log('C: ' + JSON.stringify(process.memoryUsage()));

    process.exit();
}

/* counts generation attempts to avoid double generation on failure */
let generationCounter = 0;

/** Generates bytecode using a child process. A promise is returned. */
function generateBytecode() {
    if (generationCounter > 0) {
        console.error("generation attempt already made in this session, giving up");
        process.exit(1);
    }
    generationCounter += 1;

    const child_process = require('child_process'); // require in function to avoid loading in child process
    const child = child_process.fork(
        process.argv[1],
        process.argv.slice(2).concat([CHILD_PROCESS_FLAG]),
        { stdio: 'inherit' });

    return new Promise((resolve, reject) => {
        child.on('exit', (data, signal) => {
            if (data !== 0) {
                console.error('non zero exit code of child', data, signal);

                if (data == null && signal === 'SIGKILL') {
                    return reject();
                }
                process.exit(1);
            }
            console.log(data, JSON.stringify(process.memoryUsage()));
            resolve();
        });
    });
}

/**
 * creates folder for bytecode if missing
 */
function ensureBytecodeLocationExists() {
    const dataPaths = path.dirname(JS_RELATIVE_PATH).split('/');
    dataPaths.forEach(p => {
        if (!fs.existsSync(path.join(DATA_ABSOLUTE_PATH, p))) {
            fs.mkdirSync(path.join(DATA_ABSOLUTE_PATH, p));
        }
    });
}

/**
 * Tries to build a vm.script from given js and bytecode. On rejection of bytecode it is regenerated
 * @param {string} jsData
 * @param {Buffer} bytecodeData
 */
async function createVmFromJsAndBytecode(jsPath, bytecodePath) {
    let bytecodeData = Buffer.alloc(0);
    let jsData;
    let script;
    await Promise.all([
        readFileAsync(jsPath, 'utf-8').then(data => { jsData = data }),
        readFileAsync(bytecodePath).then(data => { bytecodeData = data }).catch(e => console.log('failed to read bytecode due to', e.message)),
    ]);
    console.log('vm.script with: ' + bytecodeData.slice(16, 24).toString('hex'));
    if (bytecodeData.length !== 0) {
        script = new vm.Script(jsData, { cachedData: bytecodeData, produceCachedData: false });
    }

    if (bytecodeData.length === 0 || script.cachedDataRejected) {
        console.log('Invalid bytecode detected');
        if (bytecodePath === BYTECODE_ABSOLUTE_PATH_SOURCE && fs.existsSync(BYTECODE_ABSOLUTE_PATH_DATA)) {
            // if bytecode from mainapp fails to start -> try using app generated bytecode
            console.log('Fallback to app-generated bytecode');
            return createVmFromJsAndBytecode(jsPath, BYTECODE_ABSOLUTE_PATH_DATA);
        } else {
            // if app generated bytecode already used
            // happens in case of update with old bytecode present -> regenerate
            console.log('bytecode rejected - regen');
            const generationPromise = generateBytecode();
            let shouldRunWithByteCode = true;

            await generationPromise.catch(() => {
                console.log('Run without bytecode');

                if (fs.existsSync(BYTECODE_ABSOLUTE_PATH_DATA)) {
                    fs.unlinkSync(BYTECODE_ABSOLUTE_PATH_DATA);
                }

                script = new vm.Script(jsData, { produceCachedData: false });
                shouldRunWithByteCode = false;
            });

            if (shouldRunWithByteCode) {
                return generationPromise.then(() => {
                    return fs.readFileSync(BYTECODE_ABSOLUTE_PATH_DATA);
                }).then((bytecodeDataRetry) => {
                    console.log('vm.script with: ' + bytecodeDataRetry.slice(16, 24).toString('hex'));
                    const scriptInner = new vm.Script(jsData, { cachedData: bytecodeDataRetry, produceCachedData: false });
                    if (scriptInner.cachedDataRejected) {
                        console.error('re-generated bytecode rejected - exiting');
                        process.exit(1);
                    }
                    return scriptInner;
                });
            } else {
                return script;
            }
        }
    } else {
        return script;
    }
}

/**
 * Actual app start
 * @param script instance from vm.script containing app
 */
function runVMScript(script) {
    console.log('RUN');
    const vars = {
        require,
        console,
        // We don't need module and exports because we use browserify, but some
        // modules rely on presence of these variables to detect node environment.
        exports: {},
        module: { exports: {} },
        process,
        __dirname: __dirname
    };
    const context = Object.assign({}, global, vars);
    context.global = context;
    script.runInNewContext(context);
}

/**
 * Filters down the files list
 *
 * @private
 *
 * @param {string[]} files Filenames
 * @returns {string[]} files Filenames
 */
async function applyFilters(files, dir) {
    if (!Array.isArray(files) || !files.length) {
        return Promise.resolve([]);
    }

    return Promise.all(files.map((file) => {
        return statAsync(path.resolve(dir, file))
            .then((statObj) => {
                if (!file.startsWith('vsomeip-') || statObj.uid !== APP_UID) {
                    return Promise.resolve();
                }
                var fileDate = statObj.birthtimeMs;
                var now = new Date().getTime();
                var fileAge = Math.abs(fileDate - now);
                if (fileAge < process.uptime() * 1000) {
                    return Promise.resolve();
                }
                return Promise.resolve(file);
            }).catch((err) => Promise.resolve());
    })).then((filteredFiles) => filteredFiles.filter((item) => !!item));
}

/**
 * Deletes the files
 *
 * @private
 *
 * @param {string[]} files Filenames
 */
function deleteFiles(files, dir) {
    let deletedFiles = [];
    return Promise.all(files.map((file) => {
        return unlinkAsync(path.join(dir, file))
            .then(() => deletedFiles.push(file))
            .catch((err) => {
                console.log(`cleanupSomeip: failed to delete ${path.join(dir, file)}: ${err}`);
            });
    }))
        .then(() => console.log(`cleanupSomeip: deleted ${deletedFiles}`));
}

/**
 * Delete vsomeip-* in /var/run/someip/ (-> MGU22) or
 * /tmp/ (-> < MGU22) belonging to current PID
 *
 */
async function cleanupAppFiles() {
    // check if /var/run/someip/ exists (MGU22)
    const runFolderExists = fs.existsSync(RUNDIR);
    if (runFolderExists) {
        const runFiles = fs.readdirSync(RUNDIR);
        const filteredFiles = await applyFilters(runFiles, RUNDIR)
        return deleteFiles(filteredFiles, RUNDIR);
    } else {
        // expect files in /tmp
        const tmpFiles = fs.readdirSync(TMPDIR);
        const filteredFiles = await applyFilters(tmpFiles, TMPDIR)
        return deleteFiles(filteredFiles, TMPDIR);
    }
}

/**
 * Runs the app after ensuring bytecode exists.
 * STEPS:
 * if bytecode is missing: generate in child
 * read js and bytecode
 * try to create VM.script using both
 * run VM.script
 */
async function run() {
    // detect if we are running in parent or child process

    if (process.argv.includes(CHILD_PROCESS_FLAG)) {
        // child
        return generateByteCodeAsChild(JS_ABSOLUTE_PATH, BYTECODE_ABSOLUTE_PATH_DATA); // nothing else to do in child
    } else {
        // parent
        let basePromise = Promise.resolve();
        const cleanupPromise = cleanupAppFiles();
        let bytecodePathToUse = BYTECODE_ABSOLUTE_PATH_SOURCE;
        ensureBytecodeLocationExists();

        if (!fs.existsSync(BYTECODE_ABSOLUTE_PATH_SOURCE)) {
            if (fs.existsSync(BYTECODE_ABSOLUTE_PATH_DATA)) {
                bytecodePathToUse = BYTECODE_ABSOLUTE_PATH_DATA;
                console.log('start with bytecode exists');
            } else {
                console.log('start with bytecode missing');
                basePromise = generateBytecode();
                bytecodePathToUse = BYTECODE_ABSOLUTE_PATH_DATA;
            }
        } else {
            console.log('start with bytecode exists (pre-generated)');
        }

        let shouldRunWithByteCode = true;
        await basePromise.catch(async (_) => {
            console.log('handling child process failure');

            if (fs.existsSync(BYTECODE_ABSOLUTE_PATH_DATA)) {
                fs.unlinkSync(BYTECODE_ABSOLUTE_PATH_DATA);
            }
            const jsData = await readFileAsync(JS_ABSOLUTE_PATH, 'utf-8');
            const script = new vm.Script(jsData, { produceCachedData: false });
            runVMScript(script);
            shouldRunWithByteCode = false;
        });

        if (shouldRunWithByteCode) {
            return basePromise.then(() => Promise.all([
                createVmFromJsAndBytecode(JS_ABSOLUTE_PATH, bytecodePathToUse),
                cleanupPromise
            ]))
                .then(([script, _]) => runVMScript(script))
                .catch((err) => {
                    console.error(err);
                    console.error('Could not start, exit');
                    process.exit(1);
                });
        }
    }
}

if (module.parent) {
    module.exports = { run };
} else {
    if (process.execArgv.find(element => element.startsWith(DEBUG_FLAG))) {
        console.log('starting without bytecode for inspect', process.execArgv);
        require(JS_ABSOLUTE_PATH);
    } else {
        run();
    }
}

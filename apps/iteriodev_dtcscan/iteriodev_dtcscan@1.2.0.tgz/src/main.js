'use strict';
/*
 * iteriodev_dtcscan: fault codes of every control unit (tile "Fault Codes").
 *   Scan : UDS 19 02 0C (pending + confirmed) to all units (0xDF) over TASU, like BMW's teleservice
 *          READ_PRIMARY_DTCS; one reply per unit, collected until 4 s without a new one.
 *   Clear: UDS 14 FF FF FF to each unit that had codes (or one unit), after a confirm popup; then
 *          scans again.
 *   Check Control: active messages from CheckControlMaster.basicList, names from the cluster's
 *          KombiInterface_2 ccList / newCCMessage (read-only, as idrive7-apps does).
 * Every request passes apps/oap-shared/tasu-guard.js (in diag.js send): reads always, clearing only with
 * the car parked (speed 0 + engine speed 0, fresh), flash programming never.
 * Transport + parsing: ./diag.js (ported from idrive7-apps, MIT). The head unit has no fault texts:
 * after a scan every new unit is asked its SGBD index (22 F1 50), which picks its ISTA SGBD and that
 * SGBD's fault texts (sgbd_index.json + texts/, built by scripts/oap-tools/dtc_build.py). Any car.
 *
 * Screens (1.2.0, the car apps' Telemetry design): drawn by the GPU renderer (mgu-renderd, scripts/renderd), laid out
 * by scripts/oap-tools/make_dtcscan_project.js (apps/hmi-ui-builder/projects/fault-codes.json) and exported into this
 * folder (rhmiData/ = one empty RHMI host state per screen, renderer/ = screens.json + the builder's runtime). Tabs
 * Control units | Check Control (its badge: the active messages). home: units with faults and codes, Scan all, Clear
 * all, the units with faults (tap one -> moduleFaults: its codes, Back, clear this unit); confirmClear: the dialog
 * over home; ccMessages. A list longer than four rows shows three a page and Previous / Next.
 * The renderer gives the app the touches on its screens; the HMI's BACK / HOME / popups work through the host
 * states (screenapp.js bindHosts). Start, tile and shutdown: the shared OnlineApp host (oap-shared/online-host.js), iDrive 8.
 */
const fs = require('fs');
const path = require('path');
const util = require('util');
const someipBuilders                   = require('oap-sdk/src/someip/someipBuilders');
const { Diag, parseDtcReply, parseSgbdIndex, isSgbdIndexReply, statusInfo, ecuName, hex, NRC } = require('./diag.js');
const { createGuard }                  = require('./tasu-guard.js');
const { createHost }                   = require('./online-host.js');

const LOG = '[iteriodev_dtcscan]';

const TASU_IF = 'com.harman.infotainment.systemfunctions.tasu.tasu.InternalTasu';
const TASU_INST = 'SystemFunctionsInternalTasuInst1';
// ponytail: current faults only (pending 0x04 + confirmed 0x08); 0xFF would add history entries
const MASK = 0x0C;
const RETRY_MS = 30e3;
// the package root (next to renderer/, texts/): javascript/ is one level down in the source package; the app's data
// folder is beside the package root (the Store's)
const SOURCE = typeof __dirname === 'string' ? path.join(__dirname, '..') : `/var/opt/public/oap/oap_${process.getuid()}/source`;
const DATA = path.join(__dirname, '..', '..', 'data');
const SCAN_FILE = `${DATA}/last_scan.json`;
const LOG_FILE = `${DATA}/dtcscan.log`;
const CCM_IF = 'de.bmw.infotainment.checkcontrol.CheckControlMaster';
const KOMBI_IF = 'de.bmw.infotainment.KombiInterface_2';
const CC_POLL_MS = 10e3;    // getters re-read while a screen is open, in case the notifiers stay silent
const CAR_POLL_MS = 500;    // speed + rpm for the parked check (apps/oap-shared/tasu-guard.js), while a screen is open
const STATES = ['home', 'moduleFaults', 'confirmClear', 'ccMessages'];   // screens = their RHMI host states

const errText = (e) => String(e && e.message || e).slice(0, 80);
// own log file: console output goes to DLT, which has no reader on this car
function log() {
    const line = [new Date().toISOString()].concat([].slice.call(arguments)
        .map((x) => (typeof x === 'string' ? x : util.inspect(x, { depth: 4 }).slice(0, 2000)))).join(' ');
    console.error(LOG, line);
    try { if (fs.statSync(LOG_FILE).size > 256 * 1024) fs.writeFileSync(LOG_FILE, ''); } catch (e) { /* no file yet */ }
    try { fs.appendFileSync(LOG_FILE, `${line}\n`); } catch (e) { /* no data folder */ }
}

// ---- scan / clear -------------------------------------------------------------------------------------
let scan = null;            // { at, ecus: [{ addr, dtcs: [{ code, status }], nrc }] }
try { scan = JSON.parse(fs.readFileSync(SCAN_FILE, 'utf8')); } catch (e) { /* none yet */ }
let phase = 'idle';         // idle | scanning | clearing
let replies = 0;
let msg = '';
let link = 'connecting';
let selected = null;        // unit address shown on moduleFaults
let clearTarget = null;     // 'all' | unit address
// every TASU request passes the guard: reads always, clearing and other state changes only when parked
const guard = createGuard();
const diag = new Diag((m) => log(m), guard);

// Fault texts (scripts/oap-tools/dtc_build.py, nothing car-specific). Each unit says which SGBD it is via
// 22 F1 50 (its SGBD index, what ISTA's IDENT reads); sgbd_index.json maps "<addr> <index>" -> SGBD
// (ecu.db), texts/<SGBD>.json holds that SGBD's fault texts. dtc_texts.json: hand-made "addr:code" (wins).
const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return {}; } };
const TEXTS = readJson(path.join(SOURCE, 'dtc_texts.json'));
const SGBD = readJson(path.join(SOURCE, 'sgbd_index.json'));
const IDS_FILE = `${DATA}/ecu_ids.json`;
const ids = readJson(IDS_FILE);   // "12" -> "0F26E8"; '' = asked, no index (not asked again)
const variantOf = (addr) => SGBD[`${hex(addr)} ${ids[hex(addr)]}`] || null;
const variantTexts = {};          // SGBD -> { code: text }, loaded on first use
function describe(addr, code) {
    const own = TEXTS[`${hex(addr)}:${code}`];
    if (own) return own;
    const v = variantOf(addr);
    if (!v) return null;
    if (!variantTexts[v]) variantTexts[v] = readJson(path.join(SOURCE, 'texts', `${v}.json`));
    return variantTexts[v][code] || null;
}
// identified units are named by what they are (unit_names.json: SGBD -> its ISTA group's name), the same on
// every model; the G20 address table only for units that gave no index
const NAMES = readJson(path.join(SOURCE, 'unit_names.json'));
const unitName = (a) => {
    const v = variantOf(a), n = ecuName(a);
    return (v && NAMES[v]) || (v && /^ECU 0x/.test(n) ? v : n);
};

const withFaults = () => (scan ? scan.ecus.filter((e) => e.dtcs.length) : []);
const ecuOf = (addr) => (scan ? scan.ecus.find((e) => e.addr === addr) : null);
const plural = (n, w) => `${n} ${w}${n === 1 ? '' : 's'}`;
const two = (n) => (n < 10 ? '0' : '') + n;
const when = (ms) => { const d = new Date(ms); return `${two(d.getDate())}.${two(d.getMonth() + 1)}. ${two(d.getHours())}:${two(d.getMinutes())}`; };

function connectTasu() {
    return someipBuilders.buildAndInitTypedProxy(TASU_IF, TASU_INST, { timeoutMs: 10000 })
        .then((p) => diag.attach(p))
        .then(() => { link = 'ok'; log('TASU ready'); })
        .catch((e) => { link = `ERR ${errText(e)}`; log('TASU:', e); setTimeout(connectTasu, RETRY_MS); })
        .then(render);
}

// ---- parked check: speed + engine speed (scalings car-confirmed in oap-cardash) ------------------------
const CAR_SOURCES = {
    Speed: ['de.bmw.infotainment.vehicle.Vehicle2', 'statusCarSpeed2',
        (x) => { const r = x && x.speedVehicleCentreOfGravity; if (typeof r === 'number' && r !== 65535) guard.speed(r / 64); }],
    Rpm: ['de.bmw.infotainment.vehicle.CDS', 'statusEngineSpeed2',
        (x) => { const r = x && x.actualValueRPMEngineCrankshaft; if (typeof r === 'number' && r !== 65535) guard.rpm(r * 0.25); }],
};
const carProxies = {};
/** read speed + rpm now (resolves either way; a value that doesn't come stays stale = not parked) */
function readCar() {
    return Promise.all(Object.keys(carProxies).map((n) => {
        const [, field, fn] = CAR_SOURCES[n];
        return Promise.resolve().then(() => carProxies[n][field].getValue()).then(fn, () => null);
    }));
}
function connectCar(name) {
    const [ifName, field, fn] = CAR_SOURCES[name];
    return someipBuilders.buildAndInitTypedProxy(ifName, '1', { timeoutMs: 10000 })
        .then((p) => Promise.resolve().then(() => p[field].subscribe(fn)).catch((e) => log(`${name} subscribe:`, e))
            .then(() => { carProxies[name] = p; }))
        .catch((e) => { log(`${name}:`, e); setTimeout(() => connectCar(name), RETRY_MS); });
}

// ---- Check Control ------------------------------------------------------------------------------------
const cc = new Map();       // ccmId -> { ecu, reason }
const ccNames = new Map();  // ccmId -> { name, color }
const ccLink = { CCM: 'connecting', Kombi: 'connecting' };
const ccProxies = {};
// the values come as nested structs / unions: visit every object in them
function walk(o, fn) {
    if (!o || typeof o !== 'object') return;
    if (Array.isArray(o)) { o.forEach((x) => walk(x, fn)); return; }
    fn(o);
    Object.keys(o).forEach((k) => walk(o[k], fn));
}
function onBasicList(v) {
    const seen = new Set();
    walk(v, (o) => {
        if (o.ccmId === undefined) return;
        seen.add(o.ccmId);
        if (o.activeState === 'AKTIV' || o.activeState === 0) cc.set(o.ccmId, { ecu: o.requestorDiagAddr, reason: String(o.reason) });
        else cc.delete(o.ccmId);
    });
    if (Array.isArray(v)) [...cc.keys()].forEach((id) => { if (!seen.has(id)) cc.delete(id); });   // the whole list: gone = inactive
    render();
}
function onNames(v) {
    walk(v, (o) => {
        const id = o.cCIdentifer !== undefined ? o.cCIdentifer : o.cCIdentifier;
        const name = o.cCShortName || o.cCName;
        if (id !== undefined && name) ccNames.set(id, { name: String(name).replace(/[^\x20-\x7e]/g, '').trim(), color: o.cCColor });
    });
    render();
}
const CC_SOURCES = {
    CCM: [CCM_IF, { basicList: onBasicList }],
    Kombi: [KOMBI_IF, { ccList: onNames, newCCMessage: onNames }],
};
function readCc() {
    Object.keys(ccProxies).forEach((name) => {
        const [, fields] = CC_SOURCES[name], p = ccProxies[name];
        Object.keys(fields).forEach((f) => { if (p[f] && typeof p[f].getValue === 'function') Promise.resolve().then(() => p[f].getValue()).then(fields[f], () => null); });
    });
}
function connectCc(name) {
    const [ifName, fields] = CC_SOURCES[name];
    return someipBuilders.buildAndInitTypedProxy(ifName, '1', { timeoutMs: 10000 })
        .then((p) => Promise.all(Object.keys(fields).map((f) => Promise.resolve().then(() => p[f].subscribe(fields[f]))
            .catch((e) => log(`${name}.${f} subscribe:`, e)))).then(() => { ccProxies[name] = p; ccLink[name] = 'ok'; readCc(); }))
        .catch((e) => { ccLink[name] = `ERR ${errText(e)}`; log(`${name}:`, e); setTimeout(() => connectCc(name), RETRY_MS); })
        .then(render);
}
const ccColor = (c) => ({ RED: 'RED', 1: 'RED', YELLOW: 'YEL', 2: 'YEL', ORANGE: 'ORA', 4: 'ORA', GREEN: 'GRN', 3: 'GRN', WHITE: 'WHT', 5: 'WHT' }[c] || '');
const CC_THEME = { RED: 'crit', YEL: 'warn', ORA: 'warn', GRN: 'ok' };    // badge colour on the screen
const CC_WORD = { RED: 'Red', YEL: 'Yellow', ORA: 'Orange', GRN: 'Green', WHT: 'White' };
// the active messages as rows (teleRow opts): the cluster's colour as the badge, its name, who sent it
function ccItems() {
    return [...cc.keys()].sort((a, b) => a - b).map((id) => {
        const m = cc.get(id), n = ccNames.get(id) || {}, short = ccColor(n.color);
        const from = m.ecu !== undefined && m.ecu !== 0 ? unitName(m.ecu) : '';
        return { badge: CC_WORD[short] || 'Info', badgeColor: CC_THEME[short] || 'dim', label: n.name || `Message ${id}`,
            sub: [from, /DTC/.test(m.reason) ? 'from a fault code' : '', `id ${id}`].filter(Boolean).join(' · ') };
    });
}
const ccState = () => (ccLink.CCM === 'ok' ? '' : ccLink.CCM === 'connecting' ? 'connecting...' : 'not available');

/** units not asked before say which SGBD they are: one functional 22 F1 50 (read-only, like the scan) */
function identify(addrs) {
    const todo = addrs.filter((a) => !(hex(a) in ids));
    if (!todo.length) return Promise.resolve();
    return diag.functional(0x22, [0xF1, 0x50], { accept: isSgbdIndexReply })
        .then((res) => {
            res.forEach((uds, a) => { ids[hex(a)] = parseSgbdIndex(uds) || ''; });
            todo.forEach((a) => { if (!(hex(a) in ids)) ids[hex(a)] = ''; });
            try { fs.writeFileSync(IDS_FILE, JSON.stringify(ids)); } catch (e) { log('save ids:', e); }
            // raw bytes of units whose index ecu.db doesn't know: to check the reply layout on a new car
            log('identify:', [...res.keys()].map((a) => `${hex(a)}=${ids[hex(a)] || '-'}${variantOf(a) ? ` ${variantOf(a)}`
                : ` ?${res.get(a).map((x) => hex(x)).join('')}`}`).join(' '));
        })
        .catch((e) => log('identify failed:', e));   // texts stay off; asked again next scan
}

// a unit's 19 02 reply -> { addr, dtcs, nrc }; the units with the most codes first
const PARAMS = [0x02, MASK];
const ecuFrom = (addr, uds) => { const p = parseDtcReply(uds, PARAMS); return { addr, dtcs: p.dtcs, nrc: p.ok ? null : p.nrc }; };
const byFaults = (a, b) => b.dtcs.length - a.dtcs.length || a.addr - b.addr;
let live = null;            // the scan running: unit address -> its reply, as they come (the screen shows them); else null
let lastAddr = null;        // the unit that answered last (the scan running)
function doScan(keep) {
    if (phase !== 'idle') return Promise.resolve();
    phase = 'scanning'; replies = 0; msg = ''; live = new Map(); lastAddr = null;
    render();
    return diag.functional(0x19, PARAMS, { onReply: (a, n, uds) => { live.set(a, ecuFrom(a, uds)); lastAddr = a; replies = live.size; render(); } })
        .then((res) => {
            const ecus = [];
            res.forEach((uds, addr) => ecus.push(ecuFrom(addr, uds)));
            ecus.sort(byFaults);
            scan = { at: Date.now(), ecus };
            try { fs.writeFileSync(SCAN_FILE, JSON.stringify(scan)); } catch (e) { log('save scan:', e); }
            const n = ecus.reduce((s, e) => s + e.dtcs.length, 0);
            log(`scan: ${ecus.length} units, ${n} codes`, ecus.filter((e) => e.dtcs.length || e.nrc)
                .map((e) => `${hex(e.addr)}:${e.nrc ? `NRC ${hex(e.nrc)}` : e.dtcs.map((d) => `${d.code}/${hex(d.status)}`).join(',')}`).join(' '));
            // (the empty state says "No control unit answered"; the notes say why it can be)
            msg = ecus.length ? keep || '' : 'No reply over the diagnostic link. Scanning also works with the engine running.';
            return identify(ecus.map((e) => e.addr));
        })
        .catch((e) => { msg = `Scan failed: ${errText(e)}`; log('scan failed:', e); })
        .then(() => { phase = 'idle'; live = null; render(); });
}

function doClear() {
    const targets = clearTarget === 'all' ? withFaults().map((e) => e.addr) : [clearTarget];
    if (phase !== 'idle' || !targets.length || targets[0] === null) return Promise.resolve();
    phase = 'clearing';
    let ok = 0;
    let stopped = '';           // the guard refused (car moved / engine started): no further units
    let chain = Promise.resolve();
    targets.forEach((a) => {
        chain = chain.then(() => {
            if (stopped) return null;
            msg = `Clearing ${unitName(a)}...`; render();
            // fresh speed + rpm right before each request: the guard decides on them
            return readCar().then(() => diag.physical(a, 0x14, [0xFF, 0xFF, 0xFF], 6000))
                .then((r) => {
                    if (r && r[0] === 0x54) ok++;
                    else log(`clear ${hex(a)}:`, r ? (r[0] === 0x7F ? NRC[r[2]] || hex(r[2]) : r.map((x) => hex(x)).join(' ')) : 'no answer');
                }, (e) => { if (!guard.check(0x14, [0xFF, 0xFF, 0xFF]).ok) stopped = errText(e); log(`clear ${hex(a)}:`, errText(e)); });
        });
    });
    return chain.then(() => {
        log(`cleared ${ok}/${targets.length}${stopped ? `, stopped: ${stopped}` : ''}`);
        const done = `${stopped ? `Stopped, ${stopped}. ` : ''}Cleared ${ok} of ${plural(targets.length, 'control unit')}.`;
        phase = 'idle'; msg = `${done} Scanning again...`;
        render();
        return new Promise((res) => setTimeout(res, 1500)).then(() => doScan(done));
    });
}

// ---- what the screens show ----------------------------------------------------------------------------
// rows (teleRow opts): a unit with its count of codes, a code with its status
const statusColor = (b) => (b & 0x81 ? 'crit' : b & 0x0C ? 'warn' : 'dim');   // active / lamp, pending / stored, history
const BADGE = { ACT: 'Active', LAMP: 'Lamp', PEND: 'Pending', STORE: 'Stored', HIST: 'History' };
function unitRow(e) {
    const act = e.dtcs.filter((d) => d.status & 1).length, kept = e.dtcs.length - act;
    return { badge: String(e.dtcs.length), badgeColor: act ? 'crit' : 'warn', label: unitName(e.addr),
        sub: `0x${hex(e.addr)} · ${act ? `${act} active${kept ? `, ${kept} stored` : ''}` : 'stored'}` };
}
function codeRow(e, d) {
    const s = statusInfo(d.status);
    return { badge: BADGE[s.short], badgeColor: statusColor(d.status), label: d.code,
        sub: describe(e.addr, d.code) || `${s.label} · status ${hex(d.status)}` };
}
// a list on a page: four rows (<key>0-3), or three a page and Previous / Next under them (<key>Prev / Page / Next)
const pageNo = { unit: 0, code: 0, cc: 0 };
function showRows(key, list, rowOf) {
    const per = list.length > 4 ? 3 : 4, pages = Math.max(1, Math.ceil(list.length / per));
    pageNo[key] = Math.max(0, Math.min(pageNo[key], pages - 1));
    const first = pageNo[key] * per, rows = list.slice(first, first + per), more = pages > 1;
    for (let i = 0; i < 4; i++) screens.set(`${key}${i}`, rows[i] ? Object.assign({ hidden: false }, rowOf(rows[i])) : { hidden: true });
    screens.set(`${key}Prev`, { hidden: !more, disabled: pageNo[key] === 0 })
        .set(`${key}Next`, { hidden: !more, disabled: pageNo[key] >= pages - 1 })
        .set(`${key}Page`, { hidden: !more, text: `${first + 1}-${first + rows.length} of ${list.length}` });
    return rows;
}
const ago = (ms) => { const m = Math.floor((Date.now() - ms) / 60e3); return m < 1 ? 'just now' : m < 60 ? `${m} min ago` : when(ms); };
// the parked check (clearing needs it) as a chip in the frame
function parkedChip() {
    const p = guard.parked();
    if (p.ok) return [['Engine off', 'ok']];
    return p.why === 'the engine is running' ? [['Engine running', 'warn']] : p.why === 'the car is moving' ? [['Moving', 'warn']] : [];
}

// notes under the counts: the latest message first (the box cuts the end)
function hintText() {
    const out = [];
    if (msg) out.push(msg);
    if (link !== 'ok') out.push(`Diagnostic link: ${link}`);
    if (live) return out.join('\n');                  // a scan running: the last scan's notes no longer hold
    if (!scan) out.push('Ignition on, engine off, then Scan all units.');
    else {
        const refused = scan.ecus.filter((e) => e.nrc).map((e) => `${unitName(e.addr)} (${NRC[e.nrc] || `NRC ${hex(e.nrc)}`})`);
        if (refused.length) out.push(`Refused the request: ${refused.join(', ')}.`);
    }
    const known = scan ? scan.ecus.filter((e) => variantOf(e.addr)).length : 0;
    out.push(known ? `ISTA fault texts for ${plural(known, 'identified control unit')}; other codes show their status byte.`
        : 'Codes are BMW fault codes as ISTA shows them; look them up per control unit.');
    const clean = scan ? scan.ecus.filter((e) => !e.dtcs.length && !e.nrc).map((e) => unitName(e.addr)) : [];
    if (clean.length) out.push(`No codes: ${clean.join(', ')}.`);
    return out.join('\n');
}

// ---- screens (the renderer) ----------------------------------------------------------------------------
// renderer/ is the builder's export: screens.json + its runtime. Loaded with a computed path: the linked app.js
// leaves it to the platform require (plain files in the package, Node 8).
const RENDERER = path.join(SOURCE, 'renderer');
const runtime = (f) => require(path.join(RENDERER, f));
let screens = null;
let unitAddrs = [];         // unit0-3 -> unit address (the rows last drawn)

// the app's values on every screen (ScreenApp.set: drawn only when the shown screen changed)
function render() {
    if (!screens) return;
    const ecus = live ? Array.from(live.values()) : scan ? scan.ecus : [], bad = ecus.filter((e) => e.dtcs.length).sort(byFaults);
    const codes = bad.reduce((s, e) => s + e.dtcs.length, 0), total = scan ? scan.ecus.length : 0;
    const known = !!live || total > 0, none = !live && !!scan && !total;      // none: no unit answered the last scan
    const chips = parkedChip(), ccs = ccState(), tabs = ['Control units', cc.size ? ['Check Control', String(cc.size)] : 'Check Control'];
    // home (and the page under the clear dialog), left: the two counts, how many answered, notes, Scan all / Clear all
    screens.set('homeMenu', { tabs, chips, sub: phase === 'scanning' ? 'Scanning…' : phase === 'clearing' ? 'Clearing fault codes…'
        : scan ? `Last scan ${ago(scan.at)}` : 'Not scanned yet' })
        .set('unitsValue', { value: known ? String(bad.length) : '--', color: !known ? 'faint' : bad.length ? 'crit' : live ? 'text' : 'ok' })
        .set('codesValue', { value: known ? String(codes) : '--', color: !known ? 'faint' : codes || live ? 'text' : 'ok' })
        .set('answered', { text: live ? (total ? `${replies} of ${total} control units read` : `${plural(replies, 'control unit')} answered`)
            : none ? 'No answer to the last scan' : scan ? `of ${plural(total, 'control unit')} answered` : 'Scan to read every control unit' })
        .set('homeHint', { text: hintText() })
        .set('scanBtn', { text: phase === 'scanning' ? 'Scanning…' : phase === 'clearing' ? 'Clearing…' : 'Scan all units', disabled: phase !== 'idle' })
        .set('clearAllBtn', { disabled: phase !== 'idle' || !withFaults().length });
    // right: the scan running (progress against the last scan's units, the units with faults so far, the last answer),
    // the units with faults (a page of them), or a state: not scanned yet, no unit answered, no fault codes
    const listed = !live && bad.length > 0;
    screens.set('scanProgress', { hidden: !live, value: total ? Math.min(1, replies / total) : 0, right: total ? `${replies} / ${total}` : String(replies) })
        .set('nowLine', { hidden: !live || lastAddr === null, text: lastAddr === null ? '' : `Last answer: 0x${hex(lastAddr)} · ${unitName(lastAddr)}` })
        .set('listTitle', { hidden: !listed });
    for (let i = 0; i < 3; i++) screens.set(`live${i}`, live && bad[i] ? Object.assign({ hidden: false }, unitRow(bad[i])) : { hidden: true });
    unitAddrs = showRows('unit', listed ? bad : [], unitRow).map((x) => x.addr);
    screens.set('homeEmpty', live || listed ? { hidden: true } : !scan
        ? { hidden: false, icon: 'wrench', head: 'Not scanned yet', line: 'Scan all units reads the fault memory of every control unit.', color: '' }
        : none ? { hidden: false, icon: 'warning', head: 'No control unit answered', line: 'Ignition on? Then scan again.', color: 'warn' }
            : { hidden: false, icon: 'check', head: 'No fault codes', line: `${plural(total, 'control unit')} answered, none has a fault stored.`, color: 'ok' });
    // a unit's codes (a sub-page of Control units)
    const e = ecuOf(selected), v = e && variantOf(e.addr);
    screens.set('faultsMenu', { tabs, chips, title: e ? unitName(e.addr) : 'Control unit',
        sub: e ? [`0x${hex(e.addr)}`, v, plural(e.dtcs.length, 'fault code')].filter(Boolean).join(' · ') : '' });
    showRows('code', e ? e.dtcs : [], (d) => codeRow(e, d));
    screens.set('codesEmpty', { hidden: !e || e.dtcs.length > 0 })
        .set('faultsHint', { text: msg })
        .set('clearUnitBtn', { disabled: phase !== 'idle' || !e || !e.dtcs.length });
    // the clear dialog
    screens.set('clearDialog', { body: clearTarget === null ? '' : clearTarget === 'all' ? `Clear the fault codes of ${plural(withFaults().length, 'control unit')}?`
        : `Clear the fault codes of ${unitName(clearTarget)} (0x${hex(clearTarget)})?` });
    // Check Control
    const msgs = ccs ? [] : ccItems();
    screens.set('ccMenu', { tabs, sub: ccs ? `Check Control ${ccs}` : msgs.length
        ? `${plural(msgs.length, 'active message')}${ccLink.Kombi === 'ok' ? '' : ' · names: cluster list not available'}` : 'No active messages' });
    showRows('cc', msgs, (m) => m);
    screens.set('ccEmpty', msgs.length ? { hidden: true } : ccs ? { hidden: false, icon: 'warning', head: `Check Control ${ccs}`, line: ccLink.CCM, color: 'warn' }
        : { hidden: false, icon: 'check', head: 'No Check Control messages', line: 'The cluster shows no warning right now.', color: 'ok' });
}

// no confirm screen unless parked (the guard checks again before every request)
function parkedOrSay() {
    const p = guard.parked();
    if (!p.ok) { msg = `Clearing needs the car parked: ${p.why}. Stop, engine off, ignition on.`; render(); }
    return p.ok;
}
function confirmClear(target) {
    if (!parkedOrSay()) return;
    clearTarget = target;
    render();
    showScreen('confirmClear');
}
// home is the first screen; Check Control and a unit's codes open over it (BACK returns to it)
const TAB_PAGES = ['home', 'ccMessages'];
const MENUS = { homeMenu: 0, faultsMenu: 0, ccMenu: 1 };     // each screen's frame (teleShell) -> its own tab
function goTo(to) {
    const cur = screens.st && screens.st.name;
    if (!to || !cur || to === cur) return;
    if (cur !== 'home') closeScreen(cur);
    if (to !== 'home') { readCc(); showScreen(to); }
}
function openUnit(addr) {
    if (addr === undefined) return;
    selected = addr; pageNo.code = 0;
    render();
    showScreen('moduleFaults');
}

// taps with "app event" (the design's onTap event:<name>); Back / Cancel are the design's own ('back')
const EVENTS = {
    scan: () => doScan(),
    clearAll: () => {
        if (phase !== 'idle') return;
        if (!withFaults().length) { msg = scan ? 'Nothing to clear.' : 'Scan first, then clear.'; render(); return; }
        confirmClear('all');
    },
    clearUnit: () => {
        const e = ecuOf(selected);
        if (phase === 'idle' && e && e.dtcs.length) confirmClear(selected);
    },
    clearYes: () => { closeScreen('confirmClear'); doClear(); },
    ccRefresh: () => readCc(),
};
[0, 1, 2, 3].forEach((i) => { EVENTS[`unit${i}`] = () => openUnit(unitAddrs[i]); });
Object.keys(pageNo).forEach((k) => {                    // (showRows keeps the page in range)
    EVENTS[`${k}Prev`] = () => { pageNo[k]--; render(); };
    EVENTS[`${k}Next`] = () => { pageNo[k]++; render(); };
});
const onEvent = (name) => { if (EVENTS[name]) EVENTS[name](); };
// a tab tapped (o: the frame's opts, its sel the tab tapped): the frame keeps its own tab, the page changes
function onChange(name, o) {
    if (!(name in MENUS)) return;
    const to = TAB_PAGES[o.sel];
    screens.set(name, { sel: MENUS[name] });
    goTo(to);
}

// ---- RHMI: the host states (the OnlineApp host hands them over) ----------------------------------------
let app = null;
const comp = (n) => app.getByName(n);
function showScreen(name) {
    return comp(name).updateResources().then(() => app.openState(name))
        .then(() => log(`opened ${name}`))
        .catch((e) => log(`open ${name} failed:`, e));
}
const closeScreen = (name) => app.closeState(name).catch((e) => log(`close ${name} failed:`, e));

function startScreens(rhmiApp, hosts) {
    app = rhmiApp;
    const design = JSON.parse(fs.readFileSync(path.join(RENDERER, 'screens.json'), 'utf8'));
    const { RenderClient } = runtime('kit/renderd.js');
    const { ScreenApp } = runtime('screenapp.js');
    const rlog = { info: (m) => log(m), warn: (m) => log(m), error: (m) => log(m) };
    const gpu = new RenderClient('iteriodev_dtcscan', rlog);
    screens = new ScreenApp(gpu, design, { view: 'id8', log: rlog });
    // a host state per screen: the HMI shows it -> the screen shows; BACK / HOME / popups through them
    screens.bindHosts(hosts, { open: (name) => showScreen(name), close: closeScreen });
    screens.on('change', onChange);
    screens.on('event', onEvent);
    // the user left for the HMI (touched it): leave the host states too, or the HMI would show their empty pages
    screens.on('closed', (why) => { if (why !== 'hmi') STATES.slice().reverse().forEach(closeScreen); });
    gpu.connect();
    render();
}

// ---- lifecycle: the shared OnlineApp host (start, tile, shutdown; iDrive 8) -----------------------------
// The TASU link, Check Control and the car data start with the screens (a background start has none).
log('start', process.getuid());
createHost({
    states: STATES,
    log,
    onReady: (rhmiApp, hosts) => {
        startScreens(rhmiApp, hosts);
        log('screens ready');
        connectTasu();
        Object.keys(CC_SOURCES).forEach(connectCc);
        Object.keys(CAR_SOURCES).forEach(connectCar);
        setInterval(() => { if (screens && screens.st) readCc(); }, CC_POLL_MS);
        setInterval(() => { if (screens && screens.st) readCar().then(render); }, CAR_POLL_MS);   // (+ the parked chip)
    },
});
